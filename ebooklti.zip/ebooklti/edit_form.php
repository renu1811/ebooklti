<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file defines de main basicebooklti configuration form
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

global $CFG;
require_once($CFG->libdir.'/formslib.php');
require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

class mod_ebooklti_edit_types_form extends moodleform{
    public function definition() {
        global $CFG;

        $mform    =& $this->_form;

        $istool = $this->_customdata && $this->_customdata->istool;

        // Add basicebooklti elements.
        $mform->addElement('header', 'setup', get_string('tool_settings', 'ebooklti'));

        $mform->addElement('text', 'ebooklti_typename', get_string('typename', 'ebooklti'));
        $mform->setType('ebooklti_typename', PARAM_TEXT);
        $mform->addHelpButton('ebooklti_typename', 'typename', 'ebooklti');
        $mform->addRule('ebooklti_typename', null, 'required', null, 'client');

        $mform->addElement('text', 'ebooklti_toolurl', get_string('toolurl', 'ebooklti'), array('size' => '64'));
        $mform->setType('ebooklti_toolurl', PARAM_URL);
        $mform->addHelpButton('ebooklti_toolurl', 'toolurl', 'ebooklti');

        $mform->addElement('textarea', 'ebooklti_description', get_string('tooldescription', 'ebooklti'), array('rows' => 4, 'cols' => 60));
        $mform->setType('ebooklti_description', PARAM_TEXT);
        $mform->addHelpButton('ebooklti_description', 'tooldescription', 'ebooklti');
        if (!$istool) {
            $mform->addRule('ebooklti_toolurl', null, 'required', null, 'client');
        } else {
            $mform->disabledIf('ebooklti_toolurl', null);
        }

        if (!$istool) {
            $mform->addElement('text', 'ebooklti_resourcekey', get_string('resourcekey_admin', 'ebooklti'));
            $mform->setType('ebooklti_resourcekey', PARAM_TEXT);
            $mform->addHelpButton('ebooklti_resourcekey', 'resourcekey_admin', 'ebooklti');
            $mform->setForceLtr('ebooklti_resourcekey');

            $mform->addElement('passwordunmask', 'ebooklti_password', get_string('password_admin', 'ebooklti'));
            $mform->setType('ebooklti_password', PARAM_TEXT);
            $mform->addHelpButton('ebooklti_password', 'password_admin', 'ebooklti');
        }

        if ($istool) {
            $mform->addElement('textarea', 'ebooklti_parameters', get_string('parameter', 'ebooklti'), array('rows' => 4, 'cols' => 60));
            $mform->setType('ebooklti_parameters', PARAM_TEXT);
            $mform->addHelpButton('ebooklti_parameters', 'parameter', 'ebooklti');
            $mform->disabledIf('ebooklti_parameters', null);
            $mform->setForceLtr('ebooklti_parameters');
        }

        $mform->addElement('textarea', 'ebooklti_customparameters', get_string('custom', 'ebooklti'), array('rows' => 4, 'cols' => 60));
        $mform->setType('ebooklti_customparameters', PARAM_TEXT);
        $mform->addHelpButton('ebooklti_customparameters', 'custom', 'ebooklti');
        $mform->setForceLtr('ebooklti_customparameters');

        if (!empty($this->_customdata->isadmin)) {
            $options = array(
                EBOOKLTI_COURSEVISIBLE_NO => get_string('show_in_course_no', 'ebooklti'),
                EBOOKLTI_COURSEVISIBLE_PRECONFIGURED => get_string('show_in_course_preconfigured', 'ebooklti'),
                EBOOKLTI_COURSEVISIBLE_ACTIVITYCHOOSER => get_string('show_in_course_activity_chooser', 'ebooklti'),
            );
            if ($istool) {
                // LTI2 tools can not be matched by URL, they have to be either in preconfigured tools or in activity chooser.
                unset($options[EBOOKLTI_COURSEVISIBLE_NO]);
                $stringname = 'show_in_course_ebooklti2';
            } else {
                $stringname = 'show_in_course_ebooklti1';
            }
            $mform->addElement('select', 'ebooklti_coursevisible', get_string($stringname, 'ebooklti'), $options);
            $mform->addHelpButton('ebooklti_coursevisible', $stringname, 'ebooklti');
            $mform->setDefault('ebooklti_coursevisible', '1');
        } else {
            $mform->addElement('hidden', 'ebooklti_coursevisible', EBOOKLTI_COURSEVISIBLE_PRECONFIGURED);
        }
        $mform->setType('ebooklti_coursevisible', PARAM_INT);

        $mform->addElement('hidden', 'typeid');
        $mform->setType('typeid', PARAM_INT);

        $launchoptions = array();
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_EMBED] = get_string('embed', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS] = get_string('embed_no_blocks', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW] = get_string('existing_window', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_WINDOW] = get_string('new_window', 'ebooklti');

        $mform->addElement('select', 'ebooklti_launchcontainer', get_string('default_launch_container', 'ebooklti'), $launchoptions);
        $mform->setDefault('ebooklti_launchcontainer', EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS);
        $mform->addHelpButton('ebooklti_launchcontainer', 'default_launch_container', 'ebooklti');
        $mform->setType('ebooklti_launchcontainer', PARAM_INT);

        $mform->addElement('advcheckbox', 'ebooklti_contentitem', get_string('contentitem', 'ebooklti'));
        $mform->addHelpButton('ebooklti_contentitem', 'contentitem', 'ebooklti');
        $mform->setAdvanced('ebooklti_contentitem');
        if ($istool) {
            $mform->disabledIf('ebooklti_contentitem', null);
        }

        $mform->addElement('text', 'ebooklti_toolurl_ContentItemSelectionRequest',
            get_string('ebooklti_toolurl_ContentItemSelectionRequest', 'ebooklti'), array('size' => '64'));
        $mform->setType('ebooklti_toolurl_ContentItemSelectionRequest', PARAM_URL);
        $mform->setAdvanced('ebooklti_toolurl_ContentItemSelectionRequest');
        $mform->addHelpButton('ebooklti_toolurl_ContentItemSelectionRequest', 'ebooklti_toolurl_ContentItemSelectionRequest', 'ebooklti');
        $mform->disabledIf('ebooklti_toolurl_ContentItemSelectionRequest', 'ebooklti_contentitem', 'notchecked');
        if ($istool) {
            $mform->disabledIf('ebooklti_toolurl__ContentItemSelectionRequest', null);
        }

        $mform->addElement('hidden', 'oldicon');
        $mform->setType('oldicon', PARAM_URL);

        $mform->addElement('text', 'ebooklti_icon', get_string('icon_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('ebooklti_icon', PARAM_URL);
        $mform->setAdvanced('ebooklti_icon');
        $mform->addHelpButton('ebooklti_icon', 'icon_url', 'ebooklti');

        $mform->addElement('text', 'ebooklti_secureicon', get_string('secure_icon_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('ebooklti_secureicon', PARAM_URL);
        $mform->setAdvanced('ebooklti_secureicon');
        $mform->addHelpButton('ebooklti_secureicon', 'secure_icon_url', 'ebooklti');

        if (!$istool) {
            // Display the ebooklti advantage services.
            $this->get_ebooklti_advantage_services($mform);
        }

        if (!$istool) {
            // Add privacy preferences fieldset where users choose whether to send their data.
            $mform->addElement('header', 'privacy', get_string('privacy', 'ebooklti'));

            $options = array();
            $options[0] = get_string('never', 'ebooklti');
            $options[1] = get_string('always', 'ebooklti');
            $options[2] = get_string('delegate', 'ebooklti');

            $mform->addElement('select', 'ebooklti_sendname', get_string('share_name_admin', 'ebooklti'), $options);
            $mform->setType('ebooklti_sendname', PARAM_INT);
            $mform->setDefault('ebooklti_sendname', '2');
            $mform->addHelpButton('ebooklti_sendname', 'share_name_admin', 'ebooklti');

            $mform->addElement('select', 'ebooklti_sendemailaddr', get_string('share_email_admin', 'ebooklti'), $options);
            $mform->setType('ebooklti_sendemailaddr', PARAM_INT);
            $mform->setDefault('ebooklti_sendemailaddr', '2');
            $mform->addHelpButton('ebooklti_sendemailaddr', 'share_email_admin', 'ebooklti');

            // EBOOKLTI Extensions.

            // Add grading preferences fieldset where the tool is allowed to return grades.
            $mform->addElement('select', 'ebooklti_acceptgrades', get_string('accept_grades_admin', 'ebooklti'), $options);
            $mform->setType('ebooklti_acceptgrades', PARAM_INT);
            $mform->setDefault('ebooklti_acceptgrades', '2');
            $mform->addHelpButton('ebooklti_acceptgrades', 'accept_grades_admin', 'ebooklti');

            $mform->addElement('checkbox', 'ebooklti_forcessl', '&nbsp;', ' ' . get_string('force_ssl', 'ebooklti'), $options);
            $mform->setType('ebooklti_forcessl', PARAM_BOOL);
            if (!empty($CFG->mod_ebooklti_forcessl)) {
                $mform->setDefault('ebooklti_forcessl', '1');
                $mform->freeze('ebooklti_forcessl');
            } else {
                $mform->setDefault('ebooklti_forcessl', '0');
            }
            $mform->addHelpButton('ebooklti_forcessl', 'force_ssl', 'ebooklti');

            if (!empty($this->_customdata->isadmin)) {
                // Add setup parameters fieldset.
                $mform->addElement('header', 'setupoptions', get_string('miscellaneous', 'ebooklti'));

                // Adding option to change id that is placed in context_id.
                $idoptions = array();
                $idoptions[0] = get_string('id', 'ebooklti');
                $idoptions[1] = get_string('courseid', 'ebooklti');

                $mform->addElement('text', 'ebooklti_organizationid', get_string('organizationid', 'ebooklti'));
                $mform->setType('ebooklti_organizationid', PARAM_TEXT);
                $mform->addHelpButton('ebooklti_organizationid', 'organizationid', 'ebooklti');

                $mform->addElement('text', 'ebooklti_organizationurl', get_string('organizationurl', 'ebooklti'));
                $mform->setType('ebooklti_organizationurl', PARAM_URL);
                $mform->addHelpButton('ebooklti_organizationurl', 'organizationurl', 'ebooklti');
            }
        }

        /* Suppress this for now - Chuck
         * mform->addElement('text', 'ebooklti_organizationdescr', get_string('organizationdescr', 'ebooklti'))
         * mform->setType('ebooklti_organizationdescr', PARAM_TEXT)
         * mform->addHelpButton('ebooklti_organizationdescr', 'organizationdescr', 'ebooklti')
         */

        /*
        // Add a hidden element to signal a tool fixing operation after a problematic backup - restore process
        //$mform->addElement('hidden', 'ebooklti_fix');
        */

        $tab = optional_param('tab', '', PARAM_ALPHAEXT);
        $mform->addElement('hidden', 'tab', $tab);
        $mform->setType('tab', PARAM_ALPHAEXT);

        $courseid = optional_param('course', 1, PARAM_INT);
        $mform->addElement('hidden', 'course', $courseid);
        $mform->setType('course', PARAM_INT);

        // Add standard buttons, common to all modules.
        $this->add_action_buttons();

    }

    /**
     * Retrieves the data of the submitted form.
     *
     * @return stdClass
     */
    public function get_data() {
        $data = parent::get_data();
        if ($data && !empty($this->_customdata->istool)) {
            // Content item checkbox is disabled in tool settings, so this cannot be edited. Just unset it.
            unset($data->ebooklti_contentitem);
        }
        return $data;
    }

    /**
     * Generates the ebooklti advantage extra configuration adding it to the mform
     *
     * @param MoodleQuickForm $mform
     */
    public function get_ebooklti_advantage_services(&$mform) {
        // For each service add the label and get the array of configuration.
        $services = ebooklti_get_services();
        $mform->addElement('header', 'services', get_string('services', 'ebooklti'));
        foreach ($services as $service) {
            /** @var \mod_ebooklti\local\ebookltiservice\service_base $service */
            $service->get_configuration_options($mform);
        }
    }
}
