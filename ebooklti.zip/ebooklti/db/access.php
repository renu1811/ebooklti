<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the capabilities used by the ebooklti module
 *
 * @package    mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$capabilities = array(

    // Whether the user can see the link to the ebooklti external tool and follow it.
    'mod/ebooklti:view' => array(
        'captype' => 'read',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'coursecreator' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    ),

    // Add an External tool activity to a course.
    'mod/ebooklti:addinstance' => array(
        'riskbitmask' => RISK_XSS,

        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => array(
            'student' => CAP_PROHIBIT,
            'teacher' => CAP_PROHIBIT,
            'editingteacher' => CAP_PROHIBIT,
            'coursecreator'  => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ),

    ),
	
	// Edit an External tool activity to a course.
    'mod/ebooklti:editinstance' => array(
        'riskbitmask' => RISK_XSS,

        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => array(
            'student' => CAP_PROHIBIT,
            'teacher' => CAP_PROHIBIT,
            'editingteacher' => CAP_PROHIBIT,
            'coursecreator'  => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ),

    // Do not allow student, editingteacher, teacher to add this activities.
    //        'clonepermissionsfrom' => 'moodle/course:manageactivities'
    ),
	
	// Controls access to the grade.php script, which shows all the submissions
    // made to the external tool that have been reported back to Moodle.
    'mod/ebooklti:grade' => array(
        'riskbitmask' => RISK_PERSONAL,

        'captype' => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'coursecreator'  => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    ),

    // When the user arrives at the ebooklti external tool, if they have this capability
    // in Moodle, then they are given the Instructor role in the remote system,
    // otherwise they are given Learner. See the ebooklti_get_ims_role function.
    'mod/ebooklti:manage' => array(
        'riskbitmask' => RISK_PERSONAL, // A bit of a guess, but seems likely.

        'captype' => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'coursecreator' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    ),

    // When the user arrives at the ebooklti external tool, if they have this capability
    // in Moodle, then they are given the Administrator role in the remote system,
    // otherwise they are given Learner. See the ebooklti_get_ims_role function.
    'mod/ebooklti:admin' => array(
        'riskbitmask' => RISK_PERSONAL, // A bit of a guess, but seems likely.

        'captype' => 'write',
        'contextlevel' => CONTEXT_MODULE
    ),

    // The ability to create or edit tool configurations for particular courses.
    'mod/ebooklti:addcoursetool' => array(
        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => array(
            'editingteacher' => CAP_PROHIBIT,
            'coursecreator'  => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    ),

    // The ability to request the administrator to configure a particular
    // ebooklti External tool globally.
    'mod/ebooklti:requesttooladd' => array(
        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => array(
            'editingteacher' => CAP_PROHIBIT,
            'coursecreator' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        )
    )
);
