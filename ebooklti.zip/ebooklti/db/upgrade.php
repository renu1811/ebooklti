<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file keeps track of upgrades to the ebooklti module
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

 defined('MOODLE_INTERNAL') || die;

/**
 * xmldb_ebooklti_upgrade is the function that upgrades
 * the ebooklti module database when is needed
 *
 * This function is automaticly called when version number in
 * version.php changes.
 *
 * @param int $oldversion New old version number.
 *
 * @return boolean
 */
function xmldb_ebooklti_upgrade($oldversion) {
    global $CFG, $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2016052301) {

        // Changing type of field value on table ebooklti_types_config to text.
        $table = new xmldb_table('ebooklti_types_config');
        $field = new xmldb_field('value', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null, 'name');

        // Launch change of type for field value.
        $dbman->change_field_type($table, $field);

        // ebooklti savepoint reached.
        upgrade_mod_savepoint(true, 2016052301, 'ebooklti');
    }

    // Automatically generated Moodle v3.2.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    if ($oldversion < 2017111301) {

        // A bug in the EBOOKLTI plugin incorrectly inserted a grade item for
        // EBOOKLTI instances which were set to not allow grading.
        // The change finds any EBOOKLTI which does not have grading enabled,
        // and updates any grades to delete them.

        $ebookltis = $DB->get_recordset_sql("
                SELECT
                       l.id,
                       l.course,
                       l.instructorchoiceacceptgrades,
                       t.enabledcapability,
                       t.toolproxyid,
                       tc.value AS acceptgrades
                  FROM {ebooklti} l
            INNER JOIN {grade_items} gt
                    ON l.id = gt.iteminstance
             LEFT JOIN {ebooklti_types} t
                    ON t.id = l.typeid
             LEFT JOIN {ebooklti_types_config} tc
                    ON tc.typeid = t.id AND tc.name = 'acceptgrades'
                 WHERE gt.itemmodule = 'ebooklti'
                   AND gt.itemtype = 'mod'
        ");

        foreach ($ebookltis as $ebooklti) {
            $acceptgrades = true;
            if (empty($ebooklti->toolproxyid)) {
                $typeacceptgrades = isset($ebooklti->acceptgrades) ? $ebooklti->acceptgrades : 2;
                if (!($typeacceptgrades == 1 ||
                        ($typeacceptgrades == 2 && $ebooklti->instructorchoiceacceptgrades == 1))) {
                    $acceptgrades = false;
                }
            } else {
                $enabledcapabilities = explode("\n", $ebooklti->enabledcapability);
                $acceptgrades = in_array('Result.autocreate', $enabledcapabilities);
            }

            if (!$acceptgrades) {
                // Required when doing CLI upgrade.
                require_once($CFG->libdir . '/gradelib.php');
                grade_update('mod/ebooklti', $ebooklti->course, 'mod', 'ebooklti', $ebooklti->id, 0, null, array('deleted' => 1));
            }

        }

        $ebookltis->close();

        upgrade_mod_savepoint(true, 2017111301, 'ebooklti');
    }

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.
	if ($oldversion < 2018051417) {

		$ebookltis = $DB->execute("update {ebooklti} set toolurl='' where toolurl is null");

        $table = new xmldb_table('ebooklti');        
		
		$field = new xmldb_field('custom_is_restricted_access', XMLDB_TYPE_INTEGER, '1', null, null, null, null, 'custom_course_idnumber');
		if (!$dbman->field_exists($table, $field)) {
			$dbman->add_field($table, $field);
		}
		
		$field = new xmldb_field('toolurl', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null, 'typeid');
        $dbman->change_field_type($table, $field);
		
		$field = new xmldb_field('grade', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '100', 'instructorchoiceacceptgrades');
        $dbman->change_field_type($table, $field);		
		
        $table2 = new xmldb_table('ebooklti_assessment_attempt');		
		$index = new xmldb_index('mdl_ebooasseatte_ebo_ix', XMLDB_INDEX_NOTUNIQUE, array('ebookltiid'));

        if (!$dbman->index_exists($table2, $index)) {
            $dbman->add_index($table2, $index);
        }
		
		$table3 = new xmldb_table('ebooklti_types');        
		
		$field = new xmldb_field('description', XMLDB_TYPE_TEXT, null, null, null, null, null, 'timemodified');
		if (!$dbman->field_exists($table3, $field)) {
			$dbman->add_field($table3, $field);
		}
		
		
		$table4 = new xmldb_table('ebooklti_types_config');
		$field = new xmldb_field('value', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null, 'name');
        $dbman->change_field_type($table4, $field);
		
        // ebooklti savepoint reached.
        upgrade_mod_savepoint(true, 2018051417, 'ebooklti');
    }

    return true;

}
