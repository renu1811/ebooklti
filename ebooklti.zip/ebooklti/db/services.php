<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External tool external functions and service definitions.
 *
 * @package    mod_ebooklti
 * @category   external
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @since      Moodle 3.0
 */

$functions = array(

    'mod_ebooklti_get_tool_launch_data' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'get_tool_launch_data',
        'description'   => 'Return the launch data for a given ebooklti external tool.',
        'type'          => 'read',
        'capabilities'  => 'mod/ebooklti:view',
        'ajax'          => true
    ),

    'mod_ebooklti_get_ebookltis_by_courses' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'get_ebookltis_by_courses',
        'description'   => 'Returns a list of ebooklti external tool instances in a provided set of courses, if
                            no courses are provided then all the ebooklti external tool instances the user has access to will be returned.',
        'type'          => 'read',
        'capabilities'  => 'mod/ebooklti:view',
        'ajax'          => true
    ),

    'mod_ebooklti_view_ebooklti' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'view_ebooklti',
        'description'   => 'Trigger the course module viewed event and update the module completion status.',
        'type'          => 'read',
        'capabilities'  => 'mod/ebooklti:view',
        'ajax'          => true
    ),

    'mod_ebooklti_get_tool_proxies' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'get_tool_proxies',
        'description'   => 'Get a list of the tool proxies',
        'type'          => 'read',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_create_tool_proxy' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'create_tool_proxy',
        'description'   => 'Create a tool proxy',
        'type'          => 'write',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_delete_tool_proxy' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'delete_tool_proxy',
        'description'   => 'Delete a tool proxy',
        'type'          => 'write',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_get_tool_proxy_registration_request' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'get_tool_proxy_registration_request',
        'description'   => 'Get a registration request for a tool proxy',
        'type'          => 'read',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_get_tool_types' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'get_tool_types',
        'description'   => 'Get a list of the tool types',
        'type'          => 'read',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_create_tool_type' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'create_tool_type',
        'description'   => 'Create a tool type',
        'type'          => 'write',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_update_tool_type' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'update_tool_type',
        'description'   => 'Update a tool type',
        'type'          => 'write',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_delete_tool_type' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'delete_tool_type',
        'description'   => 'Delete a tool type',
        'type'          => 'write',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),

    'mod_ebooklti_is_cartridge' => array(
        'classname'     => 'mod_ebooklti_external',
        'methodname'    => 'is_cartridge',
        'description'   => 'Determine if the given url is for a cartridge',
        'type'          => 'read',
        'capabilities'  => 'moodle/site:config',
        'ajax'          => true
    ),
    
    'ebooklti_grade_update' => array(         //web service function name
        'classname'   => 'mod_ebooklti_external',  //class containing the external function
        'methodname'  => 'update_grades',          //external function name
        'description' => 'ebook lti grade update.',    //human readable description of the web service function
        'type'        => 'write',                  //database rights of the web service function (read, write)
        'ajax'          => true
    ),
);

$services = array( 
    'ebooklti grade update' => array( 
        'functions' => array( 'ebooklti_grade_update' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_grade_update' 
    ),
    'Ebook Lti Is Cartridge' => array( 
        'functions' => array( 'mod_ebooklti_is_cartridge' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_is_cartridge' 
    ),
    'Ebook Lti Delete Tool Type' => array( 
        'functions' => array( 'mod_ebooklti_delete_tool_type' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_delete_tool_type' 
    ),
    'Ebook Lti Update Tool Type' => array( 
        'functions' => array( 'mod_ebooklti_update_tool_type' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_update_tool_type' 
    ),
    'Ebook Lti Create Tool Type' => array( 
        'functions' => array( 'mod_ebooklti_create_tool_type' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_create_tool_type' 
    ),
    'Ebook Lti Create Get Tool Type' => array( 
        'functions' => array( 'mod_ebooklti_get_tool_types' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'ebooklti_get_tool_types' 
    ),
    'Ebook Lti Get Tool Proxy Registration Request' => array( 
        'functions' => array( 'mod_ebooklti_get_tool_proxy_registration_request' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'get_tool_proxy_registration_request' 
    ),
    'Ebook Lti Delete Tool Proxy' => array( 
        'functions' => array( 'mod_ebooklti_delete_tool_proxy' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'delete_tool_proxt' 
    ),
    'Ebook Lti Create Tool Proxy' => array( 
        'functions' => array( 'mod_ebooklti_create_tool_proxy' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'create_tool_proxy' 
    ),
    'Ebook Lti Get Tool Proxies' => array( 
        'functions' => array( 'mod_ebooklti_get_tool_proxies' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'get_tool_proxies' 
    ),
     'Ebook Lti View Ebooklti' => array( 
        'functions' => array( 'mod_ebooklti_view_ebooklti' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'view_ebooklti' 
    ),
      'Ebook Lti Get Ebooklti Courses' => array( 
        'functions' => array( 'mod_ebooklti_get_ebookltis_by_courses' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'get_ebookltis_by_courses' 
    ), 
      'Ebook Lti Tool Launch Data' => array( 
        'functions' => array( 'mod_ebooklti_get_tool_launch_data' ), 
        'restrictedusers' => 1, 
        'enabled'=>1,
        'shortname'=>'get_tool_launch_data' 
    ),

);
