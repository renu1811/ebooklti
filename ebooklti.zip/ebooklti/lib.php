<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains a library of functions and constants for the ebooklti module
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

/**
 * Returns all other caps used in module.
 *
 * @return array
 */
function ebooklti_get_extra_capabilities() {
    return array('moodle/site:accessallgroups');
}

/**
 * List of features supported in URL module
 * @param string $feature FEATURE_xx constant for requested feature
 * @return mixed True if module supports feature, false if not, null if doesn't know
 */
function ebooklti_supports($feature) {
    switch ($feature) {
        case FEATURE_GROUPS:
        case FEATURE_GROUPINGS:
            return false;
        case FEATURE_MOD_INTRO:
        case FEATURE_COMPLETION_TRACKS_VIEWS:
        case FEATURE_GRADE_HAS_GRADE:
        case FEATURE_GRADE_OUTCOMES:
        case FEATURE_BACKUP_MOODLE2:
        case FEATURE_SHOW_DESCRIPTION:
            return true;

        default:
            return null;
    }
}

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod.html) this function
 * will create a new instance and return the id number
 * of the new instance.
 *
 * @param object $instance An object from the form in mod.html
 * @return int The id of the newly inserted basicebooklti record
 **/
function ebooklti_add_instance($ebooklti, $mform) {
    global $DB, $CFG, $COURSE;
    require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

    if (!isset($ebooklti->toolurl)) {
        $ebooklti->toolurl = '';
    }

    ebooklti_load_tool_if_cartridge($ebooklti);

    $ebooklti->timecreated = time();
    $ebooklti->timemodified = $ebooklti->timecreated;
    $ebooklti->servicesalt = uniqid('', true);
    /* Custom parameters start */
    $ebooklti->custom_course_idnumber = $COURSE->idnumber;
    $str_to_separate  = $ebooklti->custom_chapterorassessmentID_with_resourcelinkId;
    $separated = explode('||', $str_to_separate, 4);
    $ebooklti->custom_activity_type = $separated[0];
    $ebooklti->custom_unique_activity_id = $separated[1];
    $ebooklti->custom_resource_link_id = $separated[2];
    $ebooklti->grade = $separated[3];
    if($separated[0]=="chapter_media") {
       $ebooklti->icon = "/mod/ebooklti/pix/icon-media.svg";
    }  else {
       $ebooklti->icon = '';
    }
    /* Custom parameters end */
 
    if (!isset($ebooklti->typeid)) {
        $ebooklti->typeid = null;
    }

    ebooklti_force_type_config_settings($ebooklti, ebooklti_get_type_config_by_instance($ebooklti));

    if (empty($ebooklti->typeid) && isset($ebooklti->urlmatchedtypeid)) {
        $ebooklti->typeid = $ebooklti->urlmatchedtypeid;
    }

    if (!isset($ebooklti->instructorchoiceacceptgrades) || $ebooklti->instructorchoiceacceptgrades != EBOOKLTI_SETTING_ALWAYS) {
        // The instance does not accept grades back from the provider, so set to "No grade" value 0.
        $ebooklti->grade = 0;
    }

    $ebooklti->id = $DB->insert_record('ebooklti', $ebooklti);

    if (isset($ebooklti->instructorchoiceacceptgrades) && $ebooklti->instructorchoiceacceptgrades == EBOOKLTI_SETTING_ALWAYS) {
        if (!isset($ebooklti->cmidnumber)) {
            $ebooklti->cmidnumber = '';
        }
        // enter gradebook placeholder for only OpenPage2 assessments.
	if($separated[0]=="assessment") {//ONLY for OP2 assessment we will have grade placeholder
        $ebooklti->grade = $separated[3];
          ebooklti_grade_item_update($ebooklti);
	}
    }

    $completiontimeexpected = !empty($ebooklti->completionexpected) ? $ebooklti->completionexpected : null;
    \core_completion\api::update_completion_date_event($ebooklti->coursemodule, 'ebooklti', $ebooklti->id, $completiontimeexpected);

    return $ebooklti->id;
}

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod.html) this function
 * will update an existing instance with new data.
 *
 * @param object $instance An object from the form in mod.html
 * @return boolean Success/Fail
 **/
function ebooklti_update_instance($ebooklti, $mform) {
    global $DB, $CFG, $COURSE;
    require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

    ebooklti_load_tool_if_cartridge($ebooklti);
    /* Custom parameters start */
    $ebooklti->custom_course_idnumber = $COURSE->idnumber;
    $str_to_separate  = $ebooklti->custom_chapterorassessmentID_with_resourcelinkId;
    $separated = explode('||', $str_to_separate, 4);
    $ebooklti->custom_activity_type = $separated[0];
    $ebooklti->custom_unique_activity_id = $separated[1];
    $ebooklti->custom_resource_link_id = $separated[2];
    $ebooklti->grade = $separated[3];
    if($separated[0]=="chapter_media") {
       $ebooklti->icon = "/mod/ebooklti/pix/icon-media.svg";
    } else {
       $ebooklti->icon = '';
    }
    /* Custom parameters end */

    $ebooklti->timemodified = time();
    $ebooklti->id = $ebooklti->instance;

    if (!isset($ebooklti->showtitlelaunch)) {
        $ebooklti->showtitlelaunch = 0;
    }

    if (!isset($ebooklti->showdescriptionlaunch)) {
        $ebooklti->showdescriptionlaunch = 0;
    }

    ebooklti_force_type_config_settings($ebooklti, ebooklti_get_type_config_by_instance($ebooklti));

    if (isset($ebooklti->instructorchoiceacceptgrades) && $ebooklti->instructorchoiceacceptgrades == EBOOKLTI_SETTING_ALWAYS) {
        // enter gradebook placeholder for only OpenPage2 assessments.
	if($separated[0]=="assessment") { //ONLY for OP2 assessment we will have grade placeholder
        $ebooklti->grade = $separated[3];
          ebooklti_grade_item_update($ebooklti);
	}
    } else {
        // Instance is no longer accepting grades from Provider, set grade to "No grade" value 0.
        $ebooklti->grade = 0;
        $ebooklti->instructorchoiceacceptgrades = 0;

        ebooklti_grade_item_delete($ebooklti);
    }

	if(!property_exists($ebooklti,'typeid')){ $ebooklti->typeid = 0; }
    if ($ebooklti->typeid == 0 && isset($ebooklti->urlmatchedtypeid)) {
        $ebooklti->typeid = $ebooklti->urlmatchedtypeid;
    }

    $completiontimeexpected = !empty($ebooklti->completionexpected) ? $ebooklti->completionexpected : null;
    \core_completion\api::update_completion_date_event($ebooklti->coursemodule, 'ebooklti', $ebooklti->id, $completiontimeexpected);

    return $DB->update_record('ebooklti', $ebooklti);
}

/**
 * Given an ID of an instance of this module,
 * this function will permanently delete the instance
 * and any data that depends on it.
 *
 * @param int $id Id of the module instance
 * @return boolean Success/Failure
 **/
function ebooklti_delete_instance($id) {
    global $DB;

    if (! $basicebooklti = $DB->get_record("ebooklti", array("id" => $id))) {
        return false;
    }

    $result = true;

    // Delete any dependent records here.
    ebooklti_grade_item_delete($basicebooklti);

    $ebookltitype = $DB->get_record('ebooklti_types', array('id' => $basicebooklti->typeid));
    if ($ebookltitype) {
        $DB->delete_records('ebooklti_tool_settings',
            array('toolproxyid' => $ebookltitype->toolproxyid, 'course' => $basicebooklti->course, 'coursemoduleid' => $id));
    }

    $cm = get_coursemodule_from_instance('ebooklti', $id);
    \core_completion\api::update_completion_date_event($cm->id, 'ebooklti', $id, null);

    return $DB->delete_records("ebooklti", array("id" => $basicebooklti->id));
}

/**
 * Return aliases of this activity. ebookLTI should have an alias for each configured tool type
 * This is so you can add an ebooklti external tool types directly to the activity chooser
 *
 * @param stdClass $defaultitem default item that would be added to the activity chooser if this callback was not present.
 *     It has properties: archetype, name, title, help, icon, link
 * @return array An array of aliases for this activity. Each element is an object with same list of properties as $defaultitem,
 *     plus an additional property, helplink.
 *     Properties title and link are required
 **/
function ebooklti_get_shortcuts($defaultitem) {
    global $CFG, $COURSE;
    require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

    $types = ebooklti_get_configured_types($COURSE->id, $defaultitem->link->param('sr'));
    $types[] = $defaultitem;

    // Add items defined in ebookltisource plugins.
    foreach (core_component::get_plugin_list('ebookltisource') as $pluginname => $dir) {
        if ($moretypes = component_callback("ebookltisource_$pluginname", 'get_types')) {
            // Callback 'get_types()' in 'ebookltisource' plugins is deprecated in 3.1 and will be removed in 3.5, TODO MDL-53697.
            debugging('Deprecated callback get_types() is found in ebookltisource_' . $pluginname .
                ', use get_shortcuts() instead', DEBUG_DEVELOPER);
            $grouptitle = get_string('modulenameplural', 'mod_ebooklti');
            foreach ($moretypes as $subtype) {
                // Instead of adding subitems combine the name of the group with the name of the subtype.
                $subtype->title = get_string('activitytypetitle', '',
                    (object)['activity' => $grouptitle, 'type' => $subtype->typestr]);
                // Re-implement the logic of get_module_metadata() in Moodle 3.0 and below for converting
                // subtypes into items in activity chooser.
                $subtype->type = str_replace('&amp;', '&', $subtype->type);
                $subtype->name = preg_replace('/.*type=/', '', $subtype->type);
                $subtype->link = new moodle_url($defaultitem->link, array('type' => $subtype->name));
                if (empty($subtype->help) && !empty($subtype->name) &&
                        get_string_manager()->string_exists('help' . $subtype->name, $pluginname)) {
                    $subtype->help = get_string('help' . $subtype->name, $pluginname);
                }
                unset($subtype->typestr);
                $types[] = $subtype;
            }
        }
        // ebookLTISOURCE plugins can also implement callback get_shortcuts() to add items to the activity chooser.
        // The return values are the same as of the 'mod' callbacks except that $defaultitem is only passed for reference and
        // should not be added to the return value.
        if ($moretypes = component_callback("ebookltisource_$pluginname", 'get_shortcuts', array($defaultitem))) {
            $types = array_merge($types, $moretypes);
        }
    }
    return $types;
}

/**
 * Given a coursemodule object, this function returns the extra
 * information needed to print this activity in various places.
 * For this module we just need to support external urls as
 * activity icons
 *
 * @param stdClass $coursemodule
 * @return cached_cm_info info
 */
function ebooklti_get_coursemodule_info($coursemodule) {
    global $DB, $CFG;
    require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

    if (!$ebooklti = $DB->get_record('ebooklti', array('id' => $coursemodule->instance),
            'icon, secureicon, intro, introformat, name, typeid, toolurl, launchcontainer')) {
        return null;
    }

    $info = new cached_cm_info();

    if ($coursemodule->showdescription) {
        // Convert intro to html. Do not filter cached version, filters run at display time.
        $info->content = format_module_intro('ebooklti', $ebooklti, $coursemodule->id, false);
    }

    if (!empty($ebooklti->typeid)) {
        $toolconfig = ebooklti_get_type_config($ebooklti->typeid);
    } else if ($tool = ebooklti_get_tool_by_url_match($ebooklti->toolurl)) {
        $toolconfig = ebooklti_get_type_config($tool->id);
    } else {
        $toolconfig = array();
    }

    // We want to use the right icon based on whether the
    // current page is being requested over http or https.
    if (ebooklti_request_is_using_ssl() &&
        (!empty($ebooklti->secureicon) || (isset($toolconfig['secureicon']) && !empty($toolconfig['secureicon'])))) {
        if (!empty($ebooklti->secureicon)) {
            $info->iconurl = new moodle_url($ebooklti->secureicon);
        } else {
            $info->iconurl = new moodle_url($toolconfig['secureicon']);
        }
    } else if (!empty($ebooklti->icon)) {
        $info->iconurl = new moodle_url($ebooklti->icon);
    } else if (isset($toolconfig['icon']) && !empty($toolconfig['icon'])) {
        $info->iconurl = new moodle_url($toolconfig['icon']);
    }

    // Does the link open in a new window?
    $launchcontainer = ebooklti_get_launch_container($ebooklti, $toolconfig);
    if ($launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_WINDOW) {
        $launchurl = new moodle_url('/mod/ebooklti/launch.php', array('id' => $coursemodule->id));
        $info->onclick = "window.open('" . $launchurl->out(false) . "', 'ebooklti-".$coursemodule->id."'); return false;";
    }

    $info->name = $ebooklti->name;

    return $info;
}

/**
 * Return a small object with summary information about what a
 * user has done with a given particular instance of this module
 * Used for user activity reports.
 * $return->time = the time they did it
 * $return->info = a short text description
 *
 * @return null
 * @TODO: implement this moodle function (if needed)
 **/
function ebooklti_user_outline($course, $user, $mod, $basicebooklti) {
    return null;
}

/**
 * Print a detailed representation of what a user has done with
 * a given particular instance of this module, for user activity reports.
 *
 * @return boolean
 * @TODO: implement this moodle function (if needed)
 **/
function ebooklti_user_complete($course, $user, $mod, $basicebooklti) {
    return true;
}

/**
 * Given a course and a time, this module should find recent activity
 * that has occurred in basicebooklti activities and print it out.
 * Return true if there was output, or false is there was none.
 *
 * @uses $CFG
 * @return boolean
 * @TODO: implement this moodle function
 **/
function ebooklti_print_recent_activity($course, $isteacher, $timestart) {
    return false;  //  True if anything was printed, otherwise false.
}

/**
 * Function to be run periodically according to the moodle cron
 * This function searches for things that need to be done, such
 * as sending out mail, toggling flags etc ...
 *
 * @uses $CFG
 * @return boolean
 **/
function ebooklti_cron () {
    return true;
}

/**
 * Must return an array of grades for a given instance of this module,
 * indexed by user.  It also returns a maximum allowed grade.
 *
 * Example:
 *    $return->grades = array of grades;
 *    $return->maxgrade = maximum allowed grade;
 *
 *    return $return;
 *
 * @param int $basicebookltiid ID of an instance of this module
 * @return mixed Null or object with an array of grades and with the maximum grade
 *
 * @TODO: implement this moodle function (if needed)
 **/
function ebooklti_grades($basicebookltiid) {
    return null;
}

/**
 * This function returns if a scale is being used by one basicebooklti
 * it it has support for grading and scales. Commented code should be
 * modified if necessary. See forum, glossary or journal modules
 * as reference.
 *
 * @param int $basicebookltiid ID of an instance of this module
 * @return mixed
 *
 * @TODO: implement this moodle function (if needed)
 **/
function ebooklti_scale_used ($basicebookltiid, $scaleid) {
    $return = false;

    // $rec = get_record("basicebooklti","id","$basicebookltiid","scale","-$scaleid");
    //
    // if (!empty($rec)  && !empty($scaleid)) {
    //     $return = true;
    // }

    return $return;
}

/**
 * Checks if scale is being used by any instance of basicebooklti.
 * This function was added in 1.9
 *
 * This is used to find out if scale used anywhere
 * @param $scaleid int
 * @return boolean True if the scale is used by any basicebooklti
 *
 */
function ebooklti_scale_used_anywhere($scaleid) {
    global $DB;

    if ($scaleid and $DB->record_exists('ebooklti', array('grade' => -$scaleid))) {
        return true;
    } else {
        return false;
    }
}

/**
 * Execute post-install custom actions for the module
 * This function was added in 1.9
 *
 * @return boolean true if success, false on error
 */
function ebooklti_install() {
     return true;
}

/**
 * Execute post-uninstall custom actions for the module
 * This function was added in 1.9
 *
 * @return boolean true if success, false on error
 */
function ebooklti_uninstall() {
    return true;
}

/**
 * Returns available Basic EBOOKLTI types
 *
 * @return array of BasicEBOOKLTI types
 */
function ebooklti_get_ebooklti_types() {
    global $DB;

    return $DB->get_records('ebooklti_types', null, 'state DESC, timemodified DESC');
}

/**
 * Returns available Basic EBOOKLTI types that match the given
 * tool proxy id
 *
 * @param int $toolproxyid Tool proxy id
 * @return array of BasicEBOOKLTI types
 */
function ebooklti_get_ebooklti_types_from_proxy_id($toolproxyid) {
    global $DB;

    return $DB->get_records('ebooklti_types', array('toolproxyid' => $toolproxyid), 'state DESC, timemodified DESC');
}

/**
 * Create grade item for given basicebooklti
 *
 * @category grade
 * @param object $basicebooklti object with extra cmidnumber
 * @param mixed optional array/object of grade(s); 'reset' means reset grades in gradebook
 * @return int 0 if ok, error code otherwise
 */
function ebooklti_grade_item_update($basicebooklti, $grades = null) {
    global $CFG;
    require_once($CFG->libdir.'/gradelib.php');
    require_once($CFG->dirroot.'/mod/ebooklti/servicelib.php');

    if (!ebooklti_accepts_grades($basicebooklti)) {
        return 0;
    }

    $params = array('itemname' => $basicebooklti->name, 'idnumber' => $basicebooklti->cmidnumber);

    if ($basicebooklti->grade > 0) {
        $params['gradetype'] = GRADE_TYPE_VALUE;
        $params['grademax']  = $basicebooklti->grade;
        $params['grademin']  = 0;

    } else if ($basicebooklti->grade < 0) {
        $params['gradetype'] = GRADE_TYPE_SCALE;
        $params['scaleid']   = -$basicebooklti->grade;

    } else {
        $params['gradetype'] = GRADE_TYPE_TEXT; // Allow text comments only.
    }

    if ($grades === 'reset') {
        $params['reset'] = true;
        $grades = null;
    }

    return grade_update('mod/ebooklti', $basicebooklti->course, 'mod', 'ebooklti', $basicebooklti->id, 0, $grades, $params);
}

/**
 * Update activity grades
 *
 * @param stdClass $basicebooklti The EBOOKLTI instance
 * @param int      $userid Specific user only, 0 means all.
 * @param bool     $nullifnone Not used
 */
function ebooklti_update_grades($basicebooklti, $userid=0, $nullifnone=true) {
    global $CFG;
    require_once($CFG->dirroot.'/mod/ebooklti/servicelib.php');

    $str_to_separate  = $basicebooklti->custom_chapterorassessmentID_with_resourcelinkId;
    $separated = explode('||', $str_to_separate, 4);
    $basicebooklti->custom_activity_type = $separated[0];
    $basicebooklti->custom_unique_activity_id = $separated[1];
    $basicebooklti->custom_resource_link_id = $separated[2];
    $basicebooklti->grade = $separated[3];

    // EBOOKLTI doesn't have its own grade table so the only thing to do is update the grade item.
    if (ebooklti_accepts_grades($basicebooklti)) {
        if($separated[0]=="assessment") {//ONLY for OP2 assessment we will have grade placeholder
            $basicebooklti->grade = $separated[3];
            ebooklti_grade_item_update($basicebooklti);
        }
    }
}

/**
 * Delete grade item for given basicebooklti
 *
 * @category grade
 * @param object $basicebooklti object
 * @return object basicebooklti
 */
function ebooklti_grade_item_delete($basicebooklti) {
    global $CFG;
    require_once($CFG->libdir.'/gradelib.php');

    return grade_update('mod/ebooklti', $basicebooklti->course, 'mod', 'ebooklti', $basicebooklti->id, 0, null, array('deleted' => 1));
}

/**
 * Log post actions
 *
 * @return array
 */
function ebooklti_get_post_actions() {
    return array();
}

/**
 * Log view actions
 *
 * @return array
 */
function ebooklti_get_view_actions() {
    return array('view all', 'view');
}

/**
 * Mark the activity completed (if required) and trigger the course_module_viewed event.
 *
 * @param  stdClass $ebooklti        ebooklti object
 * @param  stdClass $course     course object
 * @param  stdClass $cm         course module object
 * @param  stdClass $context    context object
 * @since Moodle 3.0
 */
function ebooklti_view($ebooklti, $course, $cm, $context) {

    // Trigger course_module_viewed event.
    $params = array(
        'context' => $context,
        'objectid' => $ebooklti->id
    );

    $event = \mod_ebooklti\event\course_module_viewed::create($params);
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('ebooklti', $ebooklti);
    $event->trigger();

    // Completion.
    $completion = new completion_info($course);
    $completion->set_module_viewed($cm);
}

/**
 * Check if the module has any update that affects the current user since a given time.
 *
 * @param  cm_info $cm course module data
 * @param  int $from the time to check updates from
 * @param  array $filter  if we need to check only specific updates
 * @return stdClass an object with the different type of areas indicating if they were updated or not
 * @since Moodle 3.2
 */
function ebooklti_check_updates_since(cm_info $cm, $from, $filter = array()) {
    global $DB, $USER;

    $updates = course_check_module_updates_since($cm, $from, array(), $filter);

    // Check if there is a new submission.
    $updates->submissions = (object) array('updated' => false);
    $select = 'ebookltiid = :id AND userid = :userid AND (datesubmitted > :since1 OR dateupdated > :since2)';
    $params = array('id' => $cm->instance, 'userid' => $USER->id, 'since1' => $from, 'since2' => $from);
    $submissions = $DB->get_records_select('ebooklti_submission', $select, $params, '', 'id');
    if (!empty($submissions)) {
        $updates->submissions->updated = true;
        $updates->submissions->itemids = array_keys($submissions);
    }

    // Now, teachers should see other students updates.
    if (has_capability('mod/ebooklti:manage', $cm->context)) {
        $select = 'ebookltiid = :id AND (datesubmitted > :since1 OR dateupdated > :since2)';
        $params = array('id' => $cm->instance, 'since1' => $from, 'since2' => $from);

        if (groups_get_activity_groupmode($cm) == SEPARATEGROUPS) {
            $groupusers = array_keys(groups_get_activity_shared_group_members($cm));
            if (empty($groupusers)) {
                return $updates;
            }
            list($insql, $inparams) = $DB->get_in_or_equal($groupusers, SQL_PARAMS_NAMED);
            $select .= ' AND userid ' . $insql;
            $params = array_merge($params, $inparams);
        }

        $updates->usersubmissions = (object) array('updated' => false);
        $submissions = $DB->get_records_select('ebooklti_submission', $select, $params, '', 'id');
        if (!empty($submissions)) {
            $updates->usersubmissions->updated = true;
            $updates->usersubmissions->itemids = array_keys($submissions);
        }
    }

    return $updates;
}

/**
 * Get icon mapping for font-awesome.
 */
function mod_ebooklti_get_fontawesome_icon_map() {
    return [
        'mod_ebooklti:warning' => 'fa-exclamation text-warning',
    ];
}

/**
 * This function receives a calendar event and returns the action associated with it, or null if there is none.
 *
 * This is used by block_myoverview in order to display the event appropriately. If null is returned then the event
 * is not displayed on the block.
 *
 * @param calendar_event $event
 * @param \core_calendar\action_factory $factory
 * @return \core_calendar\local\event\entities\action_interface|null
 */
function mod_ebooklti_core_calendar_provide_event_action(calendar_event $event,
                                                      \core_calendar\action_factory $factory) {
    $cm = get_fast_modinfo($event->courseid)->instances['ebooklti'][$event->instance];

    $completion = new \completion_info($cm->get_course());

    $completiondata = $completion->get_data($cm, false);

    if ($completiondata->completionstate != COMPLETION_INCOMPLETE) {
        return null;
    }

    return $factory->create_instance(
        get_string('view'),
        new \moodle_url('/mod/ebooklti/view.php', ['id' => $cm->id]),
        1,
        true
    );
}