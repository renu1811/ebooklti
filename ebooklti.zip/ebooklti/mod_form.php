<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file defines the main ebooklti configuration form
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot . '/course/moodleform_mod.php');
require_once($CFG->dirroot . '/mod/ebooklti/locallib.php');

class mod_ebooklti_mod_form extends moodleform_mod {

    public function definition() {
        global $PAGE, $OUTPUT, $COURSE;

        if ($type = optional_param('type', false, PARAM_ALPHA)) {
            component_callback("ebookltisource_$type", 'add_instance_hook');
        }

        $this->typeid = 0;
        /* Custom parameters start */
        if (isset($this)) {
            if(isset($this->_cm)) {
                $cmid_for_edit = $this->_cm->id;
                $context = context_module::instance($this->_cm->id);
                require_capability('mod/ebooklti:addinstance', $context, NULL, true, 'noeditpermission', 'ebooklti');
            }

            $subObj = new \stdclass;
            $subObj = $this->current;
            if (isset($subObj->custom_activity_type)) {
                $selected_custom_activity_type = $subObj->custom_activity_type;
            }
            if (isset($subObj->custom_resource_link_id)) {
                $selected_custom_resource_link_id = $subObj->custom_resource_link_id;
            }
            if (isset($subObj->custom_unique_activity_id)) {
                $selected_custom_unique_activity_id = $subObj->custom_unique_activity_id;
            }
            if (isset($subObj->grade)) {
                $selected_grade_max = $subObj->grade;
            }
            if (isset($selected_custom_activity_type) && isset($selected_custom_resource_link_id) && isset($selected_custom_unique_activity_id) && isset($selected_grade_max)) {
                $selecteddropdownvalue = $selected_custom_activity_type . "||" . $selected_custom_unique_activity_id . "||" . $selected_custom_resource_link_id . "||" . $selected_grade_max;
            } else {
                $selecteddropdownvalue = '';
            }
        }
        /* Custom parameters end  */

        $mform =& $this->_form;
        // Adding the "general" fieldset, where all the common settings are shown.
        $mform->addElement('header', 'general', get_string('general', 'form'));
        // Adding the standard "name" field.
        $mform->addElement('text', 'name', get_string('basicebookltiname', 'ebooklti'), array('size' => '64'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');
        // Adding the optional "intro" and "introformat" pair of fields.
        $this->standard_intro_elements(get_string('basicebookltiintro', 'ebooklti'));
        $mform->setAdvanced('introeditor');

        // Display the label to the right of the checkbox so it looks better & matches rest of the form.
        if ($mform->elementExists('showdescription')) {
            $coursedesc = $mform->getElement('showdescription');
            if (!empty($coursedesc)) {
                $coursedesc->setText(' ' . $coursedesc->getLabel());
                $coursedesc->setLabel('&nbsp');
            }
        }

        $mform->setAdvanced('showdescription');

        $mform->addElement('checkbox', 'showtitlelaunch', '&nbsp;', ' ' . get_string('display_name', 'ebooklti'));
        $mform->setAdvanced('showtitlelaunch');
        $mform->setDefault('showtitlelaunch', true);
        $mform->addHelpButton('showtitlelaunch', 'display_name', 'ebooklti');

        $mform->addElement('checkbox', 'showdescriptionlaunch', '&nbsp;', ' ' . get_string('display_description', 'ebooklti'));
        $mform->setAdvanced('showdescriptionlaunch');
        $mform->addHelpButton('showdescriptionlaunch', 'display_description', 'ebooklti');
	/*
        // Tool settings.
        $tooltypes = $mform->addElement('select', 'typeid', get_string('external_tool_type', 'ebooklti'));
        // Type ID parameter being passed when adding an preconfigured tool from activity chooser.
        $typeid = optional_param('typeid', false, PARAM_INT);
        if ($typeid) {
            $mform->getElement('typeid')->setValue($typeid);
        }
        $mform->addHelpButton('typeid', 'external_tool_type', 'ebooklti');
        $toolproxy = array();

        // Array of tool type IDs that don't support ContentItemSelectionRequest.
        $noncontentitemtypes = [];

        foreach (ebooklti_get_types_for_add_instance() as $id => $type) {
            if (!empty($type->toolproxyid)) {
                $toolproxy[] = $type->id;
                $attributes = array( 'globalTool' => 1, 'toolproxy' => 1);
                $enabledcapabilities = explode("\n", $type->enabledcapability);
                if (!in_array('Result.autocreate', $enabledcapabilities)) {
                    $attributes['nogrades'] = 1;
                }
                if (!in_array('Person.name.full', $enabledcapabilities) && !in_array('Person.name.family', $enabledcapabilities) &&
                    !in_array('Person.name.given', $enabledcapabilities)) {
                    $attributes['noname'] = 1;
                }
                if (!in_array('Person.email.primary', $enabledcapabilities)) {
                    $attributes['noemail'] = 1;
                }
            } else if ($type->course == $COURSE->id) {
                $attributes = array( 'editable' => 1, 'courseTool' => 1, 'domain' => $type->tooldomain );
            } else if ($id != 0) {
                $attributes = array( 'globalTool' => 1, 'domain' => $type->tooldomain);
            } else {
                $attributes = array();
            }

            if ($id) {
                $config = ebooklti_get_type_config($id);
                if (!empty($config['contentitem'])) {
                    $attributes['data-contentitem'] = 1;
                    $attributes['data-id'] = $id;
                } else {
                    $noncontentitemtypes[] = $id;
                }
            }
            $tooltypes->addOption($type->name, $id, $attributes);
        }

        // Add button that launches the content-item selection dialogue.
        // Set contentitem URL.
        $contentitemurl = new moodle_url('/mod/ebooklti/contentitem.php');
        $contentbuttonattributes = [
            'data-contentitemurl' => $contentitemurl->out(false)
        ];
        $contentbuttonlabel = get_string('selectcontent', 'ebooklti');
        $contentbutton = $mform->addElement('button', 'selectcontent', $contentbuttonlabel, $contentbuttonattributes);
        // Disable select content button if the selected tool doesn't support content item or it's set to Automatic.
        $allnoncontentitemtypes = $noncontentitemtypes;
        $allnoncontentitemtypes[] = '0'; // Add option value for "Automatic, based on tool URL".
        $mform->disabledIf('selectcontent', 'typeid', 'in', $allnoncontentitemtypes);

        $mform->addElement('text', 'toolurl', get_string('launch_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('toolurl', PARAM_URL);
        $mform->addHelpButton('toolurl', 'launch_url', 'ebooklti');
        $mform->disabledIf('toolurl', 'typeid', 'in', $noncontentitemtypes);

        $mform->addElement('text', 'securetoolurl', get_string('secure_launch_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('securetoolurl', PARAM_URL);
        $mform->setAdvanced('securetoolurl');
        $mform->addHelpButton('securetoolurl', 'secure_launch_url', 'ebooklti');
        $mform->disabledIf('securetoolurl', 'typeid', 'in', $noncontentitemtypes);

        $mform->addElement('hidden', 'urlmatchedtypeid', '', array( 'id' => 'id_urlmatchedtypeid' ));
        $mform->setType('urlmatchedtypeid', PARAM_INT);
	*/
	/* Custom parameters start */
        $ebookCH_ASS_list = ebooklti_get_list_ofchpaterandassessment();
        $selectchapterorassessmentID = $mform->addElement('select', 'custom_chapterorassessmentID_with_resourcelinkId', get_string('custom_chapterorassessment_id', 'ebooklti'), $ebookCH_ASS_list, 'size="20"');
        $selectchapterorassessmentID->setSelected($selecteddropdownvalue);
        $mform->addRule('custom_chapterorassessmentID_with_resourcelinkId', null, 'required', null, 'client');

        $radio = array();
        $radio[] = $mform->createElement('radio', 'custom_is_restricted_access', '', get_string('yes'), 1);
        $radio[] = $mform->createElement('radio', 'custom_is_restricted_access', '', get_string('no'), 0);
        $custom_is_restricted_access = $mform->addGroup($radio, 'custom_is_restricted_access', get_string('custom_is_restricted_access', 'ebooklti'), '', false);
        $mform->addRule('custom_is_restricted_access', null, 'required', null, 'client');
        /* Custom parameters end */
	
        $launchoptions = array();
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_DEFAULT] = get_string('default', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_EMBED] = get_string('embed', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS] = get_string('embed_no_blocks', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW] = get_string('existing_window', 'ebooklti');
        $launchoptions[EBOOKLTI_LAUNCH_CONTAINER_WINDOW] = get_string('new_window', 'ebooklti');

        $mform->addElement('select', 'launchcontainer', get_string('launchinpopup', 'ebooklti'), $launchoptions);
        $mform->setDefault('launchcontainer', EBOOKLTI_LAUNCH_CONTAINER_WINDOW);
        $mform->addHelpButton('launchcontainer', 'launchinpopup', 'ebooklti');
        $mform->setAdvanced('launchcontainer');
	/*
        $mform->addElement('text', 'resourcekey', get_string('resourcekey', 'ebooklti'));
        $mform->setType('resourcekey', PARAM_TEXT);
        $mform->setAdvanced('resourcekey');
        $mform->addHelpButton('resourcekey', 'resourcekey', 'ebooklti');
        $mform->setForceLtr('resourcekey');
        $mform->disabledIf('resourcekey', 'typeid', 'in', $noncontentitemtypes);

        $mform->addElement('passwordunmask', 'password', get_string('password', 'ebooklti'));
        $mform->setType('password', PARAM_TEXT);
        $mform->setAdvanced('password');
        $mform->addHelpButton('password', 'password', 'ebooklti');
        $mform->disabledIf('password', 'typeid', 'in', $noncontentitemtypes);

        $mform->addElement('textarea', 'instructorcustomparameters', get_string('custom', 'ebooklti'), array('rows' => 4, 'cols' => 60));
        $mform->setType('instructorcustomparameters', PARAM_TEXT);
        $mform->setAdvanced('instructorcustomparameters');
        $mform->addHelpButton('instructorcustomparameters', 'custom', 'ebooklti');
        $mform->setForceLtr('instructorcustomparameters');

        $mform->addElement('text', 'icon', get_string('icon_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('icon', PARAM_URL);
        $mform->setAdvanced('icon');
        $mform->addHelpButton('icon', 'icon_url', 'ebooklti');
        $mform->disabledIf('icon', 'typeid', 'in', $noncontentitemtypes);

        $mform->addElement('text', 'secureicon', get_string('secure_icon_url', 'ebooklti'), array('size' => '64'));
        $mform->setType('secureicon', PARAM_URL);
        $mform->setAdvanced('secureicon');
        $mform->addHelpButton('secureicon', 'secure_icon_url', 'ebooklti');
        $mform->disabledIf('secureicon', 'typeid', 'in', $noncontentitemtypes);
	*/
        // Add privacy preferences fieldset where users choose whether to send their data.
        $mform->addElement('header', 'privacy', get_string('privacy', 'ebooklti'));

        $mform->addElement('advcheckbox', 'instructorchoicesendname', '&nbsp;', ' ' . get_string('share_name', 'ebooklti'));
        $mform->setDefault('instructorchoicesendname', '1');
        $mform->addHelpButton('instructorchoicesendname', 'share_name', 'ebooklti');
        //$mform->disabledIf('instructorchoicesendname', 'typeid', 'in', $toolproxy);

        $mform->addElement('advcheckbox', 'instructorchoicesendemailaddr', '&nbsp;', ' ' . get_string('share_email', 'ebooklti'));
        $mform->setDefault('instructorchoicesendemailaddr', '1');
        $mform->addHelpButton('instructorchoicesendemailaddr', 'share_email', 'ebooklti');
        //$mform->disabledIf('instructorchoicesendemailaddr', 'typeid', 'in', $toolproxy);

        $mform->addElement('advcheckbox', 'instructorchoiceacceptgrades', '&nbsp;', ' ' . get_string('accept_grades', 'ebooklti'));
        $mform->setDefault('instructorchoiceacceptgrades', '0');
        $mform->addHelpButton('instructorchoiceacceptgrades', 'accept_grades', 'ebooklti');
        //$mform->disabledIf('instructorchoiceacceptgrades', 'typeid', 'in', $toolproxy);

        // Add standard course module grading elements.
        $this->standard_grading_coursemodule_elements();

        // Add standard elements, common to all modules.
        $this->standard_coursemodule_elements();
        $mform->setAdvanced('cmidnumber');

        // Add standard buttons, common to all modules.
        $this->add_action_buttons();

        $editurl = new moodle_url('/mod/ebooklti/instructor_edit_tool_type.php',
                array('sesskey' => sesskey(), 'course' => $COURSE->id));
        $ajaxurl = new moodle_url('/mod/ebooklti/ajax.php');

        // All these icon uses are incorrect. EBOOKLTI JS needs updating to use AMD modules and templates so it can use
        // the mustache pix helper - until then EBOOKLTI will have inconsistent icons.
        $jsinfo = (object)array(
                        'edit_icon_url' => (string)$OUTPUT->image_url('t/edit'),
                        'add_icon_url' => (string)$OUTPUT->image_url('t/add'),
                        'delete_icon_url' => (string)$OUTPUT->image_url('t/delete'),
                        'green_check_icon_url' => (string)$OUTPUT->image_url('i/valid'),
                        'warning_icon_url' => (string)$OUTPUT->image_url('warning', 'ebooklti'),
                        'instructor_tool_type_edit_url' => $editurl->out(false),
                        'ajax_url' => $ajaxurl->out(true),
                        'courseId' => $COURSE->id
                  );

        $module = array(
            'name' => 'mod_ebooklti_edit',
            'fullpath' => '/mod/ebooklti/mod_form.js',
            'requires' => array('base', 'io', 'querystring-stringify-simple', 'node', 'event', 'json-parse'),
            'strings' => array(
                array('addtype', 'ebooklti'),
                array('edittype', 'ebooklti'),
                array('deletetype', 'ebooklti'),
                array('delete_confirmation', 'ebooklti'),
                array('cannot_edit', 'ebooklti'),
                array('cannot_delete', 'ebooklti'),
                array('global_tool_types', 'ebooklti'),
                array('course_tool_types', 'ebooklti'),
                array('using_tool_configuration', 'ebooklti'),
                array('using_tool_cartridge', 'ebooklti'),
                array('domain_mismatch', 'ebooklti'),
                array('custom_config', 'ebooklti'),
                array('tool_config_not_found', 'ebooklti'),
                array('tooltypeadded', 'ebooklti'),
                array('tooltypedeleted', 'ebooklti'),
                array('tooltypenotdeleted', 'ebooklti'),
                array('tooltypeupdated', 'ebooklti'),
                array('forced_help', 'ebooklti')
            ),
        );

        if (!empty($typeid)) {
            $mform->setAdvanced('typeid');
            $mform->setAdvanced('toolurl');
        }

        $PAGE->requires->js_init_call('M.mod_ebooklti.editor.init', array(json_encode($jsinfo)), true, $module);
    }

}
