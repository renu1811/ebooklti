<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains all necessary code to view a ebooklti activity instance
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once("../../config.php");
require_once($CFG->dirroot.'/mod/ebooklti/lib.php');
require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

$id = required_param('id', PARAM_INT); // Course Module ID.
$triggerview = optional_param('triggerview', 1, PARAM_BOOL);

$cm = get_coursemodule_from_id('ebooklti', $id, 0, false, MUST_EXIST);
$ebooklti = $DB->get_record('ebooklti', array('id' => $cm->instance), '*', MUST_EXIST);
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

$context = context_module::instance($cm->id);

require_login($course, true, $cm);
require_capability('mod/ebooklti:view', $context);

/* Custom parameters start */
$ebooklti->toolurl = $CFG->op2_launch_url;
$ebooklti->resourcekey = $CFG->op2_consumer_key;
$ebooklti->password = $CFG->op2_shared_secret;
$ebooklti->cmid = $cm->id;

$id_number = $course->idnumber;
$custom_person_id = $USER->username;  //getting from moodle mdl_user.username;

// Get OCIPID
$ocp_id = ebooklti_get_ocpid($custom_person_id,$id_number);
//echo $ocp_id;

// Get Expiry Date
$custom_expiry_date = ebooklti_get_expirydate($ocp_id);  //getting from JBL/UCS
//echo $custom_expiry_date;
//$custom_expiry_date = '1514764800';


/* Instead of EBOOKLTI  core resource_link_id parameter, custom_resource_link_id is being used for excelsoft op2 integration
   EBOOKLTI core resource_link_id parameter is an auto-generated activity id of moodle. But custom_resource_link_id is an unique GUID of ebook OR ebook chapter OR ebook assessment. 
*/

$custom_resource_link_id= $ebooklti->custom_resource_link_id;  //getting from op2 via WS 
$custom_course_idnumber = $ebooklti->custom_course_idnumber;   //getting from moodle mdl_course.idnumber;
$custom_is_restricted_access = $ebooklti->custom_is_restricted_access; 

$ebooklti->instructorcustomparameters= "expiry_date="        .$custom_expiry_date.
                                       "\ncourse_id="  .$custom_course_idnumber.
                                       "\nperson_id="        .$custom_person_id.
				       "\nresource_link_id=" .$custom_resource_link_id.
                                       "\nis_restricted_access=" .$custom_is_restricted_access;
//echo "<pre>";
//var_dump($ebooklti);
//exit;

/* Custom parameters end  */

// Completion and trigger events.
if ($triggerview) {
    ebooklti_view($ebooklti, $course, $cm, $context);
}

$ebooklti->cmid = $cm->id;
ebooklti_launch_tool($ebooklti);

