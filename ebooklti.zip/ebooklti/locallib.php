<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of Basicebooklti4Moodle
//
// Basicebooklti4Moodle is an IMS Basicebooklti (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. Basicebooklti is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS Basicebooklti
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support Basicebooklti. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// Basicebooklti4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// Simpleebooklti consumer for Moodle is an implementation of the early specification of ebooklti
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// Basicebooklti4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains the library of functions and constants for the ebooklti module
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

// TODO: Switch to core oauthlib once implemented - MDL-30149.
use moodle\mod\ebooklti as ebooklti;

global $CFG;
require_once($CFG->dirroot.'/mod/ebooklti/OAuth.php');
require_once($CFG->libdir.'/weblib.php');
require_once($CFG->dirroot . '/course/modlib.php');
require_once($CFG->dirroot . '/mod/ebooklti/TrivialStore.php');
require_once($CFG->libdir . '/jbl_api/jblapirestcurl.php');

define('EBOOKLTI_URL_DOMAIN_REGEX', '/(?:https?:\/\/)?(?:www\.)?([^\/]+)(?:\/|$)/i');

define('EBOOKLTI_LAUNCH_CONTAINER_DEFAULT', 1);
define('EBOOKLTI_LAUNCH_CONTAINER_EMBED', 2);
define('EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS', 3);
define('EBOOKLTI_LAUNCH_CONTAINER_WINDOW', 4);
define('EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW', 5);

define('EBOOKLTI_TOOL_STATE_ANY', 0);
define('EBOOKLTI_TOOL_STATE_CONFIGURED', 1);
define('EBOOKLTI_TOOL_STATE_PENDING', 2);
define('EBOOKLTI_TOOL_STATE_REJECTED', 3);
define('EBOOKLTI_TOOL_PROXY_TAB', 4);

define('EBOOKLTI_TOOL_PROXY_STATE_CONFIGURED', 1);
define('EBOOKLTI_TOOL_PROXY_STATE_PENDING', 2);
define('EBOOKLTI_TOOL_PROXY_STATE_ACCEPTED', 3);
define('EBOOKLTI_TOOL_PROXY_STATE_REJECTED', 4);

define('EBOOKLTI_SETTING_NEVER', 0);
define('EBOOKLTI_SETTING_ALWAYS', 1);
define('EBOOKLTI_SETTING_DELEGATE', 2);

define('EBOOKLTI_COURSEVISIBLE_NO', 0);
define('EBOOKLTI_COURSEVISIBLE_PRECONFIGURED', 1);
define('EBOOKLTI_COURSEVISIBLE_ACTIVITYCHOOSER', 2);

define('EBOOKLTI_VERSION_1', 'LTI-1p0');
define('EBOOKLTI_VERSION_2', 'LTI-2p0');

/**
 * Return the launch data required for opening the ebooklti external tool.
 *
 * @param  stdClass $instance the ebooklti external tool activity settings
 * @return array the endpoint URL and parameters (including the signature)
 * @since  Moodle 3.0
 */
function ebooklti_get_launch_data($instance) {
    global $PAGE, $CFG, $USER;

    if (empty($instance->typeid)) {
        $tool = ebooklti_get_tool_by_url_match($instance->toolurl, $instance->course);
        if ($tool) {
            $typeid = $tool->id;
        } else {
            $tool = ebooklti_get_tool_by_url_match($instance->securetoolurl,  $instance->course);
            if ($tool) {
                $typeid = $tool->id;
            } else {
                $typeid = null;
            }
        }
    } else {
        $typeid = $instance->typeid;
        $tool = ebooklti_get_type($typeid);
    }

    if ($typeid) {
        $typeconfig = ebooklti_get_type_config($typeid);
    } else {
        // There is no admin configuration for this tool. Use configuration in the ebooklti instance record plus some defaults.
        $typeconfig = (array)$instance;

        $typeconfig['sendname'] = $instance->instructorchoicesendname;
        $typeconfig['sendemailaddr'] = $instance->instructorchoicesendemailaddr;
        $typeconfig['customparameters'] = $instance->instructorcustomparameters;
        $typeconfig['acceptgrades'] = $instance->instructorchoiceacceptgrades;
        $typeconfig['allowroster'] = $instance->instructorchoiceallowroster;
        $typeconfig['forcessl'] = '0';
    }

    // Default the organizationid if not specified.
    if (empty($typeconfig['organizationid'])) {
        $urlparts = parse_url($CFG->wwwroot);

        $typeconfig['organizationid'] = $urlparts['host'];
    }

    if (isset($tool->toolproxyid)) {
        $toolproxy = ebooklti_get_tool_proxy($tool->toolproxyid);
        $key = $toolproxy->guid;
        $secret = $toolproxy->secret;
    } else {
        $toolproxy = null;
        if (!empty($instance->resourcekey)) {
            $key = $instance->resourcekey;
        } else if (!empty($typeconfig['resourcekey'])) {
            $key = $typeconfig['resourcekey'];
        } else {
            $key = '';
        }
        if (!empty($instance->password)) {
            $secret = $instance->password;
        } else if (!empty($typeconfig['password'])) {
            $secret = $typeconfig['password'];
        } else {
            $secret = '';
        }
    }

    $endpoint = !empty($instance->toolurl) ? $instance->toolurl : $typeconfig['toolurl'];
    $endpoint = trim($endpoint);

    // If the current request is using SSL and a secure tool URL is specified, use it.
    if (ebooklti_request_is_using_ssl() && !empty($instance->securetoolurl)) {
        $endpoint = trim($instance->securetoolurl);
    }

    // If SSL is forced, use the secure tool url if specified. Otherwise, make sure https is on the normal launch URL.
    if (isset($typeconfig['forcessl']) && ($typeconfig['forcessl'] == '1')) {
        if (!empty($instance->securetoolurl)) {
            $endpoint = trim($instance->securetoolurl);
        }

        $endpoint = ebooklti_ensure_url_is_https($endpoint);
    } else {
        if (!strstr($endpoint, '://')) {
            $endpoint = 'http://' . $endpoint;
        }
    }

    $orgid = $typeconfig['organizationid'];

    $course = $PAGE->course;
    $isebooklti2 = isset($tool->toolproxyid);
    $allparams = ebooklti_build_request($instance, $typeconfig, $course, $typeid, $isebooklti2);
    if ($isebooklti2) {
        $requestparams = ebooklti_build_request_ebooklti2($tool, $allparams);
    } else {
        $requestparams = $allparams;
    }
    $requestparams = array_merge($requestparams, ebooklti_build_standard_request($instance, $orgid, $isebooklti2));
    $customstr = '';
    if (isset($typeconfig['customparameters'])) {
        $customstr = $typeconfig['customparameters'];
    }
    $requestparams = array_merge($requestparams, ebooklti_build_custom_parameters($toolproxy, $tool, $instance, $allparams, $customstr,
        $instance->instructorcustomparameters, $isebooklti2));

    $launchcontainer = ebooklti_get_launch_container($instance, $typeconfig);
    $returnurlparams = array('course' => $course->id,
                             'launch_container' => $launchcontainer,
                             'instanceid' => $instance->id,
                             'sesskey' => sesskey());

    // Add the return URL. We send the launch container along to help us avoid frames-within-frames when the user returns.
    $url = new \moodle_url('/mod/ebooklti/return.php', $returnurlparams);
    $returnurl = $url->out(false);

    if (isset($typeconfig['forcessl']) && ($typeconfig['forcessl'] == '1')) {
        $returnurl = ebooklti_ensure_url_is_https($returnurl);
    }

    $target = '';
    switch($launchcontainer) {
        case EBOOKLTI_LAUNCH_CONTAINER_EMBED:
        case EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS:
            $target = 'iframe';
            break;
        case EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW:
            $target = 'frame';
            break;
        case EBOOKLTI_LAUNCH_CONTAINER_WINDOW:
            $target = 'window';
            break;
    }
    if (!empty($target)) {
        $requestparams['launch_presentation_document_target'] = $target;
    }

    $requestparams['launch_presentation_return_url'] = $returnurl;

    // Add the parameters configured by the ebooklti advantage services.
    if ($typeid && !$isebooklti2) {
        $services = ebooklti_get_services();
        foreach ($services as $service) {
            $ebookltiadvantageparameters = $service->get_launch_parameters('basic-lti-launch-request',
                    $course->id, $USER->id , $typeid, $instance->id);
            foreach ($ebookltiadvantageparameters as $ebookltiadvantagekey => $ebookltiadvantagevalue) {
                $requestparams[$ebookltiadvantagekey] = $ebookltiadvantagevalue;
            }
        }
    }

    // Allow request params to be updated by sub-plugins.
    $plugins = core_component::get_plugin_list('ebookltisource');
    foreach (array_keys($plugins) as $plugin) {
        $pluginparams = component_callback('ebookltisource_'.$plugin, 'before_launch',
            array($instance, $endpoint, $requestparams), array());

        if (!empty($pluginparams) && is_array($pluginparams)) {
            $requestparams = array_merge($requestparams, $pluginparams);
        }
    }

    if (!empty($key) && !empty($secret)) {
        $parms = ebooklti_sign_parameters($requestparams, $endpoint, "POST", $key, $secret);

        $endpointurl = new \moodle_url($endpoint);
        $endpointparams = $endpointurl->params();

        // Strip querystring params in endpoint url from $parms to avoid duplication.
        if (!empty($endpointparams) && !empty($parms)) {
            foreach (array_keys($endpointparams) as $paramname) {
                if (isset($parms[$paramname])) {
                    unset($parms[$paramname]);
                }
            }
        }

    } else {
        // If no key and secret, do the launch unsigned.
        $returnurlparams['unsigned'] = '1';
        $parms = $requestparams;
    }

    return array($endpoint, $parms);
}

/**
 * Launch an ebooklti external tool activity.
 *
 * @param  stdClass $instance the ebooklti external tool activity settings
 * @return string The HTML code containing the javascript code for the launch
 */
function ebooklti_launch_tool($instance) {

    list($endpoint, $parms) = ebooklti_get_launch_data($instance);
    $debuglaunch = ( $instance->debuglaunch == 1 );
	
    $content = ebooklti_post_launch_html($parms, $endpoint, $debuglaunch);

    echo $content;
}

/**
 * Prepares an EBOOKLTI registration request message
 *
 * @param object $toolproxy  Tool Proxy instance object
 */
function ebooklti_register($toolproxy) {
    $endpoint = $toolproxy->regurl;

    // Change the status to pending.
    $toolproxy->state = EBOOKLTI_TOOL_PROXY_STATE_PENDING;
    ebooklti_update_tool_proxy($toolproxy);

    $requestparams = ebooklti_build_registration_request($toolproxy);

    $content = ebooklti_post_launch_html($requestparams, $endpoint, false);

    echo $content;
}


/**
 * Gets the parameters for the regirstration request
 *
 * @param object $toolproxy Tool Proxy instance object
 * @return array Registration request parameters
 */
function ebooklti_build_registration_request($toolproxy) {
    $key = $toolproxy->guid;
    $secret = $toolproxy->secret;

    $requestparams = array();
    $requestparams['lti_message_type'] = 'ToolProxyRegistrationRequest';
    $requestparams['lti_version'] = 'LTI-2p0';
    $requestparams['reg_key'] = $key;
    $requestparams['reg_password'] = $secret;
    $requestparams['reg_url'] = $toolproxy->regurl;

    // Add the profile URL.
    $profileservice = ebooklti_get_service_by_name('profile');
    $profileservice->set_tool_proxy($toolproxy);
    $requestparams['tc_profile_url'] = $profileservice->parse_value('$ToolConsumerProfile.url');

    // Add the return URL.
    $returnurlparams = array('id' => $toolproxy->id, 'sesskey' => sesskey());
    $url = new \moodle_url('/mod/ebooklti/externalregistrationreturn.php', $returnurlparams);
    $returnurl = $url->out(false);

    $requestparams['launch_presentation_return_url'] = $returnurl;

    return $requestparams;
}

/**
 * Build source ID
 *
 * @param int $instanceid
 * @param int $userid
 * @param string $servicesalt
 * @param null|int $typeid
 * @param null|int $launchid
 * @return stdClass
 */
function ebooklti_build_sourcedid($instanceid, $userid, $servicesalt, $typeid = null, $launchid = null) {
    $data = new \stdClass();

    $data->instanceid = $instanceid;
    $data->userid = $userid;
    $data->typeid = $typeid;
    if (!empty($launchid)) {
        $data->launchid = $launchid;
    } else {
        $data->launchid = mt_rand();
    }

    $json = json_encode($data);

    $hash = hash('sha256', $json . $servicesalt, false);

    $container = new \stdClass();
    $container->data = $data;
    $container->hash = $hash;

    return $container;
}

/**
 * This function builds the request that must be sent to the tool producer
 *
 * @param object    $instance       Basic EBOOKLTI instance object
 * @param array     $typeconfig     Basic EBOOKLTI tool configuration
 * @param object    $course         Course object
 * @param int|null  $typeid         Basic EBOOKLTI tool ID
 * @param boolean   $isebooklti2         True if an EBOOKLTI 2 tool is being launched
 *
 * @return array                    Request details
 */
function ebooklti_build_request($instance, $typeconfig, $course, $typeid = null, $isebooklti2 = false) {
    global $USER, $CFG;

    if (empty($instance->cmid)) {
        $instance->cmid = 0;
    }

    $role = ebooklti_get_ims_role($USER, $instance->cmid, $instance->course, $isebooklti2);

    $requestparams = array(
        'user_id' => $USER->id,
        'lis_person_sourcedid' => $USER->idnumber,
        'roles' => $role,
        'context_id' => $course->id,
        'context_label' => trim(html_to_text($course->shortname, 0)),
        'context_title' => trim(html_to_text($course->fullname, 0)),
    );
    if (!empty($instance->name)) {
        $requestparams['resource_link_title'] = trim(html_to_text($instance->name, 0));
    }
    if (!empty($instance->cmid)) {
        $intro = format_module_intro('ebooklti', $instance, $instance->cmid);
        $intro = trim(html_to_text($intro, 0, false));

        // This may look weird, but this is required for new lines
        // so we generate the same OAuth signature as the tool provider.
        $intro = str_replace("\n", "\r\n", $intro);
        $requestparams['resource_link_description'] = $intro;
    }
    if (!empty($instance->id)) {
        $requestparams['resource_link_id'] = $instance->id;
    }
    if (!empty($instance->resource_link_id)) {
        $requestparams['resource_link_id'] = $instance->resource_link_id;
    }
    if ($course->format == 'site') {
        $requestparams['context_type'] = 'Group';
    } else {
        $requestparams['context_type'] = 'CourseSection';
        $requestparams['lis_course_section_sourcedid'] = $course->idnumber;
    }

    if (!empty($instance->id) && !empty($instance->servicesalt) && ($isebooklti2 ||
            $typeconfig['acceptgrades'] == EBOOKLTI_SETTING_ALWAYS ||
            ($typeconfig['acceptgrades'] == EBOOKLTI_SETTING_DELEGATE && $instance->instructorchoiceacceptgrades == EBOOKLTI_SETTING_ALWAYS))
    ) {
        $placementsecret = $instance->servicesalt;
        $sourcedid = json_encode(ebooklti_build_sourcedid($instance->id, $USER->id, $placementsecret, $typeid));
        $requestparams['lis_result_sourcedid'] = $sourcedid;

        // Add outcome service URL.
        $serviceurl = new \moodle_url('/mod/ebooklti/service.php');
        $serviceurl = $serviceurl->out();

        $forcessl = false;
        if (!empty($CFG->mod_ebooklti_forcessl)) {
            $forcessl = true;
        }

        if ((isset($typeconfig['forcessl']) && ($typeconfig['forcessl'] == '1')) or $forcessl) {
            $serviceurl = ebooklti_ensure_url_is_https($serviceurl);
        }

        $requestparams['lis_outcome_service_url'] = $serviceurl;
    }

    // Send user's name and email data if appropriate.
    if ($isebooklti2 || $typeconfig['sendname'] == EBOOKLTI_SETTING_ALWAYS ||
        ($typeconfig['sendname'] == EBOOKLTI_SETTING_DELEGATE && isset($instance->instructorchoicesendname)
            && $instance->instructorchoicesendname == EBOOKLTI_SETTING_ALWAYS)
    ) {
        $requestparams['lis_person_name_given'] = $USER->firstname;
        $requestparams['lis_person_name_family'] = $USER->lastname;
        $requestparams['lis_person_name_full'] = fullname($USER);
        $requestparams['ext_user_username'] = $USER->username;
    }

    if ($isebooklti2 || $typeconfig['sendemailaddr'] == EBOOKLTI_SETTING_ALWAYS ||
        ($typeconfig['sendemailaddr'] == EBOOKLTI_SETTING_DELEGATE && isset($instance->instructorchoicesendemailaddr)
            && $instance->instructorchoicesendemailaddr == EBOOKLTI_SETTING_ALWAYS)
    ) {
        $requestparams['lis_person_contact_email_primary'] = $USER->email;
    }

    return $requestparams;
}

/**
 * This function builds the request that must be sent to an EBOOKLTI 2 tool provider
 *
 * @param object    $tool           Basic EBOOKLTI tool object
 * @param array     $params         Custom launch parameters
 *
 * @return array                    Request details
 */
function ebooklti_build_request_ebooklti2($tool, $params) {

    $requestparams = array();

    $capabilities = ebooklti_get_capabilities();
    $enabledcapabilities = explode("\n", $tool->enabledcapability);
    foreach ($enabledcapabilities as $capability) {
        if (array_key_exists($capability, $capabilities)) {
            $val = $capabilities[$capability];
            if ($val && (substr($val, 0, 1) != '$')) {
                if (isset($params[$val])) {
                    $requestparams[$capabilities[$capability]] = $params[$capabilities[$capability]];
                }
            }
        }
    }

    return $requestparams;
}

/**
 * This function builds the standard parameters for an EBOOKLTI 1 or 2 request that must be sent to the tool producer
 *
 * @param stdClass  $instance       Basic EBOOKLTI instance object
 * @param string    $orgid          Organisation ID
 * @param boolean   $isebooklti2         True if an EBOOKLTI 2 tool is being launched
 * @param string    $messagetype    The request message type. Defaults to basic-lti-launch-request if empty.
 *
 * @return array                    Request details
 */
function ebooklti_build_standard_request($instance, $orgid, $isebooklti2, $messagetype = 'basic-lti-launch-request') {
    global $CFG;

    $requestparams = array();

    if ($instance) {
        $requestparams['resource_link_id'] = $instance->id;
        if (property_exists($instance, 'resource_link_id') and !empty($instance->resource_link_id)) {
            $requestparams['resource_link_id'] = $instance->resource_link_id;
        }
    }

    $requestparams['launch_presentation_locale'] = current_language();

    // Make sure we let the tool know what LMS they are being called from.
    $requestparams['ext_lms'] = 'moodle-2';
    $requestparams['tool_consumer_info_product_family_code'] = 'moodle';
    $requestparams['tool_consumer_info_version'] = strval($CFG->version);

    // Add oauth_callback to be compliant with the 1.0A spec.
    $requestparams['oauth_callback'] = 'about:blank';

    if (!$isebooklti2) {
        $requestparams['lti_version'] = 'LTI-1p0';
    } else {
        $requestparams['lti_version'] = 'LTI-2p0';
    }
    $requestparams['lti_message_type'] = $messagetype;

    if ($orgid) {
        $requestparams["tool_consumer_instance_guid"] = $orgid;
    }
    if (!empty($CFG->mod_ebooklti_institution_name)) {
        $requestparams['tool_consumer_instance_name'] = trim(html_to_text($CFG->mod_ebooklti_institution_name, 0));
    } else {
        $requestparams['tool_consumer_instance_name'] = get_site()->shortname;
    }
    $requestparams['tool_consumer_instance_description'] = trim(html_to_text(get_site()->fullname, 0));

    return $requestparams;
}

/**
 * This function builds the custom parameters
 *
 * @param object    $toolproxy      Tool proxy instance object
 * @param object    $tool           Tool instance object
 * @param object    $instance       Tool placement instance object
 * @param array     $params         EBOOKLTI launch parameters
 * @param string    $customstr      Custom parameters defined for tool
 * @param string    $instructorcustomstr      Custom parameters defined for this placement
 * @param boolean   $isebooklti2         True if an EBOOKLTI 2 tool is being launched
 *
 * @return array                    Custom parameters
 */
function ebooklti_build_custom_parameters($toolproxy, $tool, $instance, $params, $customstr, $instructorcustomstr, $isebooklti2) {

    // Concatenate the custom parameters from the administrator and the instructor
    // Instructor parameters are only taken into consideration if the administrator
    // has given permission.
    $custom = array();
    if ($customstr) {
        $custom = ebooklti_split_custom_parameters($toolproxy, $tool, $params, $customstr, $isebooklti2);
    }
    if ($instructorcustomstr) {
        $custom = array_merge(ebooklti_split_custom_parameters($toolproxy, $tool, $params,
            $instructorcustomstr, $isebooklti2), $custom);
    }
    if ($isebooklti2) {
        $custom = array_merge(ebooklti_split_custom_parameters($toolproxy, $tool, $params,
            $tool->parameter, true), $custom);
        $settings = ebooklti_get_tool_settings($tool->toolproxyid);
        $custom = array_merge($custom, ebooklti_get_custom_parameters($toolproxy, $tool, $params, $settings));
        if (!empty($instance->course)) {
            $settings = ebooklti_get_tool_settings($tool->toolproxyid, $instance->course);
            $custom = array_merge($custom, ebooklti_get_custom_parameters($toolproxy, $tool, $params, $settings));
            if (!empty($instance->id)) {
                $settings = ebooklti_get_tool_settings($tool->toolproxyid, $instance->course, $instance->id);
                $custom = array_merge($custom, ebooklti_get_custom_parameters($toolproxy, $tool, $params, $settings));
            }
        }
    }

    return $custom;
}

/**
 * Builds a standard EBOOKLTI Content-Item selection request.
 *
 * @param int $id The tool type ID.
 * @param stdClass $course The course object.
 * @param moodle_url $returnurl The return URL in the tool consumer (TC) that the tool provider (TP)
 *                              will use to return the Content-Item message.
 * @param string $title The tool's title, if available.
 * @param string $text The text to display to represent the content item. This value may be a long description of the content item.
 * @param array $mediatypes Array of MIME types types supported by the TC. If empty, the TC will support ebookltilink by default.
 * @param array $presentationtargets Array of ways in which the selected content item(s) can be requested to be opened
 *                                   (via the presentationDocumentTarget element for a returned content item).
 *                                   If empty, "frame", "iframe", and "window" will be supported by default.
 * @param bool $autocreate Indicates whether any content items returned by the TP would be automatically persisted without
 * @param bool $multiple Indicates whether the user should be permitted to select more than one item. False by default.
 *                         any option for the user to cancel the operation. False by default.
 * @param bool $unsigned Indicates whether the TC is willing to accept an unsigned return message, or not.
 *                       A signed message should always be required when the content item is being created automatically in the
 *                       TC without further interaction from the user. False by default.
 * @param bool $canconfirm Flag for can_confirm parameter. False by default.
 * @param bool $copyadvice Indicates whether the TC is able and willing to make a local copy of a content item. False by default.
 * @return stdClass The object containing the signed request parameters and the URL to the TP's Content-Item selection interface.
 * @throws moodle_exception When the EBOOKLTI tool type does not exist.`
 * @throws coding_exception For invalid media type and presentation target parameters.
 */
function ebooklti_build_content_item_selection_request($id, $course, moodle_url $returnurl, $title = '', $text = '', $mediatypes = [],
                                                  $presentationtargets = [], $autocreate = false, $multiple = false,
                                                  $unsigned = false, $canconfirm = false, $copyadvice = false) {
    global $USER;

    $tool = ebooklti_get_type($id);
    // Validate parameters.
    if (!$tool) {
        throw new moodle_exception('errortooltypenotfound', 'mod_ebooklti');
    }
    if (!is_array($mediatypes)) {
        throw new coding_exception('The list of accepted media types should be in an array');
    }
    if (!is_array($presentationtargets)) {
        throw new coding_exception('The list of accepted presentation targets should be in an array');
    }

    // Check title. If empty, use the tool's name.
    if (empty($title)) {
        $title = $tool->name;
    }

    $typeconfig = ebooklti_get_type_config($id);
    $key = '';
    $secret = '';
    $isebooklti2 = false;
    if (isset($tool->toolproxyid)) {
        $isebooklti2 = true;
        $toolproxy = ebooklti_get_tool_proxy($tool->toolproxyid);
        $key = $toolproxy->guid;
        $secret = $toolproxy->secret;
    } else {
        $toolproxy = null;
        if (!empty($typeconfig['resourcekey'])) {
            $key = $typeconfig['resourcekey'];
        }
        if (!empty($typeconfig['password'])) {
            $secret = $typeconfig['password'];
        }
    }
    $tool->enabledcapability = '';
    if (!empty($typeconfig['enabledcapability_ContentItemSelectionRequest'])) {
        $tool->enabledcapability = $typeconfig['enabledcapability_ContentItemSelectionRequest'];
    }

    $tool->parameter = '';
    if (!empty($typeconfig['parameter_ContentItemSelectionRequest'])) {
        $tool->parameter = $typeconfig['parameter_ContentItemSelectionRequest'];
    }

    // Set the tool URL.
    if (!empty($typeconfig['toolurl_ContentItemSelectionRequest'])) {
        $toolurl = new moodle_url($typeconfig['toolurl_ContentItemSelectionRequest']);
    } else {
        $toolurl = new moodle_url($typeconfig['toolurl']);
    }

    // Check if SSL is forced.
    if (!empty($typeconfig['forcessl'])) {
        // Make sure the tool URL is set to https.
        if (strtolower($toolurl->get_scheme()) === 'http') {
            $toolurl->set_scheme('https');
        }
        // Make sure the return URL is set to https.
        if (strtolower($returnurl->get_scheme()) === 'http') {
            $returnurl->set_scheme('https');
        }
    }
    $toolurlout = $toolurl->out(false);

    // Get base request parameters.
    $instance = new stdClass();
    $instance->course = $course->id;
    $requestparams = ebooklti_build_request($instance, $typeconfig, $course, $id, $isebooklti2);

    // Get EBOOKLTI2-specific request parameters and merge to the request parameters if applicable.
    if ($isebooklti2) {
        $ebooklti2params = ebooklti_build_request_ebooklti2($tool, $requestparams);
        $requestparams = array_merge($requestparams, $ebooklti2params);
    }

    // Add the parameters configured by the ebooklti advantage services.
    if ($id && !$isebooklti2) {
        $services = ebooklti_get_services();
        foreach ($services as $service) {
            $ebookltiadvantageparameters = $service->get_launch_parameters('ContentItemSelectionRequest',
                    $course->id, $USER->id , $id);
            foreach ($ebookltiadvantageparameters as $ebookltiadvantagekey => $ebookltiadvantagevalue) {
                $requestparams[$ebookltiadvantagekey] = $ebookltiadvantagevalue;
            }
        }
    }

    // Get standard request parameters and merge to the request parameters.
    $orgid = !empty($typeconfig['organizationid']) ? $typeconfig['organizationid'] : '';
    $standardparams = ebooklti_build_standard_request(null, $orgid, $isebooklti2, 'ContentItemSelectionRequest');
    $requestparams = array_merge($requestparams, $standardparams);

    // Get custom request parameters and merge to the request parameters.
    $customstr = '';
    if (!empty($typeconfig['customparameters'])) {
        $customstr = $typeconfig['customparameters'];
    }
    $customparams = ebooklti_build_custom_parameters($toolproxy, $tool, $instance, $requestparams, $customstr, '', $isebooklti2);
    $requestparams = array_merge($requestparams, $customparams);

    // Allow request params to be updated by sub-plugins.
    $plugins = core_component::get_plugin_list('ebookltisource');
    foreach (array_keys($plugins) as $plugin) {
        $pluginparams = component_callback('ebookltisource_' . $plugin, 'before_launch', [$instance, $toolurlout, $requestparams], []);

        if (!empty($pluginparams) && is_array($pluginparams)) {
            $requestparams = array_merge($requestparams, $pluginparams);
        }
    }

    // Media types. Set to ebookltilink by default if empty.
    if (empty($mediatypes)) {
        $mediatypes = [
            'application/vnd.ims.ebooklti.v1.ebookltilink',
        ];
    }
    $requestparams['accept_media_types'] = implode(',', $mediatypes);

    // Presentation targets. Supports frame, iframe, window by default if empty.
    if (empty($presentationtargets)) {
        $presentationtargets = [
            'frame',
            'iframe',
            'window',
        ];
    }
    $requestparams['accept_presentation_document_targets'] = implode(',', $presentationtargets);

    // Other request parameters.
    $requestparams['accept_copy_advice'] = $copyadvice === true ? 'true' : 'false';
    $requestparams['accept_multiple'] = $multiple === true ? 'true' : 'false';
    $requestparams['accept_unsigned'] = $unsigned === true ? 'true' : 'false';
    $requestparams['auto_create'] = $autocreate === true ? 'true' : 'false';
    $requestparams['can_confirm'] = $canconfirm === true ? 'true' : 'false';
    $requestparams['content_item_return_url'] = $returnurl->out(false);
    $requestparams['title'] = $title;
    $requestparams['text'] = $text;
    $signedparams = ebooklti_sign_parameters($requestparams, $toolurlout, 'POST', $key, $secret);
    $toolurlparams = $toolurl->params();

    // Strip querystring params in endpoint url from $signedparams to avoid duplication.
    if (!empty($toolurlparams) && !empty($signedparams)) {
        foreach (array_keys($toolurlparams) as $paramname) {
            if (isset($signedparams[$paramname])) {
                unset($signedparams[$paramname]);
            }
        }
    }

    // Check for params that should not be passed. Unset if they are set.
    $unwantedparams = [
        'resource_link_id',
        'resource_link_title',
        'resource_link_description',
        'launch_presentation_return_url',
        'lis_result_sourcedid',
    ];
    foreach ($unwantedparams as $param) {
        if (isset($signedparams[$param])) {
            unset($signedparams[$param]);
        }
    }

    // Prepare result object.
    $result = new stdClass();
    $result->params = $signedparams;
    $result->url = $toolurlout;

    return $result;
}

/**
 * Processes the tool provider's response to the ContentItemSelectionRequest and builds the configuration data from the
 * selected content item. This configuration data can be then used when adding a tool into the course.
 *
 * @param int $typeid The tool type ID.
 * @param string $messagetype The value for the lti_message_type parameter.
 * @param string $ltiversion The value for the lti_version parameter.
 * @param string $consumerkey The consumer key.
 * @param string $contentitemsjson The JSON string for the content_items parameter.
 * @return stdClass The array of module information objects.
 * @throws moodle_exception
 * @throws ebooklti\OAuthException
 */
function ebooklti_tool_configuration_from_content_item($typeid, $messagetype, $ebookltiversion, $consumerkey, $contentitemsjson) {
    $tool = ebooklti_get_type($typeid);
    // Validate parameters.
    if (!$tool) {
        throw new moodle_exception('errortooltypenotfound', 'mod_ebooklti');
    }
    // Check lti_message_type. Show debugging if it's not set to ContentItemSelection.
    // No need to throw exceptions for now since lti_message_type does not seem to be used in this processing at the moment.
    if ($messagetype !== 'ContentItemSelection') {
        debugging("lti_message_type is invalid: {$messagetype}. It should be set to 'ContentItemSelection'.",
            DEBUG_DEVELOPER);
    }

    $typeconfig = ebooklti_get_type_config($typeid);

    if (isset($tool->toolproxyid)) {
        $isebooklti2 = true;
        $toolproxy = ebooklti_get_tool_proxy($tool->toolproxyid);
        $key = $toolproxy->guid;
        $secret = $toolproxy->secret;
    } else {
        $isebooklti2 = false;
        $toolproxy = null;
        if (!empty($typeconfig['resourcekey'])) {
            $key = $typeconfig['resourcekey'];
        } else {
            $key = '';
        }
        if (!empty($typeconfig['password'])) {
            $secret = $typeconfig['password'];
        } else {
            $secret = '';
        }
    }

    // Check EBOOKLTI versions from our side and the response's side. Show debugging if they don't match.
    // No need to throw exceptions for now since EBOOKLTI version does not seem to be used in this processing at the moment.
    $expectedversion = EBOOKLTI_VERSION_1;
    if ($isebooklti2) {
        $expectedversion = EBOOKLTI_VERSION_2;
    }
    if ($ebookltiversion !== $expectedversion) {
        debugging("lti_version from response does not match the tool's configuration. Tool: {$expectedversion}," .
            " Response: {$ebookltiversion}", DEBUG_DEVELOPER);
    }

    if ($consumerkey !== $key) {
        throw new moodle_exception('errorincorrectconsumerkey', 'mod_ebooklti');
    }

    $store = new ebooklti\TrivialOAuthDataStore();
    $store->add_consumer($key, $secret);
    $server = new ebooklti\OAuthServer($store);
    $method = new ebooklti\OAuthSignatureMethod_HMAC_SHA1();
    $server->add_signature_method($method);
    $request = ebooklti\OAuthRequest::from_request();
    try {
        $server->verify_request($request);
    } catch (ebooklti\OAuthException $e) {
        throw new ebooklti\OAuthException("OAuth signature failed: " . $e->getMessage());
    }

    $items = json_decode($contentitemsjson);
    if (empty($items)) {
        throw new moodle_exception('errorinvaliddata', 'mod_ebooklti', '', $contentitemsjson);
    }
    if (!isset($items->{'@graph'}) || !is_array($items->{'@graph'}) || (count($items->{'@graph'}) > 1)) {
        throw new moodle_exception('errorinvalidresponseformat', 'mod_ebooklti');
    }

    $config = null;
    if (!empty($items->{'@graph'})) {
        $item = $items->{'@graph'}[0];

        $config = new stdClass();
        $config->name = '';
        if (isset($item->title)) {
            $config->name = $item->title;
        }
        if (empty($config->name)) {
            $config->name = $tool->name;
        }
        if (isset($item->text)) {
            $config->introeditor = [
                'text' => $item->text,
                'format' => FORMAT_PLAIN
            ];
        }
        if (isset($item->icon->{'@id'})) {
            $iconurl = new moodle_url($item->icon->{'@id'});
            // Assign item's icon URL to secureicon or icon depending on its scheme.
            if (strtolower($iconurl->get_scheme()) === 'https') {
                $config->secureicon = $iconurl->out(false);
            } else {
                $config->icon = $iconurl->out(false);
            }
        }
        if (isset($item->url)) {
            $url = new moodle_url($item->url);
            $config->toolurl = $url->out(false);
            $config->typeid = 0;
        } else {
            $config->typeid = $typeid;
        }
        $config->instructorchoiceacceptgrades = EBOOKLTI_SETTING_NEVER;
        if (!$isebooklti2 && isset($typeconfig['acceptgrades'])) {
            $acceptgrades = $typeconfig['acceptgrades'];
            if ($acceptgrades == EBOOKLTI_SETTING_ALWAYS) {
                // We create a line item regardless if the definition contains one or not.
                $config->instructorchoiceacceptgrades = EBOOKLTI_SETTING_ALWAYS;
            }
            if ($acceptgrades == EBOOKLTI_SETTING_DELEGATE || $acceptgrades == EBOOKLTI_SETTING_ALWAYS) {
                if (isset($item->lineItem)) {
                    $lineitem = $item->lineItem;
                    $config->instructorchoiceacceptgrades = EBOOKLTI_SETTING_ALWAYS;
                    $maxscore = 100;
                    if (isset($lineitem->scoreConstraints)) {
                        $sc = $lineitem->scoreConstraints;
                        if (isset($sc->totalMaximum)) {
                            $maxscore = $sc->totalMaximum;
                        } else if (isset($sc->normalMaximum)) {
                            $maxscore = $sc->normalMaximum;
                        }
                    }
                    $config->grade_modgrade_point = $maxscore;
                    if (isset($lineitem->assignedActivity) && isset($lineitem->assignedActivity->activityId)) {
                        $config->cmidnumber = $lineitem->assignedActivity->activityId;
                    }
                }
            }
        }
        $config->instructorchoicesendname = EBOOKLTI_SETTING_NEVER;
        $config->instructorchoicesendemailaddr = EBOOKLTI_SETTING_NEVER;
        $config->launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_DEFAULT;
        if (isset($item->placementAdvice->presentationDocumentTarget)) {
            if ($item->placementAdvice->presentationDocumentTarget === 'window') {
                $config->launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_WINDOW;
            } else if ($item->placementAdvice->presentationDocumentTarget === 'frame') {
                $config->launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS;
            } else if ($item->placementAdvice->presentationDocumentTarget === 'iframe') {
                $config->launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_EMBED;
            }
        }
        if (isset($item->custom)) {
            $customparameters = [];
            foreach ($item->custom as $key => $value) {
                $customparameters[] = "{$key}={$value}";
            }
            $config->instructorcustomparameters = implode("\n", $customparameters);
        }
        $config->contentitemjson = json_encode($item);
    }
    return $config;
}

function ebooklti_get_tool_table($tools, $id) {
    global $OUTPUT;
    $html = '';

    $typename = get_string('typename', 'ebooklti');
    $baseurl = get_string('baseurl', 'ebooklti');
    $action = get_string('action', 'ebooklti');
    $createdon = get_string('createdon', 'ebooklti');

    if (!empty($tools)) {
        $html .= "
        <div id=\"{$id}_tools_container\" style=\"margin-top:.5em;margin-bottom:.5em\">
            <table id=\"{$id}_tools\">
                <thead>
                    <tr>
                        <th>$typename</th>
                        <th>$baseurl</th>
                        <th>$createdon</th>
                        <th>$action</th>
                    </tr>
                </thead>
        ";

        foreach ($tools as $type) {
            $date = userdate($type->timecreated, get_string('strftimedatefullshort', 'core_langconfig'));
            $accept = get_string('accept', 'ebooklti');
            $update = get_string('update', 'ebooklti');
            $delete = get_string('delete', 'ebooklti');

            if (empty($type->toolproxyid)) {
                $baseurl = new \moodle_url('/mod/ebooklti/typessettings.php', array(
                        'action' => 'accept',
                        'id' => $type->id,
                        'sesskey' => sesskey(),
                        'tab' => $id
                    ));
                $ref = $type->baseurl;
            } else {
                $baseurl = new \moodle_url('/mod/ebooklti/toolssettings.php', array(
                        'action' => 'accept',
                        'id' => $type->id,
                        'sesskey' => sesskey(),
                        'tab' => $id
                    ));
                $ref = $type->tpname;
            }

            $accepthtml = $OUTPUT->action_icon($baseurl,
                    new \pix_icon('t/check', $accept, '', array('class' => 'iconsmall')), null,
                    array('title' => $accept, 'class' => 'editing_accept'));

            $deleteaction = 'delete';

            if ($type->state == EBOOKLTI_TOOL_STATE_CONFIGURED) {
                $accepthtml = '';
            }

            if ($type->state != EBOOKLTI_TOOL_STATE_REJECTED) {
                $deleteaction = 'reject';
                $delete = get_string('reject', 'ebooklti');
            }

            $updateurl = clone($baseurl);
            $updateurl->param('action', 'update');
            $updatehtml = $OUTPUT->action_icon($updateurl,
                    new \pix_icon('t/edit', $update, '', array('class' => 'iconsmall')), null,
                    array('title' => $update, 'class' => 'editing_update'));

            if (($type->state != EBOOKLTI_TOOL_STATE_REJECTED) || empty($type->toolproxyid)) {
                $deleteurl = clone($baseurl);
                $deleteurl->param('action', $deleteaction);
                $deletehtml = $OUTPUT->action_icon($deleteurl,
                        new \pix_icon('t/delete', $delete, '', array('class' => 'iconsmall')), null,
                        array('title' => $delete, 'class' => 'editing_delete'));
            } else {
                $deletehtml = '';
            }
            $html .= "
            <tr>
                <td>
                    {$type->name}
                </td>
                <td>
                    {$ref}
                </td>
                <td>
                    {$date}
                </td>
                <td align=\"center\">
                    {$accepthtml}{$updatehtml}{$deletehtml}
                </td>
            </tr>
            ";
        }
        $html .= '</table></div>';
    } else {
        $html .= get_string('no_' . $id, 'ebooklti');
    }

    return $html;
}

/**
 * This function builds the tab for a category of tool proxies
 *
 * @param object    $toolproxies    Tool proxy instance objects
 * @param string    $id             Category ID
 *
 * @return string                   HTML for tab
 */
function ebooklti_get_tool_proxy_table($toolproxies, $id) {
    global $OUTPUT;

    if (!empty($toolproxies)) {
        $typename = get_string('typename', 'ebooklti');
        $url = get_string('registrationurl', 'ebooklti');
        $action = get_string('action', 'ebooklti');
        $createdon = get_string('createdon', 'ebooklti');

        $html = <<< EOD
        <div id="{$id}_tool_proxies_container" style="margin-top: 0.5em; margin-bottom: 0.5em">
            <table id="{$id}_tool_proxies">
                <thead>
                    <tr>
                        <th>{$typename}</th>
                        <th>{$url}</th>
                        <th>{$createdon}</th>
                        <th>{$action}</th>
                    </tr>
                </thead>
EOD;
        foreach ($toolproxies as $toolproxy) {
            $date = userdate($toolproxy->timecreated, get_string('strftimedatefullshort', 'core_langconfig'));
            $accept = get_string('register', 'ebooklti');
            $update = get_string('update', 'ebooklti');
            $delete = get_string('delete', 'ebooklti');

            $baseurl = new \moodle_url('/mod/ebooklti/registersettings.php', array(
                    'action' => 'accept',
                    'id' => $toolproxy->id,
                    'sesskey' => sesskey(),
                    'tab' => $id
                ));

            $registerurl = new \moodle_url('/mod/ebooklti/register.php', array(
                    'id' => $toolproxy->id,
                    'sesskey' => sesskey(),
                    'tab' => 'tool_proxy'
                ));

            $accepthtml = $OUTPUT->action_icon($registerurl,
                    new \pix_icon('t/check', $accept, '', array('class' => 'iconsmall')), null,
                    array('title' => $accept, 'class' => 'editing_accept'));

            $deleteaction = 'delete';

            if ($toolproxy->state != EBOOKLTI_TOOL_PROXY_STATE_CONFIGURED) {
                $accepthtml = '';
            }

            if (($toolproxy->state == EBOOKLTI_TOOL_PROXY_STATE_CONFIGURED) || ($toolproxy->state == EBOOKLTI_TOOL_PROXY_STATE_PENDING)) {
                $delete = get_string('cancel', 'ebooklti');
            }

            $updateurl = clone($baseurl);
            $updateurl->param('action', 'update');
            $updatehtml = $OUTPUT->action_icon($updateurl,
                    new \pix_icon('t/edit', $update, '', array('class' => 'iconsmall')), null,
                    array('title' => $update, 'class' => 'editing_update'));

            $deleteurl = clone($baseurl);
            $deleteurl->param('action', $deleteaction);
            $deletehtml = $OUTPUT->action_icon($deleteurl,
                    new \pix_icon('t/delete', $delete, '', array('class' => 'iconsmall')), null,
                    array('title' => $delete, 'class' => 'editing_delete'));
            $html .= <<< EOD
            <tr>
                <td>
                    {$toolproxy->name}
                </td>
                <td>
                    {$toolproxy->regurl}
                </td>
                <td>
                    {$date}
                </td>
                <td align="center">
                    {$accepthtml}{$updatehtml}{$deletehtml}
                </td>
            </tr>
EOD;
        }
        $html .= '</table></div>';
    } else {
        $html = get_string('no_' . $id, 'ebooklti');
    }

    return $html;
}

/**
 * Extracts the enabled capabilities into an array, including those implicitly declared in a parameter
 *
 * @param object $tool  Tool instance object
 *
 * @return array List of enabled capabilities
 */
function ebooklti_get_enabled_capabilities($tool) {
    if (!isset($tool)) {
        return array();
    }
    if (!empty($tool->enabledcapability)) {
        $enabledcapabilities = explode("\n", $tool->enabledcapability);
    } else {
        $enabledcapabilities = array();
    }
    $paramstr = str_replace("\r\n", "\n", $tool->parameter);
    $paramstr = str_replace("\n\r", "\n", $paramstr);
    $paramstr = str_replace("\r", "\n", $paramstr);
    $params = explode("\n", $paramstr);
    foreach ($params as $param) {
        $pos = strpos($param, '=');
        if (($pos === false) || ($pos < 1)) {
            continue;
        }
        $value = trim(core_text::substr($param, $pos + 1, strlen($param)));
        if (substr($value, 0, 1) == '$') {
            $value = substr($value, 1);
            if (!in_array($value, $enabledcapabilities)) {
                $enabledcapabilities[] = $value;
            }
        }
    }
    return $enabledcapabilities;
}

/**
 * Splits the custom parameters field to the various parameters
 *
 * @param object    $toolproxy      Tool proxy instance object
 * @param object    $tool           Tool instance object
 * @param array     $params         EBOOKLTI launch parameters
 * @param string    $customstr      String containing the parameters
 * @param boolean   $isebooklti2         True if an EBOOKLTI 2 tool is being launched
 *
 * @return array of custom parameters
 */
function ebooklti_split_custom_parameters($toolproxy, $tool, $params, $customstr, $isebooklti2 = false) {
    $customstr = str_replace("\r\n", "\n", $customstr);
    $customstr = str_replace("\n\r", "\n", $customstr);
    $customstr = str_replace("\r", "\n", $customstr);
    $lines = explode("\n", $customstr);  // Or should this split on "/[\n;]/"?
    $retval = array();
    foreach ($lines as $line) {
        $pos = strpos($line, '=');
        if ( $pos === false || $pos < 1 ) {
            continue;
        }
        $key = trim(core_text::substr($line, 0, $pos));
        $key = ebooklti_map_keyname($key, false);
        $val = trim(core_text::substr($line, $pos + 1, strlen($line)));
        $val = ebooklti_parse_custom_parameter($toolproxy, $tool, $params, $val, $isebooklti2);
        $key2 = ebooklti_map_keyname($key);
        $retval['custom_'.$key2] = $val;
        if ($key != $key2) {
            $retval['custom_'.$key] = $val;
        }
    }
    return $retval;
}

/**
 * Adds the custom parameters to an array
 *
 * @param object    $toolproxy      Tool proxy instance object
 * @param object    $tool           Tool instance object
 * @param array     $params         EBOOKLTI launch parameters
 * @param array     $parameters     Array containing the parameters
 *
 * @return array    Array of custom parameters
 */
function ebooklti_get_custom_parameters($toolproxy, $tool, $params, $parameters) {
    $retval = array();
    foreach ($parameters as $key => $val) {
        $key2 = ebooklti_map_keyname($key);
        $val = ebooklti_parse_custom_parameter($toolproxy, $tool, $params, $val, true);
        $retval['custom_'.$key2] = $val;
        if ($key != $key2) {
            $retval['custom_'.$key] = $val;
        }
    }
    return $retval;
}

/**
 * Parse a custom parameter to replace any substitution variables
 *
 * @param object    $toolproxy      Tool proxy instance object
 * @param object    $tool           Tool instance object
 * @param array     $params         EBOOKLTI launch parameters
 * @param string    $value          Custom parameter value
 * @param boolean   $isebooklti2         True if an EBOOKLTI 2 tool is being launched
 *
 * @return string Parsed value of custom parameter
 */
function ebooklti_parse_custom_parameter($toolproxy, $tool, $params, $value, $isebooklti2) {
    // This is required as {${$valarr[0]}->{$valarr[1]}}" may be using the USER or COURSE var.
    global $USER, $COURSE;

    if ($value) {
        if (substr($value, 0, 1) == '\\') {
            $value = substr($value, 1);
        } else if (substr($value, 0, 1) == '$') {
            $value1 = substr($value, 1);
            $enabledcapabilities = ebooklti_get_enabled_capabilities($tool);
            if (!$isebooklti2 || in_array($value1, $enabledcapabilities)) {
                $capabilities = ebooklti_get_capabilities();
                if (array_key_exists($value1, $capabilities)) {
                    $val = $capabilities[$value1];
                    if ($val) {
                        if (substr($val, 0, 1) != '$') {
                            $value = $params[$val];
                        } else {
                            $valarr = explode('->', substr($val, 1), 2);
                            $value = "{${$valarr[0]}->{$valarr[1]}}";
                            $value = str_replace('<br />' , ' ', $value);
                            $value = str_replace('<br>' , ' ', $value);
                            $value = format_string($value);
                        }
                    } else {
                        $value = ebooklti_calculate_custom_parameter($value1);
                    }
                } else if ($isebooklti2) {
                    $val = $value;
                    $services = ebooklti_get_services();
                    foreach ($services as $service) {
                        $service->set_tool_proxy($toolproxy);
                        $value = $service->parse_value($val);
                        if ($val != $value) {
                            break;
                        }
                    }
                }
            }
        }
    }
    return $value;
}

/**
 * Calculates the value of a custom parameter that has not been specified earlier
 *
 * @param string    $value          Custom parameter value
 *
 * @return string Calculated value of custom parameter
 */
function ebooklti_calculate_custom_parameter($value) {
    global $USER, $COURSE;

    switch ($value) {
        case 'Moodle.Person.userGroupIds':
            return implode(",", groups_get_user_groups($COURSE->id, $USER->id)[0]);
    }
    return null;
}

/**
 * Used for building the names of the different custom parameters
 *
 * @param string $key   Parameter name
 * @param bool $tolower Do we want to convert the key into lower case?
 * @return string       Processed name
 */
function ebooklti_map_keyname($key, $tolower = true) {
    $newkey = "";
    if ($tolower) {
        $key = core_text::strtolower(trim($key));
    }
    foreach (str_split($key) as $ch) {
        if ( ($ch >= 'a' && $ch <= 'z') || ($ch >= '0' && $ch <= '9') || (!$tolower && ($ch >= 'A' && $ch <= 'Z'))) {
            $newkey .= $ch;
        } else {
            $newkey .= '_';
        }
    }
    return $newkey;
}

/**
 * Gets the IMS role string for the specified user and EBOOKLTI course module.
 *
 * @param mixed    $user      User object or user id
 * @param int      $cmid      The course module id of the EBOOKLTI activity
 * @param int      $courseid  The course id of the EBOOKLTI activity
 * @param boolean  $isebooklti2    True if an EBOOKLTI 2 tool is being launched
 *
 * @return string A role string suitable for passing with an EBOOKLTI launch
 */
function ebooklti_get_ims_role($user, $cmid, $courseid, $isebooklti2) {
    $roles = array();

    if (empty($cmid)) {
        // If no cmid is passed, check if the user is a teacher in the course
        // This allows other modules to programmatically "fake" a launch without
        // a real EBOOKLTI instance.
        $context = context_course::instance($courseid);

        if (has_capability('moodle/course:manageactivities', $context, $user)) {
            array_push($roles, 'Instructor');
        } else {
            array_push($roles, 'Learner');
        }
    } else {
        $context = context_module::instance($cmid);

        if (has_capability('mod/ebooklti:manage', $context)) {
            array_push($roles, 'Instructor');
        } else {
            array_push($roles, 'Learner');
        }
    }

    if (is_siteadmin($user) || has_capability('mod/ebooklti:admin', $context)) {
        // Make sure admins do not have the Learner role, then set admin role.
        $roles = array_diff($roles, array('Learner'));
        if (!$isebooklti2) {
            array_push($roles, 'urn:ebooklti:sysrole:ims/lis/Administrator', 'urn:ebooklti:instrole:ims/lis/Administrator');
        } else {
            array_push($roles, 'http://purl.imsglobal.org/vocab/lis/v2/person#Administrator');
        }
    }

    return join(',', $roles);
}

/**
 * Returns configuration details for the tool
 *
 * @param int $typeid   Basic EBOOKLTI tool typeid
 *
 * @return array        Tool Configuration
 */
function ebooklti_get_type_config($typeid) {
    global $DB;

    $query = "SELECT name, value
                FROM {ebooklti_types_config}
               WHERE typeid = :typeid1
           UNION ALL
              SELECT 'toolurl' AS name, baseurl AS value
                FROM {ebooklti_types}
               WHERE id = :typeid2
           UNION ALL
              SELECT 'icon' AS name, icon AS value
                FROM {ebooklti_types}
               WHERE id = :typeid3
           UNION ALL
              SELECT 'secureicon' AS name, secureicon AS value
                FROM {ebooklti_types}
               WHERE id = :typeid4";

    $typeconfig = array();
    $configs = $DB->get_records_sql($query,
        array('typeid1' => $typeid, 'typeid2' => $typeid, 'typeid3' => $typeid, 'typeid4' => $typeid));

    if (!empty($configs)) {
        foreach ($configs as $config) {
            $typeconfig[$config->name] = $config->value;
        }
    }

    return $typeconfig;
}

function ebooklti_get_tools_by_url($url, $state, $courseid = null) {
    $domain = ebooklti_get_domain_from_url($url);

    return ebooklti_get_tools_by_domain($domain, $state, $courseid);
}

function ebooklti_get_tools_by_domain($domain, $state = null, $courseid = null) {
    global $DB, $SITE;

    $statefilter = '';
    $coursefilter = '';

    if ($state) {
        $statefilter = 'AND state = :state';
    }

    if ($courseid && $courseid != $SITE->id) {
        $coursefilter = 'OR course = :courseid';
    }

    $query = "SELECT *
                FROM {ebooklti_types}
               WHERE tooldomain = :tooldomain
                 AND (course = :siteid $coursefilter)
                 $statefilter";

    return $DB->get_records_sql($query, array(
        'courseid' => $courseid,
        'siteid' => $SITE->id,
        'tooldomain' => $domain,
        'state' => $state
    ));
}

/**
 * Returns all basicEBOOKLTI tools configured by the administrator
 *
 * @param int $course
 *
 * @return array
 */
function ebooklti_filter_get_types($course) {
    global $DB;

    if (!empty($course)) {
        $where = "WHERE t.course = :course";
        $params = array('course' => $course);
    } else {
        $where = '';
        $params = array();
    }
    $query = "SELECT t.id, t.name, t.baseurl, t.state, t.toolproxyid, t.timecreated, tp.name tpname
                FROM {ebooklti_types} t LEFT OUTER JOIN {ebooklti_tool_proxies} tp ON t.toolproxyid = tp.id
                {$where}";
    return $DB->get_records_sql($query, $params);
}

/**
 * Given an array of tools, filter them based on their state
 *
 * @param array $tools An array of ebooklti_types records
 * @param int $state One of the EBOOKLTI_TOOL_STATE_* constants
 * @return array
 */
function ebooklti_filter_tool_types(array $tools, $state) {
    $return = array();
    foreach ($tools as $key => $tool) {
        if ($tool->state == $state) {
            $return[$key] = $tool;
        }
    }
    return $return;
}

/**
 * Returns all ebooklti types visible in this course
 *
 * @param int $courseid The id of the course to retieve types for
 * @param array $coursevisible options for 'coursevisible' field,
 *        default [EBOOKLTI_COURSEVISIBLE_PRECONFIGURED, EBOOKLTI_COURSEVISIBLE_ACTIVITYCHOOSER]
 * @return stdClass[] All the ebooklti types visible in the given course
 */
function ebooklti_get_ebooklti_types_by_course($courseid, $coursevisible = null) {
    global $DB, $SITE;

    if ($coursevisible === null) {
        $coursevisible = [EBOOKLTI_COURSEVISIBLE_PRECONFIGURED, EBOOKLTI_COURSEVISIBLE_ACTIVITYCHOOSER];
    }

    list($coursevisiblesql, $coursevisparams) = $DB->get_in_or_equal($coursevisible, SQL_PARAMS_NAMED, 'coursevisible');
    $query = "SELECT *
                FROM {ebooklti_types}
               WHERE coursevisible $coursevisiblesql
                 AND (course = :siteid OR course = :courseid)
                 AND state = :active";

    return $DB->get_records_sql($query,
        array('siteid' => $SITE->id, 'courseid' => $courseid, 'active' => EBOOKLTI_TOOL_STATE_CONFIGURED) + $coursevisparams);
}

/**
 * Returns tool types for ebooklti add instance and edit page
 *
 * @return array Array of ebooklti types
 */
function ebooklti_get_types_for_add_instance() {
    global $COURSE;
    $admintypes = ebooklti_get_ebooklti_types_by_course($COURSE->id);

    $types = array();
    $types[0] = (object)array('name' => get_string('automatic', 'ebooklti'), 'course' => 0, 'toolproxyid' => null);

    foreach ($admintypes as $type) {
        $types[$type->id] = $type;
    }

    return $types;
}

/**
 * Returns a list of configured types in the given course
 *
 * @param int $courseid The id of the course to retieve types for
 * @param int $sectionreturn section to return to for forming the URLs
 * @return array Array of ebooklti types. Each element is object with properties: name, title, icon, help, helplink, link
 */
function ebooklti_get_configured_types($courseid, $sectionreturn = 0) {
    global $OUTPUT;
    $types = array();
    $admintypes = ebooklti_get_ebooklti_types_by_course($courseid, [EBOOKLTI_COURSEVISIBLE_ACTIVITYCHOOSER]);

    foreach ($admintypes as $ebookltitype) {
        $type           = new stdClass();
        $type->modclass = MOD_CLASS_ACTIVITY;
        $type->name     = 'ebooklti_type_' . $ebookltitype->id;
        // Clean the name. We don't want tags here.
        $type->title    = clean_param($ebookltitype->name, PARAM_NOTAGS);
        $trimmeddescription = trim($ebookltitype->description);
        if ($trimmeddescription != '') {
            // Clean the description. We don't want tags here.
            $type->help     = clean_param($trimmeddescription, PARAM_NOTAGS);
            $type->helplink = get_string('modulename_shortcut_link', 'ebooklti');
        }
        if (empty($ebookltitype->icon)) {
            $type->icon = $OUTPUT->pix_icon('icon', '', 'ebooklti', array('class' => 'icon'));
        } else {
            $type->icon = html_writer::empty_tag('img', array('src' => $ebookltitype->icon, 'alt' => $ebookltitype->name, 'class' => 'icon'));
        }
        $type->link = new moodle_url('/course/modedit.php', array('add' => 'ebooklti', 'return' => 0, 'course' => $courseid,
            'sr' => $sectionreturn, 'typeid' => $ebookltitype->id));
        $types[] = $type;
    }
    return $types;
}

function ebooklti_get_domain_from_url($url) {
    $matches = array();

    if (preg_match(EBOOKLTI_URL_DOMAIN_REGEX, $url, $matches)) {
        return $matches[1];
    }
}

function ebooklti_get_tool_by_url_match($url, $courseid = null, $state = EBOOKLTI_TOOL_STATE_CONFIGURED) {
    $possibletools = ebooklti_get_tools_by_url($url, $state, $courseid);

    return ebooklti_get_best_tool_by_url($url, $possibletools, $courseid);
}

function ebooklti_get_url_thumbprint($url) {
    // Parse URL requires a schema otherwise everything goes into 'path'.  Fixed 5.4.7 or later.
    if (preg_match('/https?:\/\//', $url) !== 1) {
        $url = 'http://'.$url;
    }
    $urlparts = parse_url(strtolower($url));
    if (!isset($urlparts['path'])) {
        $urlparts['path'] = '';
    }

    if (!isset($urlparts['query'])) {
        $urlparts['query'] = '';
    }

    if (!isset($urlparts['host'])) {
        $urlparts['host'] = '';
    }

    if (substr($urlparts['host'], 0, 4) === 'www.') {
        $urlparts['host'] = substr($urlparts['host'], 4);
    }

    $urllower = $urlparts['host'] . '/' . $urlparts['path'];

    if ($urlparts['query'] != '') {
        $urllower .= '?' . $urlparts['query'];
    }

    return $urllower;
}

function ebooklti_get_best_tool_by_url($url, $tools, $courseid = null) {
    if (count($tools) === 0) {
        return null;
    }

    $urllower = ebooklti_get_url_thumbprint($url);

    foreach ($tools as $tool) {
        $tool->_matchscore = 0;

        $toolbaseurllower = ebooklti_get_url_thumbprint($tool->baseurl);

        if ($urllower === $toolbaseurllower) {
            // 100 points for exact thumbprint match.
            $tool->_matchscore += 100;
        } else if (substr($urllower, 0, strlen($toolbaseurllower)) === $toolbaseurllower) {
            // 50 points if tool thumbprint starts with the base URL thumbprint.
            $tool->_matchscore += 50;
        }

        // Prefer course tools over site tools.
        if (!empty($courseid)) {
            // Minus 10 points for not matching the course id (global tools).
            if ($tool->course != $courseid) {
                $tool->_matchscore -= 10;
            }
        }
    }

    $bestmatch = array_reduce($tools, function($value, $tool) {
        if ($tool->_matchscore > $value->_matchscore) {
            return $tool;
        } else {
            return $value;
        }

    }, (object)array('_matchscore' => -1));

    // None of the tools are suitable for this URL.
    if ($bestmatch->_matchscore <= 0) {
        return null;
    }

    return $bestmatch;
}

function ebooklti_get_shared_secrets_by_key($key) {
    global $DB;

    // Look up the shared secret for the specified key in both the types_config table (for configured tools)
    // And in the ebooklti resource table for ad-hoc tools.
    $query = "SELECT t2.value
                FROM {ebooklti_types_config} t1
                JOIN {ebooklti_types_config} t2 ON t1.typeid = t2.typeid
                JOIN {ebooklti_types} type ON t2.typeid = type.id
              WHERE t1.name = 'resourcekey'
                AND t1.value = :key1
                AND t2.name = 'password'
                AND type.state = :configured1
               UNION
              SELECT tp.secret AS value
                FROM {ebooklti_tool_proxies} tp
                JOIN {ebooklti_types} t ON tp.id = t.toolproxyid
              WHERE tp.guid = :key2
                AND t.state = :configured2
              UNION
             SELECT password AS value
               FROM {ebooklti}
              WHERE resourcekey = :key3";

    $sharedsecrets = $DB->get_records_sql($query, array('configured1' => EBOOKLTI_TOOL_STATE_CONFIGURED,
        'configured2' => EBOOKLTI_TOOL_STATE_CONFIGURED, 'key1' => $key, 'key2' => $key, 'key3' => $key));

    $values = array_map(function($item) {
        return $item->value;
    }, $sharedsecrets);

    // There should really only be one shared secret per key. But, we can't prevent
    // more than one getting entered. For instance, if the same key is used for two tool providers.
    return $values;
}

/**
 * Delete a Basic EBOOKLTI configuration
 *
 * @param int $id   Configuration id
 */
function ebooklti_delete_type($id) {
    global $DB;

    // We should probably just copy the launch URL to the tool instances in this case... using a single query.
    /*
    $instances = $DB->get_records('ebooklti', array('typeid' => $id));
    foreach ($instances as $instance) {
        $instance->typeid = 0;
        $DB->update_record('ebooklti', $instance);
    }*/

    $DB->delete_records('ebooklti_types', array('id' => $id));
    $DB->delete_records('ebooklti_types_config', array('typeid' => $id));
}

function ebooklti_set_state_for_type($id, $state) {
    global $DB;

    $DB->update_record('ebooklti_types', (object)array('id' => $id, 'state' => $state));
}

/**
 * Transforms a basic EBOOKLTI object to an array
 *
 * @param object $ebookltiobject    Basic EBOOKLTI object
 *
 * @return array Basic EBOOKLTI configuration details
 */
function ebooklti_get_config($ebookltiobject) {
    $typeconfig = (array)$ebookltiobject;
    $additionalconfig = ebooklti_get_type_config($ebookltiobject->typeid);
    $typeconfig = array_merge($typeconfig, $additionalconfig);
    return $typeconfig;
}

/**
 *
 * Generates some of the tool configuration based on the instance details
 *
 * @param int $id
 *
 * @return object configuration
 *
 */
function ebooklti_get_type_config_from_instance($id) {
    global $DB;

    $instance = $DB->get_record('ebooklti', array('id' => $id));
    $config = ebooklti_get_config($instance);

    $type = new \stdClass();
    $type->ebooklti_fix = $id;
    if (isset($config['toolurl'])) {
        $type->ebooklti_toolurl = $config['toolurl'];
    }
    if (isset($config['instructorchoicesendname'])) {
        $type->ebooklti_sendname = $config['instructorchoicesendname'];
    }
    if (isset($config['instructorchoicesendemailaddr'])) {
        $type->ebooklti_sendemailaddr = $config['instructorchoicesendemailaddr'];
    }
    if (isset($config['instructorchoiceacceptgrades'])) {
        $type->ebooklti_acceptgrades = $config['instructorchoiceacceptgrades'];
    }
    if (isset($config['instructorchoiceallowroster'])) {
        $type->ebooklti_allowroster = $config['instructorchoiceallowroster'];
    }

    if (isset($config['instructorcustomparameters'])) {
        $type->ebooklti_allowsetting = $config['instructorcustomparameters'];
    }
    return $type;
}

/**
 * Generates some of the tool configuration based on the admin configuration details
 *
 * @param int $id
 *
 * @return stdClass Configuration details
 */
function ebooklti_get_type_type_config($id) {
    global $DB;

    $basicebookltitype = $DB->get_record('ebooklti_types', array('id' => $id));
    $config = ebooklti_get_type_config($id);

    $type = new \stdClass();

    $type->ebooklti_typename = $basicebookltitype->name;

    $type->typeid = $basicebookltitype->id;

    $type->toolproxyid = $basicebookltitype->toolproxyid;

    $type->ebooklti_toolurl = $basicebookltitype->baseurl;

    $type->ebooklti_description = $basicebookltitype->description;

    $type->ebooklti_parameters = $basicebookltitype->parameter;

    $type->ebooklti_icon = $basicebookltitype->icon;

    $type->ebooklti_secureicon = $basicebookltitype->secureicon;

    if (isset($config['resourcekey'])) {
        $type->ebooklti_resourcekey = $config['resourcekey'];
    }
    if (isset($config['password'])) {
        $type->ebooklti_password = $config['password'];
    }

    if (isset($config['sendname'])) {
        $type->ebooklti_sendname = $config['sendname'];
    }
    if (isset($config['instructorchoicesendname'])) {
        $type->ebooklti_instructorchoicesendname = $config['instructorchoicesendname'];
    }
    if (isset($config['sendemailaddr'])) {
        $type->ebooklti_sendemailaddr = $config['sendemailaddr'];
    }
    if (isset($config['instructorchoicesendemailaddr'])) {
        $type->ebooklti_instructorchoicesendemailaddr = $config['instructorchoicesendemailaddr'];
    }
    if (isset($config['acceptgrades'])) {
        $type->ebooklti_acceptgrades = $config['acceptgrades'];
    }
    if (isset($config['instructorchoiceacceptgrades'])) {
        $type->ebooklti_instructorchoiceacceptgrades = $config['instructorchoiceacceptgrades'];
    }
    if (isset($config['allowroster'])) {
        $type->ebooklti_allowroster = $config['allowroster'];
    }
    if (isset($config['instructorchoiceallowroster'])) {
        $type->ebooklti_instructorchoiceallowroster = $config['instructorchoiceallowroster'];
    }

    if (isset($config['customparameters'])) {
        $type->ebooklti_customparameters = $config['customparameters'];
    }

    if (isset($config['forcessl'])) {
        $type->ebooklti_forcessl = $config['forcessl'];
    }

    if (isset($config['organizationid'])) {
        $type->ebooklti_organizationid = $config['organizationid'];
    }
    if (isset($config['organizationurl'])) {
        $type->ebooklti_organizationurl = $config['organizationurl'];
    }
    if (isset($config['organizationdescr'])) {
        $type->ebooklti_organizationdescr = $config['organizationdescr'];
    }
    if (isset($config['launchcontainer'])) {
        $type->ebooklti_launchcontainer = $config['launchcontainer'];
    }

    if (isset($config['coursevisible'])) {
        $type->ebooklti_coursevisible = $config['coursevisible'];
    }

    if (isset($config['contentitem'])) {
        $type->ebooklti_contentitem = $config['contentitem'];
    }

    if (isset($config['toolurl_ContentItemSelectionRequest'])) {
        $type->ebooklti_toolurl_ContentItemSelectionRequest = $config['toolurl_ContentItemSelectionRequest'];
    }

    if (isset($config['debuglaunch'])) {
        $type->ebooklti_debuglaunch = $config['debuglaunch'];
    }

    if (isset($config['module_class_type'])) {
        $type->ebooklti_module_class_type = $config['module_class_type'];
    }

    // Get the parameters from the ebooklti services.
    $services = ebooklti_get_services();
    $ebookltiserviceprefixlength = 16;
    foreach ($services as $service) {
        $configurationparameters = $service->get_configuration_parameter_names();
        foreach ($configurationparameters as $ebookltiserviceparameter) {
            $shortebookltiserviceparameter = substr($ebookltiserviceparameter, $ebookltiserviceprefixlength);
            if (isset($config[$shortebookltiserviceparameter])) {
                $type->$ebookltiserviceparameter = $config[$shortebookltiserviceparameter];
            }
        }
    }

    return $type;
}

function ebooklti_prepare_type_for_save($type, $config) {
    if (isset($config->ebooklti_toolurl)) {
        $type->baseurl = $config->ebooklti_toolurl;
        $type->tooldomain = ebooklti_get_domain_from_url($config->ebooklti_toolurl);
    }
    if (isset($config->ebooklti_description)) {
        $type->description = $config->ebooklti_description;
    }
    if (isset($config->ebooklti_typename)) {
        $type->name = $config->ebooklti_typename;
    }
    if (isset($config->ebooklti_coursevisible)) {
        $type->coursevisible = $config->ebooklti_coursevisible;
    }

    if (isset($config->ebooklti_icon)) {
        $type->icon = $config->ebooklti_icon;
    }
    if (isset($config->ebooklti_secureicon)) {
        $type->secureicon = $config->ebooklti_secureicon;
    }

    $type->forcessl = !empty($config->ebooklti_forcessl) ? $config->ebooklti_forcessl : 0;
    $config->ebooklti_forcessl = $type->forcessl;
    if (isset($config->ebooklti_contentitem)) {
        $type->contentitem = !empty($config->ebooklti_contentitem) ? $config->ebooklti_contentitem : 0;
        $config->ebooklti_contentitem = $type->contentitem;
    }
    if (isset($config->ebooklti_toolurl_ContentItemSelectionRequest)) {
        if (!empty($config->ebooklti_toolurl_ContentItemSelectionRequest)) {
            $type->toolurl_ContentItemSelectionRequest = $config->ebooklti_toolurl_ContentItemSelectionRequest;
        } else {
            $type->toolurl_ContentItemSelectionRequest = '';
        }
        $config->ebooklti_toolurl_ContentItemSelectionRequest = $type->toolurl_ContentItemSelectionRequest;
    }

    $type->timemodified = time();

    unset ($config->ebooklti_typename);
    unset ($config->ebooklti_toolurl);
    unset ($config->ebooklti_description);
    unset ($config->ebooklti_icon);
    unset ($config->ebooklti_secureicon);
}

function ebooklti_update_type($type, $config) {
    global $DB, $CFG;

    ebooklti_prepare_type_for_save($type, $config);

    if (ebooklti_request_is_using_ssl() && !empty($type->secureicon)) {
        $clearcache = !isset($config->oldicon) || ($config->oldicon !== $type->secureicon);
    } else {
        $clearcache = isset($type->icon) && (!isset($config->oldicon) || ($config->oldicon !== $type->icon));
    }
    unset($config->oldicon);

    if ($DB->update_record('ebooklti_types', $type)) {
        foreach ($config as $key => $value) {
            if (substr($key, 0, 9) == 'ebooklti_' && !is_null($value)) {
                $record = new \StdClass();
                $record->typeid = $type->id;
                $record->name = substr($key, 9);
                $record->value = $value;
                ebooklti_update_config($record);
            }
            if (substr($key, 0, 16) == 'ebookltiservice_' && !is_null($value)) { 
                $record = new \StdClass();
                $record->typeid = $type->id;
                $record->name = substr($key, 16);
                $record->value = $value;
                ebooklti_update_config($record);
            }
        }
        require_once($CFG->libdir.'/modinfolib.php');
        if ($clearcache) {
            $sql = "SELECT DISTINCT course
                      FROM {ebooklti}
                     WHERE typeid = ?";

            $courses = $DB->get_fieldset_sql($sql, array($type->id));

            foreach ($courses as $courseid) {
                rebuild_course_cache($courseid, true);
            }
        }
    }
}

function ebooklti_add_type($type, $config) {
    global $USER, $SITE, $DB;

    ebooklti_prepare_type_for_save($type, $config);

    if (!isset($type->state)) {
        $type->state = EBOOKLTI_TOOL_STATE_PENDING;
    }

    if (!isset($type->timecreated)) {
        $type->timecreated = time();
    }

    if (!isset($type->createdby)) {
        $type->createdby = $USER->id;
    }

    if (!isset($type->course)) {
        $type->course = $SITE->id;
    }

    // Create a salt value to be used for signing passed data to extension services
    // The outcome service uses the service salt on the instance. This can be used
    // for communication with services not related to a specific EBOOKLTI instance.
    $config->ebooklti_servicesalt = uniqid('', true);

    $id = $DB->insert_record('ebooklti_types', $type);

    if ($id) {
        foreach ($config as $key => $value) {
            if (!is_null($value)) {
                $fieldparts = preg_split("/(ebooklti|ebookltiservice)_/i", $key);
                // If array has only one element, it did not start with the pattern.
                if (count($fieldparts) < 2) {
                    continue;
                }
                $fieldname = $fieldparts[1];

                $record = new \StdClass();
                $record->typeid = $id;
                $record->name = $fieldname;
                $record->value = $value;

                ebooklti_add_config($record);
            }
        }
    }

    return $id;
}

/**
 * Given an array of tool proxies, filter them based on their state
 *
 * @param array $toolproxies An array of ebooklti_tool_proxies records
 * @param int $state One of the EBOOKLTI_TOOL_PROXY_STATE_* constants
 *
 * @return array
 */
function ebooklti_filter_tool_proxy_types(array $toolproxies, $state) {
    $return = array();
    foreach ($toolproxies as $key => $toolproxy) {
        if ($toolproxy->state == $state) {
            $return[$key] = $toolproxy;
        }
    }
    return $return;
}

/**
 * Get the tool proxy instance given its GUID
 *
 * @param string  $toolproxyguid   Tool proxy GUID value
 *
 * @return object
 */
function ebooklti_get_tool_proxy_from_guid($toolproxyguid) {
    global $DB;

    $toolproxy = $DB->get_record('ebooklti_tool_proxies', array('guid' => $toolproxyguid));

    return $toolproxy;
}

/**
 * Get the tool proxy instance given its registration URL
 *
 * @param string $regurl Tool proxy registration URL
 *
 * @return array The record of the tool proxy with this url
 */
function ebooklti_get_tool_proxies_from_registration_url($regurl) {
    global $DB;

    return $DB->get_records_sql(
        'SELECT * FROM {ebooklti_tool_proxies}
        WHERE '.$DB->sql_compare_text('regurl', 256).' = :regurl',
        array('regurl' => $regurl)
    );
}

/**
 * Generates some of the tool proxy configuration based on the admin configuration details
 *
 * @param int $id
 *
 * @return mixed Tool Proxy details
 */
function ebooklti_get_tool_proxy($id) {
    global $DB;

    $toolproxy = $DB->get_record('ebooklti_tool_proxies', array('id' => $id));
    return $toolproxy;
}

/**
 * Returns ebooklti tool proxies.
 *
 * @param bool $orphanedonly Only retrieves tool proxies that have no type associated with them
 * @return array of basicEBOOKLTI types
 */
function ebooklti_get_tool_proxies($orphanedonly) {
    global $DB;

    if ($orphanedonly) {
        $usedproxyids = array_values($DB->get_fieldset_select('ebooklti_types', 'toolproxyid', 'toolproxyid IS NOT NULL'));
        $proxies = $DB->get_records('ebooklti_tool_proxies', null, 'state DESC, timemodified DESC');
        foreach ($proxies as $key => $value) {
            if (in_array($value->id, $usedproxyids)) {
                unset($proxies[$key]);
            }
        }
        return $proxies;
    } else {
        return $DB->get_records('ebooklti_tool_proxies', null, 'state DESC, timemodified DESC');
    }
}

/**
 * Generates some of the tool proxy configuration based on the admin configuration details
 *
 * @param int $id
 *
 * @return mixed  Tool Proxy details
 */
function ebooklti_get_tool_proxy_config($id) {
    $toolproxy = ebooklti_get_tool_proxy($id);

    $tp = new \stdClass();
    $tp->ebooklti_registrationname = $toolproxy->name;
    $tp->toolproxyid = $toolproxy->id;
    $tp->state = $toolproxy->state;
    $tp->ebooklti_registrationurl = $toolproxy->regurl;
    $tp->ebooklti_capabilities = explode("\n", $toolproxy->capabilityoffered);
    $tp->ebooklti_services = explode("\n", $toolproxy->serviceoffered);

    return $tp;
}

/**
 * Update the database with a tool proxy instance
 *
 * @param object   $config    Tool proxy definition
 *
 * @return int  Record id number
 */
function ebooklti_add_tool_proxy($config) {
    global $USER, $DB;

    $toolproxy = new \stdClass();
    if (isset($config->ebooklti_registrationname)) {
        $toolproxy->name = trim($config->ebooklti_registrationname);
    }
    if (isset($config->ebooklti_registrationurl)) {
        $toolproxy->regurl = trim($config->ebooklti_registrationurl);
    }
    if (isset($config->ebooklti_capabilities)) {
        $toolproxy->capabilityoffered = implode("\n", $config->ebooklti_capabilities);
    } else {
        $toolproxy->capabilityoffered = implode("\n", array_keys(ebooklti_get_capabilities()));
    }
    if (isset($config->ebooklti_services)) {
        $toolproxy->serviceoffered = implode("\n", $config->ebooklti_services);
    } else {
        $func = function($s) {
            return $s->get_id();
        };
        $servicenames = array_map($func, ebooklti_get_services());
        $toolproxy->serviceoffered = implode("\n", $servicenames);
    }
    if (isset($config->toolproxyid) && !empty($config->toolproxyid)) {
        $toolproxy->id = $config->toolproxyid;
        if (!isset($toolproxy->state) || ($toolproxy->state != EBOOKLTI_TOOL_PROXY_STATE_ACCEPTED)) {
            $toolproxy->state = EBOOKLTI_TOOL_PROXY_STATE_CONFIGURED;
            $toolproxy->guid = random_string();
            $toolproxy->secret = random_string();
        }
        $id = ebooklti_update_tool_proxy($toolproxy);
    } else {
        $toolproxy->state = EBOOKLTI_TOOL_PROXY_STATE_CONFIGURED;
        $toolproxy->timemodified = time();
        $toolproxy->timecreated = $toolproxy->timemodified;
        if (!isset($toolproxy->createdby)) {
            $toolproxy->createdby = $USER->id;
        }
        $toolproxy->guid = random_string();
        $toolproxy->secret = random_string();
        $id = $DB->insert_record('ebooklti_tool_proxies', $toolproxy);
    }

    return $id;
}

/**
 * Updates a tool proxy in the database
 *
 * @param object  $toolproxy   Tool proxy
 *
 * @return int    Record id number
 */
function ebooklti_update_tool_proxy($toolproxy) {
    global $DB;

    $toolproxy->timemodified = time();
    $id = $DB->update_record('ebooklti_tool_proxies', $toolproxy);

    return $id;
}

/**
 * Delete a Tool Proxy
 *
 * @param int $id   Tool Proxy id
 */
function ebooklti_delete_tool_proxy($id) {
    global $DB;
    $DB->delete_records('ebooklti_tool_settings', array('toolproxyid' => $id));
    $tools = $DB->get_records('ebooklti_types', array('toolproxyid' => $id));
    foreach ($tools as $tool) {
        ebooklti_delete_type($tool->id);
    }
    $DB->delete_records('ebooklti_tool_proxies', array('id' => $id));
}

/**
 * Add a tool configuration in the database
 *
 * @param object $config   Tool configuration
 *
 * @return int Record id number
 */
function ebooklti_add_config($config) {
    global $DB;

    return $DB->insert_record('ebooklti_types_config', $config);
}

/**
 * Updates a tool configuration in the database
 *
 * @param object  $config   Tool configuration
 *
 * @return mixed Record id number
 */
function ebooklti_update_config($config) {
    global $DB;

    $old = $DB->get_record('ebooklti_types_config', array('typeid' => $config->typeid, 'name' => $config->name));

    if ($old) {
        $config->id = $old->id;
        $return = $DB->update_record('ebooklti_types_config', $config);
    } else {
        $return = $DB->insert_record('ebooklti_types_config', $config);
    }
    return $return;
}

/**
 * Gets the tool settings
 *
 * @param int  $toolproxyid   Id of tool proxy record
 * @param int  $courseid      Id of course (null if system settings)
 * @param int  $instanceid    Id of course module (null if system or context settings)
 *
 * @return array  Array settings
 */
function ebooklti_get_tool_settings($toolproxyid, $courseid = null, $instanceid = null) {
    global $DB;

    $settings = array();
    $settingsstr = $DB->get_field('ebooklti_tool_settings', 'settings', array('toolproxyid' => $toolproxyid,
        'course' => $courseid, 'coursemoduleid' => $instanceid));
    if ($settingsstr !== false) {
        $settings = json_decode($settingsstr, true);
    }
    return $settings;
}

/**
 * Sets the tool settings (
 *
 * @param array  $settings      Array of settings
 * @param int    $toolproxyid   Id of tool proxy record
 * @param int    $courseid      Id of course (null if system settings)
 * @param int    $instanceid    Id of course module (null if system or context settings)
 */
function ebooklti_set_tool_settings($settings, $toolproxyid, $courseid = null, $instanceid = null) {
    global $DB;

    $json = json_encode($settings);
    $record = $DB->get_record('ebooklti_tool_settings', array('toolproxyid' => $toolproxyid,
        'course' => $courseid, 'coursemoduleid' => $instanceid));
    if ($record !== false) {
        $DB->update_record('ebooklti_tool_settings', (object)array('id' => $record->id, 'settings' => $json, 'timemodified' => time()));
    } else {
        $record = new \stdClass();
        $record->toolproxyid = $toolproxyid;
        $record->course = $courseid;
        $record->coursemoduleid = $instanceid;
        $record->settings = $json;
        $record->timecreated = time();
        $record->timemodified = $record->timecreated;
        $DB->insert_record('ebooklti_tool_settings', $record);
    }
}

/**
 * Signs the petition to launch the ebooklti external tool using OAuth
 *
 * @param array  $oldparms     Parameters to be passed for signing
 * @param string $endpoint     url of the external tool
 * @param string $method       Method for sending the parameters (e.g. POST)
 * @param string $oauthconsumerkey
 * @param string $oauthconsumersecret
 * @return array|null
 */
function ebooklti_sign_parameters($oldparms, $endpoint, $method, $oauthconsumerkey, $oauthconsumersecret) {

    $parms = $oldparms;

    $testtoken = '';

    // TODO: Switch to core oauthlib once implemented - MDL-30149.
    $hmacmethod = new ebooklti\OAuthSignatureMethod_HMAC_SHA1();
    $testconsumer = new ebooklti\OAuthConsumer($oauthconsumerkey, $oauthconsumersecret, null);
    $accreq = ebooklti\OAuthRequest::from_consumer_and_token($testconsumer, $testtoken, $method, $endpoint, $parms);
    $accreq->sign_request($hmacmethod, $testconsumer, $testtoken);

    $newparms = $accreq->get_parameters();

    return $newparms;
}

/**
 * Posts the launch petition HTML
 *
 * @param array $newparms   Signed parameters
 * @param string $endpoint  URL of the ebooklti external tool
 * @param bool $debug       Debug (true/false)
 * @return string
 */
function ebooklti_post_launch_html($newparms, $endpoint, $debug=false) {
    
	$r = "<form action=\"" . $endpoint .
        "\" name=\"ebookltiLaunchForm\" id=\"ebookltiLaunchForm\" method=\"post\" encType=\"application/x-www-form-urlencoded\">\n";

    // Contruct html for the launch parameters.
    foreach ($newparms as $key => $value) {
        $key = htmlspecialchars($key);
        $value = htmlspecialchars($value);
        if ( $key == "ext_submit" ) {
            $r .= "<input type=\"submit\"";
        } else {
            $r .= "<input type=\"hidden\" name=\"{$key}\"";
        }
        $r .= " value=\"";
        $r .= $value;
        $r .= "\"/>\n";
    }
	
    if ( $debug ) {
        $r .= "<script language=\"javascript\"> \n";
        $r .= "  //<![CDATA[ \n";
        $r .= "function basicebookltiDebugToggle() {\n";
        $r .= "    var ele = document.getElementById(\"basicebookltiDebug\");\n";
        $r .= "    if (ele.style.display == \"block\") {\n";
        $r .= "        ele.style.display = \"none\";\n";
        $r .= "    }\n";
        $r .= "    else {\n";
        $r .= "        ele.style.display = \"block\";\n";
        $r .= "    }\n";
        $r .= "} \n";
        $r .= "  //]]> \n";
        $r .= "</script>\n";
        $r .= "<a id=\"displayText\" href=\"javascript:basicebookltiDebugToggle();\">";
        $r .= get_string("toggle_debug_data", "ebooklti")."</a>\n";
        $r .= "<div id=\"basicebookltiDebug\" style=\"display:none\">\n";
        $r .= "<b>".get_string("basicebooklti_endpoint", "ebooklti")."</b><br/>\n";
        $r .= $endpoint . "<br/>\n&nbsp;<br/>\n";
        $r .= "<b>".get_string("basicebooklti_parameters", "ebooklti")."</b><br/>\n";
        foreach ($newparms as $key => $value) {
            $key = htmlspecialchars($key);
            $value = htmlspecialchars($value);
            $r .= "$key = $value<br/>\n";
        }
        $r .= "&nbsp;<br/>\n";
        $r .= "</div>\n";
    }
    $r .= "</form>\n";
	
    if (!$debug ) {
        $r .= " <script type=\"text/javascript\"> \n" .
            "  //<![CDATA[ \n" .
            "    document.ebookltiLaunchForm.submit(); \n" .
            "  //]]> \n" .
            " </script> \n";
    } 
	
    return $r;
}

function ebooklti_get_type($typeid) {
    global $DB;

    return $DB->get_record('ebooklti_types', array('id' => $typeid));
}

function ebooklti_get_launch_container($ebooklti, $toolconfig) {
    if (empty($ebooklti->launchcontainer)) {
        $ebooklti->launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_DEFAULT;
    }

    if ($ebooklti->launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_DEFAULT) {
        if (isset($toolconfig['launchcontainer'])) {
            $launchcontainer = $toolconfig['launchcontainer'];
        }
    } else {
        $launchcontainer = $ebooklti->launchcontainer;
    }

    if (empty($launchcontainer) || $launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_DEFAULT) {
        $launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS;
    }

    $devicetype = core_useragent::get_device_type();

    // Scrolling within the object element doesn't work on iOS or Android
    // Opening the popup window also had some issues in testing
    // For mobile devices, always take up the entire screen to ensure the best experience.
    if ($devicetype === core_useragent::DEVICETYPE_MOBILE || $devicetype === core_useragent::DEVICETYPE_TABLET ) {
        $launchcontainer = EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW;
    }

    return $launchcontainer;
}

function ebooklti_request_is_using_ssl() {
    global $CFG;
    return (stripos($CFG->wwwroot, 'https://') === 0);
}

function ebooklti_ensure_url_is_https($url) {
    if (!strstr($url, '://')) {
        $url = 'https://' . $url;
    } else {
        // If the URL starts with http, replace with https.
        if (stripos($url, 'http://') === 0) {
            $url = 'https://' . substr($url, 7);
        }
    }

    return $url;
}

/**
 * Determines if we should try to log the request
 *
 * @param string $rawbody
 * @return bool
 */
function ebooklti_should_log_request($rawbody) {
    global $CFG;

    if (empty($CFG->mod_ebooklti_log_users)) {
        return false;
    }

    $logusers = explode(',', $CFG->mod_ebooklti_log_users);
    if (empty($logusers)) {
        return false;
    }

    try {
        $xml = new \SimpleXMLElement($rawbody);
        $ns  = $xml->getNamespaces();
        $ns  = array_shift($ns);
        $xml->registerXPathNamespace('ebooklti', $ns);
        $requestuserid = '';
        if ($node = $xml->xpath('//ebooklti:userId')) {
            $node = $node[0];
            $requestuserid = clean_param((string) $node, PARAM_INT);
        } else if ($node = $xml->xpath('//ebooklti:sourcedId')) {
            $node = $node[0];
            $resultjson = json_decode((string) $node);
            $requestuserid = clean_param($resultjson->data->userid, PARAM_INT);
        }
    } catch (Exception $e) {
        return false;
    }

    if (empty($requestuserid) or !in_array($requestuserid, $logusers)) {
        return false;
    }

    return true;
}

/**
 * Logs the request to a file in temp dir.
 *
 * @param string $rawbody
 */
function ebooklti_log_request($rawbody) {
    if ($tempdir = make_temp_directory('mod_ebooklti', false)) {
        if ($tempfile = tempnam($tempdir, 'mod_ebooklti_request'.date('YmdHis'))) {
            $content  = "Request Headers:\n";
            foreach (moodle\mod\ebooklti\OAuthUtil::get_headers() as $header => $value) {
                $content .= "$header: $value\n";
            }
            $content .= "Request Body:\n";
            $content .= $rawbody;

            file_put_contents($tempfile, $content);
            chmod($tempfile, 0644);
        }
    }
}

/**
 * Log an EBOOKLTI response.
 *
 * @param string $responsexml The response XML
 * @param Exception $e If there was an exception, pass that too
 */
function ebooklti_log_response($responsexml, $e = null) {
    if ($tempdir = make_temp_directory('mod_ebooklti', false)) {
        if ($tempfile = tempnam($tempdir, 'mod_ebooklti_response'.date('YmdHis'))) {
            $content = '';
            if ($e instanceof Exception) {
                $info = get_exception_info($e);

                $content .= "Exception:\n";
                $content .= "Message: $info->message\n";
                $content .= "Debug info: $info->debuginfo\n";
                $content .= "Backtrace:\n";
                $content .= format_backtrace($info->backtrace, true);
                $content .= "\n";
            }
            $content .= "Response XML:\n";
            $content .= $responsexml;

            file_put_contents($tempfile, $content);
            chmod($tempfile, 0644);
        }
    }
}

/**
 * Fetches EBOOKLTI type configuration for an EBOOKLTI instance
 *
 * @param stdClass $instance
 * @return array Can be empty if no type is found
 */
function ebooklti_get_type_config_by_instance($instance) {
    $typeid = null;
    if (empty($instance->typeid)) {
		if(!property_exists($instance,'toolurl')){ $instance->toolurl = ''; }
        $tool = ebooklti_get_tool_by_url_match($instance->toolurl, $instance->course);
        if ($tool) {
            $typeid = $tool->id;
        }
    } else {
        $typeid = $instance->typeid;
    }
    if (!empty($typeid)) {
        return ebooklti_get_type_config($typeid);
    }
    return array();
}

/**
 * Enforce type config settings onto the EBOOKLTI instance
 *
 * @param stdClass $instance
 * @param array $typeconfig
 */
function ebooklti_force_type_config_settings($instance, array $typeconfig) {
    $forced = array(
        'instructorchoicesendname'      => 'sendname',
        'instructorchoicesendemailaddr' => 'sendemailaddr',
        'instructorchoiceacceptgrades'  => 'acceptgrades',
    );

    foreach ($forced as $instanceparam => $typeconfigparam) {
        if (array_key_exists($typeconfigparam, $typeconfig) && $typeconfig[$typeconfigparam] != EBOOKLTI_SETTING_DELEGATE) {
            $instance->$instanceparam = $typeconfig[$typeconfigparam];
        }
    }
}

/**
 * Initializes an array with the capabilities supported by the EBOOKLTI module
 *
 * @return array List of capability names (without a dollar sign prefix)
 */
function ebooklti_get_capabilities() {

    $capabilities = array(
       'basic-lti-launch-request' => '',
       'ContentItemSelectionRequest' => '',
       'ToolProxyRegistrationRequest' => '',
       'Context.id' => 'context_id',
       'Context.title' => 'context_title',
       'Context.label' => 'context_label',
       'Context.sourcedId' => 'lis_course_section_sourcedid',
       'Context.longDescription' => '$COURSE->summary',
       'Context.timeFrame.begin' => '$COURSE->startdate',
       'CourseSection.title' => 'context_title',
       'CourseSection.label' => 'context_label',
       'CourseSection.sourcedId' => 'lis_course_section_sourcedid',
       'CourseSection.longDescription' => '$COURSE->summary',
       'CourseSection.timeFrame.begin' => '$COURSE->startdate',
       'ResourceLink.id' => 'resource_link_id',
       'ResourceLink.title' => 'resource_link_title',
       'ResourceLink.description' => 'resource_link_description',
       'User.id' => 'user_id',
       'User.username' => '$USER->username',
       'Person.name.full' => 'lis_person_name_full',
       'Person.name.given' => 'lis_person_name_given',
       'Person.name.family' => 'lis_person_name_family',
       'Person.email.primary' => 'lis_person_contact_email_primary',
       'Person.sourcedId' => 'lis_person_sourcedid',
       'Person.name.middle' => '$USER->middlename',
       'Person.address.street1' => '$USER->address',
       'Person.address.locality' => '$USER->city',
       'Person.address.country' => '$USER->country',
       'Person.address.timezone' => '$USER->timezone',
       'Person.phone.primary' => '$USER->phone1',
       'Person.phone.mobile' => '$USER->phone2',
       'Person.webaddress' => '$USER->url',
       'Membership.role' => 'roles',
       'Result.sourcedId' => 'lis_result_sourcedid',
       'Result.autocreate' => 'lis_outcome_service_url',
       'Moodle.Person.userGroupIds' => null);

    return $capabilities;

}

/**
 * Initializes an array with the services supported by the EBOOKLTI module
 *
 * @return array List of services
 */
function ebooklti_get_services() {

    $services = array();
    $definedservices = core_component::get_plugin_list('ebookltiservice');
    foreach ($definedservices as $name => $location) {
        $classname = "\\ebookltiservice_{$name}\\local\\service\\{$name}";
        $services[] = new $classname();
    }

    return $services;

}

/**
 * Initializes an instance of the named service
 *
 * @param string $servicename Name of service
 *
 * @return bool|\mod_ebooklti\local\ebookltiservice\service_base Service
 */
function ebooklti_get_service_by_name($servicename) {

    $service = false;
    $classname = "\\ebookltiservice_{$servicename}\\local\\service\\{$servicename}";
    if (class_exists($classname)) {
        $service = new $classname();
    }

    return $service;

}

/**
 * Finds a service by id
 *
 * @param \mod_ebooklti\local\ebookltiservice\service_base[] $services Array of services
 * @param string $resourceid  ID of resource
 *
 * @return mod_ebooklti\local\ebookltiservice\service_base Service
 */
function ebooklti_get_service_by_resource_id($services, $resourceid) {

    $service = false;
    foreach ($services as $aservice) {
        foreach ($aservice->get_resources() as $resource) {
            if ($resource->get_id() === $resourceid) {
                $service = $aservice;
                break 2;
            }
        }
    }

    return $service;

}

/**
 * Extracts the named contexts from a tool proxy
 *
 * @param object $json
 *
 * @return array Contexts
 */
function ebooklti_get_contexts($json) {

    $contexts = array();
    if (isset($json->{'@context'})) {
        foreach ($json->{'@context'} as $context) {
            if (is_object($context)) {
                $contexts = array_merge(get_object_vars($context), $contexts);
            }
        }
    }

    return $contexts;

}

/**
 * Converts an ID to a fully-qualified ID
 *
 * @param array $contexts
 * @param string $id
 *
 * @return string Fully-qualified ID
 */
function ebooklti_get_fqid($contexts, $id) {

    $parts = explode(':', $id, 2);
    if (count($parts) > 1) {
        if (array_key_exists($parts[0], $contexts)) {
            $id = $contexts[$parts[0]] . $parts[1];
        }
    }

    return $id;

}

/**
 * Returns the icon for the given tool type
 *
 * @param stdClass $type The tool type
 *
 * @return string The url to the tool type's corresponding icon
 */
function ebooklti_get_tool_type_icon_url(stdClass $type) {
    global $OUTPUT;

    $iconurl = $type->secureicon;

    if (empty($iconurl)) {
        $iconurl = $type->icon;
    }

    if (empty($iconurl)) {
        $iconurl = $OUTPUT->image_url('icon', 'ebooklti')->out();
    }

    return $iconurl;
}

/**
 * Returns the edit url for the given tool type
 *
 * @param stdClass $type The tool type
 *
 * @return string The url to edit the tool type
 */
function ebooklti_get_tool_type_edit_url(stdClass $type) {
    $url = new moodle_url('/mod/ebooklti/typessettings.php',
                          array('action' => 'update', 'id' => $type->id, 'sesskey' => sesskey(), 'returnto' => 'toolconfigure'));
    return $url->out();
}

/**
 * Returns the edit url for the given tool proxy.
 *
 * @param stdClass $proxy The tool proxy
 *
 * @return string The url to edit the tool type
 */
function ebooklti_get_tool_proxy_edit_url(stdClass $proxy) {
    $url = new moodle_url('/mod/ebooklti/registersettings.php',
                          array('action' => 'update', 'id' => $proxy->id, 'sesskey' => sesskey(), 'returnto' => 'toolconfigure'));
    return $url->out();
}

/**
 * Returns the course url for the given tool type
 *
 * @param stdClass $type The tool type
 *
 * @return string The url to the course of the tool type, void if it is a site wide type
 */
function ebooklti_get_tool_type_course_url(stdClass $type) {
    if ($type->course != 1) {
        $url = new moodle_url('/course/view.php', array('id' => $type->course));
        return $url->out();
    }
    return null;
}

/**
 * Returns the icon and edit urls for the tool type and the course url if it is a course type.
 *
 * @param stdClass $type The tool type
 *
 * @return array The urls of the tool type
 */
function ebooklti_get_tool_type_urls(stdClass $type) {
    $courseurl = ebooklti_get_tool_type_course_url($type);

    $urls = array(
        'icon' => ebooklti_get_tool_type_icon_url($type),
        'edit' => ebooklti_get_tool_type_edit_url($type),
    );

    if ($courseurl) {
        $urls['course'] = $courseurl;
    }

    return $urls;
}

/**
 * Returns the icon and edit urls for the tool proxy.
 *
 * @param stdClass $proxy The tool proxy
 *
 * @return array The urls of the tool proxy
 */
function ebooklti_get_tool_proxy_urls(stdClass $proxy) {
    global $OUTPUT;

    $urls = array(
        'icon' => $OUTPUT->image_url('icon', 'ebooklti')->out(),
        'edit' => ebooklti_get_tool_proxy_edit_url($proxy),
    );

    return $urls;
}

/**
 * Returns information on the current state of the tool type
 *
 * @param stdClass $type The tool type
 *
 * @return array An array with a text description of the state, and boolean for whether it is in each state:
 * pending, configured, rejected, unknown
 */
function ebooklti_get_tool_type_state_info(stdClass $type) {
    $isconfigured = false;
    $ispending = false;
    $isrejected = false;
    $isunknown = false;
    switch ($type->state) {
        case EBOOKLTI_TOOL_STATE_CONFIGURED:
            $state = get_string('active', 'mod_ebooklti');
            $isconfigured = true;
            break;
        case EBOOKLTI_TOOL_STATE_PENDING:
            $state = get_string('pending', 'mod_ebooklti');
            $ispending = true;
            break;
        case EBOOKLTI_TOOL_STATE_REJECTED:
            $state = get_string('rejected', 'mod_ebooklti');
            $isrejected = true;
            break;
        default:
            $state = get_string('unknownstate', 'mod_ebooklti');
            $isunknown = true;
            break;
    }

    return array(
        'text' => $state,
        'pending' => $ispending,
        'configured' => $isconfigured,
        'rejected' => $isrejected,
        'unknown' => $isunknown
    );
}

/**
 * Returns a summary of each EBOOKLTI capability this tool type requires in plain language
 *
 * @param stdClass $type The tool type
 *
 * @return array An array of text descriptions of each of the capabilities this tool type requires
 */
function ebooklti_get_tool_type_capability_groups($type) {
    $capabilities = ebooklti_get_enabled_capabilities($type);
    $groups = array();
    $hascourse = false;
    $hasactivities = false;
    $hasuseraccount = false;
    $hasuserpersonal = false;

    foreach ($capabilities as $capability) {
        // Bail out early if we've already found all groups.
        if (count($groups) >= 4) {
            continue;
        }

        if (!$hascourse && preg_match('/^CourseSection/', $capability)) {
            $hascourse = true;
            $groups[] = get_string('courseinformation', 'mod_ebooklti');
        } else if (!$hasactivities && preg_match('/^ResourceLink/', $capability)) {
            $hasactivities = true;
            $groups[] = get_string('courseactivitiesorresources', 'mod_ebooklti');
        } else if (!$hasuseraccount && preg_match('/^User/', $capability) || preg_match('/^Membership/', $capability)) {
            $hasuseraccount = true;
            $groups[] = get_string('useraccountinformation', 'mod_ebooklti');
        } else if (!$hasuserpersonal && preg_match('/^Person/', $capability)) {
            $hasuserpersonal = true;
            $groups[] = get_string('userpersonalinformation', 'mod_ebooklti');
        }
    }

    return $groups;
}


/**
 * Returns the ids of each instance of this tool type
 *
 * @param stdClass $type The tool type
 *
 * @return array An array of ids of the instances of this tool type
 */
function ebooklti_get_tool_type_instance_ids($type) {
    global $DB;

    return array_keys($DB->get_fieldset_select('ebooklti', 'id', 'typeid = ?', array($type->id)));
}

/**
 * Serialises this tool type
 *
 * @param stdClass $type The tool type
 *
 * @return array An array of values representing this type
 */
function ebooklti_serialise_tool_type(stdClass $type) {
    $capabilitygroups = ebooklti_get_tool_type_capability_groups($type);
    $instanceids = ebooklti_get_tool_type_instance_ids($type);
    // Clean the name. We don't want tags here.
    $name = clean_param($type->name, PARAM_NOTAGS);
    if (!empty($type->description)) {
        // Clean the description. We don't want tags here.
        $description = clean_param($type->description, PARAM_NOTAGS);
    } else {
        $description = get_string('editdescription', 'mod_ebooklti');
    }
    return array(
        'id' => $type->id,
        'name' => $name,
        'description' => $description,
        'urls' => ebooklti_get_tool_type_urls($type),
        'state' => ebooklti_get_tool_type_state_info($type),
        'hascapabilitygroups' => !empty($capabilitygroups),
        'capabilitygroups' => $capabilitygroups,
        // Course ID of 1 means it's not linked to a course.
        'courseid' => $type->course == 1 ? 0 : $type->course,
        'instanceids' => $instanceids,
        'instancecount' => count($instanceids)
    );
}

/**
 * Serialises this tool proxy.
 *
 * @param stdClass $proxy The tool proxy
 *
 * @return array An array of values representing this type
 */
function ebooklti_serialise_tool_proxy(stdClass $proxy) { 
    return array(
        'id' => $proxy->id,
        'name' => $proxy->name,
        'description' => get_string('activatetoadddescription', 'mod_ebooklti'),
        'urls' => ebooklti_get_tool_proxy_urls($proxy),
        'state' => array(
            'text' => get_string('pending', 'mod_ebooklti'),
            'pending' => true,
            'configured' => false,
            'rejected' => false,
            'unknown' => false
        ),
        'hascapabilitygroups' => true,
        'capabilitygroups' => array(),
        'courseid' => 0,
        'instanceids' => array(),
        'instancecount' => 0
    );
}

/**
 * Loads the cartridge information into the tool type, if the launch url is for a cartridge file
 *
 * @param stdClass $type The tool type object to be filled in
 * @since Moodle 3.1
 */
function ebooklti_load_type_if_cartridge($type) {
    if (!empty($type->ebooklti_toolurl) && ebooklti_is_cartridge($type->ebooklti_toolurl)) {
        ebooklti_load_type_from_cartridge($type->ebooklti_toolurl, $type);
    }
}

/**
 * Loads the cartridge information into the new tool, if the launch url is for a cartridge file
 *
 * @param stdClass $ebooklti The tools config
 * @since Moodle 3.1
 */
function ebooklti_load_tool_if_cartridge($ebooklti) {
    if (!empty($ebooklti->toolurl) && ebooklti_is_cartridge($ebooklti->toolurl)) {
        ebooklti_load_tool_from_cartridge($ebooklti->toolurl, $ebooklti);
    }
}

/**
 * Determines if the given url is for a IMS basic cartridge
 *
 * @param  string $url The url to be checked
 * @return True if the url is for a cartridge
 * @since Moodle 3.1
 */
function ebooklti_is_cartridge($url) {
    // If it is empty, it's not a cartridge.
    if (empty($url)) {
        return false;
    }
    // If it has xml at the end of the url, it's a cartridge.
    if (preg_match('/\.xml$/', $url)) {
        return true;
    }
    // Even if it doesn't have .xml, load the url to check if it's a cartridge..
    try {
        $toolinfo = ebooklti_load_cartridge($url,
            array(
                "launch_url" => "launchurl"
            )
        );
        if (!empty($toolinfo['launchurl'])) {
            return true;
        }
    } catch (moodle_exception $e) {
        return false; // Error loading the xml, so it's not a cartridge.
    }
    return false;
}

/**
 * Allows you to load settings for an ebooklti external tool type from an IMS cartridge.
 *
 * @param  string   $url     The URL to the cartridge
 * @param  stdClass $type    The tool type object to be filled in
 * @throws moodle_exception if the cartridge could not be loaded correctly
 * @since Moodle 3.1
 */
function ebooklti_load_type_from_cartridge($url, $type) {
    $toolinfo = ebooklti_load_cartridge($url,
        array(
            "title" => "ebooklti_typename",
            "launch_url" => "ebooklti_toolurl",
            "description" => "ebooklti_description",
            "icon" => "ebooklti_icon",
            "secure_icon" => "ebooklti_secureicon"
        ),
        array(
            "icon_url" => "ebooklti_extension_icon",
            "secure_icon_url" => "ebooklti_extension_secureicon"
        )
    );
    // If an activity name exists, unset the cartridge name so we don't override it.
    if (isset($type->ebooklti_typename)) {
        unset($toolinfo['ebooklti_typename']);
    }

    // Always prefer cartridge core icons first, then, if none are found, look at the extension icons.
    if (empty($toolinfo['ebooklti_icon']) && !empty($toolinfo['ebooklti_extension_icon'])) {
        $toolinfo['ebooklti_icon'] = $toolinfo['ebooklti_extension_icon'];
    }
    unset($toolinfo['ebooklti_extension_icon']);

    if (empty($toolinfo['ebooklti_secureicon']) && !empty($toolinfo['ebooklti_extension_secureicon'])) {
        $toolinfo['ebooklti_secureicon'] = $toolinfo['ebooklti_extension_secureicon'];
    }
    unset($toolinfo['ebooklti_extension_secureicon']);

    // Ensure Custom icons aren't overridden by cartridge params.
    if (!empty($type->ebooklti_icon)) {
        unset($toolinfo['ebooklti_icon']);
    }

    if (!empty($type->ebooklti_secureicon)) {
        unset($toolinfo['ebooklti_secureicon']);
    }

    foreach ($toolinfo as $property => $value) {
        $type->$property = $value;
    }
}

/**
 * Allows you to load in the configuration for an ebooklti external tool from an IMS cartridge.
 *
 * @param  string   $url    The URL to the cartridge
 * @param  stdClass $ebooklti    EBOOKLTI object
 * @throws moodle_exception if the cartridge could not be loaded correctly
 * @since Moodle 3.1
 */
function ebooklti_load_tool_from_cartridge($url, $ebooklti) {
    $toolinfo = ebooklti_load_cartridge($url,
        array(
            "title" => "name",
            "launch_url" => "toolurl",
            "secure_launch_url" => "securetoolurl",
            "description" => "intro",
            "icon" => "icon",
            "secure_icon" => "secureicon"
        ),
        array(
            "icon_url" => "extension_icon",
            "secure_icon_url" => "extension_secureicon"
        )
    );
    // If an activity name exists, unset the cartridge name so we don't override it.
    if (isset($ebooklti->name)) {
        unset($toolinfo['name']);
    }

    // Always prefer cartridge core icons first, then, if none are found, look at the extension icons.
    if (empty($toolinfo['icon']) && !empty($toolinfo['extension_icon'])) {
        $toolinfo['icon'] = $toolinfo['extension_icon'];
    }
    unset($toolinfo['extension_icon']);

    if (empty($toolinfo['secureicon']) && !empty($toolinfo['extension_secureicon'])) {
        $toolinfo['secureicon'] = $toolinfo['extension_secureicon'];
    }
    unset($toolinfo['extension_secureicon']);

    foreach ($toolinfo as $property => $value) {
        $ebooklti->$property = $value;
    }
}

/**
 * Search for a tag within an XML DOMDocument
 *
 * @param  string $url The url of the cartridge to be loaded
 * @param  array  $map The map of tags to keys in the return array
 * @param  array  $propertiesmap The map of properties to keys in the return array
 * @return array An associative array with the given keys and their values from the cartridge
 * @throws moodle_exception if the cartridge could not be loaded correctly
 * @since Moodle 3.1
 */
function ebooklti_load_cartridge($url, $map, $propertiesmap = array()) {
    global $CFG;
    require_once($CFG->libdir. "/filelib.php");

    $curl = new curl();
    $response = $curl->get($url);

    // TODO MDL-46023 Replace this code with a call to the new library.
    $origerrors = libxml_use_internal_errors(true);
    $origentity = libxml_disable_entity_loader(true);
    libxml_clear_errors();

    $document = new DOMDocument();
    @$document->loadXML($response, LIBXML_DTDLOAD | LIBXML_DTDATTR);

    $cartridge = new DomXpath($document);

    $errors = libxml_get_errors();

    libxml_clear_errors();
    libxml_use_internal_errors($origerrors);
    libxml_disable_entity_loader($origentity);

    if (count($errors) > 0) {
        $message = 'Failed to load cartridge.';
        foreach ($errors as $error) {
            $message .= "\n" . trim($error->message, "\n\r\t .") . " at line " . $error->line;
        }
        throw new moodle_exception('errorreadingfile', '', '', $url, $message);
    }

    $toolinfo = array();
    foreach ($map as $tag => $key) {
        $value = ebooklti_get_tag($tag, $cartridge);
        if ($value) {
            $toolinfo[$key] = $value;
        }
    }
    if (!empty($propertiesmap)) {
        foreach ($propertiesmap as $property => $key) {
            $value = ebooklti_get_tag("property", $cartridge, $property);
            if ($value) {
                $toolinfo[$key] = $value;
            }
        }
    }

    return $toolinfo;
}

/**
 * Search for a tag within an XML DOMDocument
 *
 * @param  stdClass $tagname The name of the tag to search for
 * @param  XPath    $xpath   The XML to find the tag in
 * @param  XPath    $attribute The attribute to search for (if we should search for a child node with the given
 * value for the name attribute
 * @since Moodle 3.1
 */
function ebooklti_get_tag($tagname, $xpath, $attribute = null) {
    if ($attribute) {
        $result = $xpath->query('//*[local-name() = \'' . $tagname . '\'][@name="' . $attribute . '"]');
    } else {
        $result = $xpath->query('//*[local-name() = \'' . $tagname . '\']');
    }
    if ($result->length > 0) {
        return $result->item(0)->nodeValue;
    }
    return null;
}

// Get OCP ID
function ebooklti_get_ocpid($person_id, $id_number) {

    $operation = 'validateuser';
    $paramone = $person_id;
    $response = RestCurl::get($operation, array($paramone));

    if ($response->Data == 1) {

        // $operation = 'getcoursesbyusername';
        $operation = 'GetActiveCoursesByUserName';
        $paramone = $person_id;
        $result = RestCurl::get($operation, array($paramone));
        //return OCPID
        $arr = $result->Data->Course;
        foreach ($arr as $value) {
            if (strtoupper(trim($value->courseID)) === strtoupper(trim($id_number))) {
                //print_r($value->ocpid);
                return $value->ocpid;
            }
        }

        return false;
    } else {
        // throw error
        throw new Exception('This personID, ' . $person_id . ', does not belong to a valid user.');
    }
}

// Get Expiry Date
function ebooklti_get_expirydate($ocp_id) {

    $operation = 'getcoursebyocpid';
    $paramone = $ocp_id;
    $response = RestCurl::get($operation, array($paramone));
    $timestring = $response->Data->dateExpire;
    $d = new DateTime($timestring, new DateTimeZone('America/New_York'));
    $t = $d->getTimestamp();
    $timestamp = (string) $t;
    return $timestamp;
}

// Get list of chapters, assessments, Manage Groups and Manage Reports from op2

function ebooklti_get_list_ofchpaterandassessment() {

    global $DB, $CFG, $COURSE, $USER;

    //Stop displaying options of assessments,groups,reports  for editing teacher and below roles
    $coursecontext = context_course::instance($COURSE->id);

    $url = $CFG->op2_get_chpatersandassessments_url;
    $fields_string = 'courseCode=' . $COURSE->idnumber;
    //$fields_string = 'courseCode=97812841693795E44B5';
    $urlwithparam = $url . $fields_string;
    //Initiate curl
    $ch = curl_init();
    //Disable SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    //Receive server response ...
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //Set the url
    curl_setopt($ch, CURLOPT_URL, $urlwithparam);
    //Execute
    $response = curl_exec($ch); //echo "<pre>"; print_r(curl_getinfo($ch)); print_r($response); die;
    //Closing
    curl_close($ch);
    $response = json_decode($response, true);

    $chapters_array = array();
    $assessments_array = array();

    // parsing json and creating array that we need
    foreach ($response as $arr => $a) {

        if ($arr === "chapters") {

            foreach ($a as $item) {
                $key = "chapter||" . $item['chapterId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['chapterTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "chapters")

        if ($arr === "diagnosticExercise") {

            foreach ($a as $item) {
                $key = "diagnosticExercise||" . $item['diagnosticId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['diagnosticExerciseTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "diagnosticExercise")
        
        if ($arr === "topics") {

            foreach ($a as $item) {
                $key = "topic||" . $item['topicId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['topicTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "topics")
        
        if ($arr === "chapter_media") {

            foreach ($a as $item) {
                $key = "chapter_media||" . $item['mediaId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['mediaTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "chapter_media")

        if ($arr === "groups") {

            foreach ($a as $item) {
                $key = "group||" . $item['groupId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['groupTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "groups")

        if ($arr === "reports") {

            foreach ($a as $item) {
                $key = "report||" . $item['reportId'] . "||" . $item['resourceLinkId'] . "||0"; // default to 0
                $value = $item['reportTitle'];
                $chapters_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "reports")
        
        if ($arr === "assessments") {

            foreach ($a as $item) {
                $key = "assessment||" . $item['assessmentId'] . "||" . $item['resourceLinkId'] . "||" . $item['maxGrade'];
                $value = $item['assessmentTitle'];
                $assessments_array[$key] = $value;
            } //End of foreach($a as $item)
        } //End of  if($arr === "assessments")
        
    } //End of foreach($response as $arr => $a)
    return array_merge($chapters_array, $assessments_array);
}
