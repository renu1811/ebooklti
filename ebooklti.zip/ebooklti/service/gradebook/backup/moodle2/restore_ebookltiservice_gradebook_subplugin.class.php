<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the class for restore of this gradebook plugin
 *
 * @package    ebookltiservice_gradebook
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

/**
 * Restore subplugin class.
 *
 * Provides the necessary information
 * needed to restore the lineitems related with the ebooklti activity (coupled),
 * and all the uncoupled ones from the course.
 *
 * @package    ebookltiservice_gradebook
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_ebookltiservice_gradebook_subplugin extends restore_subplugin {

    /**
     * Returns the subplugin structure to attach to the XML element.
     *
     * @return restore_path_element[] array of elements to be processed on restore.
     */
    protected function define_ebooklti_subplugin_structure() {

        $paths = array();
        $elename = $this->get_namefor('lineitem');
        $elepath = $this->get_pathfor('/lineitems/lineitem');
        $paths[] = new restore_path_element($elename, $elepath);
        return $paths;
    }

    /**
     * Processes one lineitem
     *
     * @param mixed $data
     * @return void
     */
    public function process_ebookltiservice_gradebook_lineitem($data) {
        global $DB;
        $data = (object)$data;
        // The coupled lineitems are restored as any other grade item
        // so we will only create the entry in the ebookltiservice_gradebook table.
        // We will try to find a valid toolproxy in the system.
        // If it has been found before... we use it.
        /* cache parent property to account for missing PHPDoc type specification */
        /** @var backup_activity_task $activitytask */
        $activitytask = $this->task;
        $courseid = $activitytask->get_courseid();
        if ($data->typeid != null) {
            if ($ebookltitypeid = $this->get_mappingid('ebookltitype', $data->typeid)) {
                $newtypeid = $ebookltitypeid;
            } else { // If not, then we will call our own function to find it.
                $newtypeid = $this->find_typeid($data, $courseid);
            }
        } else {
            $newtypeid = null;
        }
        if ($data->toolproxyid != null) {
            $ebookltitoolproxy = $this->get_mappingid('ebookltitoolproxy', $data->toolproxyid);
            if ($ebookltitoolproxy && $ebookltitoolproxy != 0) {
                $newtoolproxyid = $ebookltitoolproxy;
            } else { // If not, then we will call our own function to find it.
                $newtoolproxyid = $this->find_proxy_id($data);
            }
        } else {
            $newtoolproxyid = null;
        }
        if ($data->ebookltilinkid != null) {
            $ebookltilinkid = $this->get_new_parentid('ebooklti');
        } else {
            $ebookltilinkid = null;
        }
        // If this has not been restored before.
        if ($this->get_mappingid('gbsgradeitemrestored',  $data->id, 0) == 0) {
            $newgbsid = $DB->insert_record('ebookltiservice_gradebook', (object) array(
                    'gradeitemid' => 0,
                    'courseid' => $courseid,
                    'toolproxyid' => $newtoolproxyid,
                    'ebookltilinkid' => $ebookltilinkid,
                    'typeid' => $newtypeid,
                    'baseurl' => $data->baseurl,
                    'tag' => $data->tag
            ));
            $this->set_mapping('gbsgradeitemoldid', $newgbsid, $data->gradeitemid);
            $this->set_mapping('gbsgradeitemrestored', $data->id, $data->id);
        }
    }

    /**
     * If the toolproxy is not in the mapping (or it is 0)
     * we try to find the toolproxyid.
     * If none is found, then we set it to 0.
     *
     * @param mixed $data
     * @return integer $newtoolproxyid
     */
    private function find_proxy_id($data) {
        global $DB;
        $newtoolproxyid = 0;
        $oldtoolproxyguid = $data->guid;
        $oldtoolproxyvendor = $data->vendorcode;

        $dbtoolproxyjsonparams = array('guid' => $oldtoolproxyguid, 'vendorcode' => $oldtoolproxyvendor);
        $dbtoolproxy = $DB->get_field('ebooklti_tool_proxies', 'id', $dbtoolproxyjsonparams, IGNORE_MISSING);
        if ($dbtoolproxy) {
            $newtoolproxyid = $dbtoolproxy;
        }
        return $newtoolproxyid;
    }

    /**
     * If the typeid is not in the mapping or it is 0, (it should be most of the times)
     * we will try to find the better typeid that matches with the lineitem.
     * If none is found, then we set it to 0.
     *
     * @param stdClass $data
     * @param int $courseid
     * @return int The item type id
     */
    private function find_typeid($data, $courseid) {
        global $DB;
        $newtypeid = 0;
        $oldtypeid = $data->typeid;

        // 1. Find a type with the same id in the same course.
        $dbtypeidparameter = array('id' => $oldtypeid, 'course' => $courseid, 'baseurl' => $data->baseurl);
        $dbtype = $DB->get_field_select('ebooklti_types', 'id', "id=:id
                AND course=:course AND ".$DB->sql_compare_text('baseurl')."=:baseurl",
                $dbtypeidparameter);
        if ($dbtype) {
            $newtypeid = $dbtype;
        } else {
            // 2. Find a site type for all the courses (course == 1), but with the same id.
            $dbtypeidparameter = array('id' => $oldtypeid, 'baseurl' => $data->baseurl);
            $dbtype = $DB->get_field_select('ebooklti_types', 'id', "id=:id
                    AND course=1 AND ".$DB->sql_compare_text('baseurl')."=:baseurl",
                    $dbtypeidparameter);
            if ($dbtype) {
                $newtypeid = $dbtype;
            } else {
                // 3. Find a type with the same baseurl in the actual site.
                $dbtypeidparameter = array('course' => $courseid, 'baseurl' => $data->baseurl);
                $dbtype = $DB->get_field_select('ebooklti_types', 'id', "course=:course
                        AND ".$DB->sql_compare_text('baseurl')."=:baseurl",
                        $dbtypeidparameter);
                if ($dbtype) {
                    $newtypeid = $dbtype;
                } else {
                    // 4. Find a site type for all the courses (course == 1) with the same baseurl.
                    $dbtypeidparameter = array('course' => 1, 'baseurl' => $data->baseurl);
                    $dbtype = $DB->get_field_select('ebooklti_types', 'id', "course=1
                            AND ".$DB->sql_compare_text('baseurl')."=:baseurl",
                            $dbtypeidparameter);
                    if ($dbtype) {
                        $newtypeid = $dbtype;
                    }
                }
            }
        }
        return $newtypeid;
    }

    /**
     * We call the after_restore_ebooklti to update the grade_items id's that we didn't know in the moment of creating
     * the gradebook rows.
     */
    protected function after_restore_ebooklti() {
        global $DB;
        $activitytask = $this->task;
        $courseid = $activitytask->get_courseid();
        $gbstoupdate = $DB->get_records('ebookltiservice_gradebook', array('gradeitemid' => 0, 'courseid' => $courseid));
        foreach ($gbstoupdate as $gbs) {
            $oldgradeitemid = $this->get_mappingid('gbsgradeitemoldid', $gbs->id, 0);
            $newgradeitemid = $this->get_mappingid('grade_item', $oldgradeitemid, 0);
            if ($newgradeitemid > 0) {
                $gbs->gradeitemid = $newgradeitemid;
                $DB->update_record('ebookltiservice_gradebook', $gbs);
            }
        }
    }

}
