<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ebookltisubscribecoursesvc_requested
 *
 * @author snehalkumar.patel
 */



namespace mod_ebooklti\event;
defined('MOODLE_INTERNAL') || die();

 		  
class ebookltisubscribecoursesvc_requested extends \core\event\base {
	
    protected function init() {
        $this->data['crud'] = 'r';
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['other'] = '';       
        $this->context = \context_system::instance();
    }
	

    /**
     * Return localised event name.
     *
     * @return string
     */
    public static function get_name() {   													
        return get_string('eventsubscribecoursesvc_requestcall', 'ebooklti');
    }
     
    /**
     * Returns description of what happened.
     *
     * @return string
     */
    public function get_description() {
        return "A call to a course subscribe service api(OP2) was made. :  {$this->data['other']} ";
    }


    /**
     * Return the legacy event log data.
     *
     * @param array $legacydata the legacy data to set
     */
    public function set_legacy_logdata($legacydata) {
        $this->legacylogdata = $legacydata;
    }


}

