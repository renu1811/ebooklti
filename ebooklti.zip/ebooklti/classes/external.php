<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * ebooklti External tool module external API
 *
 * @package    mod_ebooklti
 * @category   external
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @since      Moodle 3.0
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/externallib.php');
require_once($CFG->dirroot . '/mod/ebooklti/lib.php');
require_once($CFG->dirroot . '/mod/ebooklti/locallib.php');

/**
 * ebooklti External tool module external functions
 *
 * @package    mod_ebooklti
 * @category   external
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @since      Moodle 3.0
 */
class mod_ebooklti_external extends external_api {

    /**
     * Returns structure be used for returning a tool type from a web service.
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    private static function tool_type_return_structure() {
        return new external_single_structure(
            array(
                'id' => new external_value(PARAM_INT, 'Tool type id'),
                'name' => new external_value(PARAM_NOTAGS, 'Tool type name'),
                'description' => new external_value(PARAM_NOTAGS, 'Tool type description'),
                'urls' => new external_single_structure(
                    array(
                        'icon' => new external_value(PARAM_URL, 'Tool type icon URL'),
                        'edit' => new external_value(PARAM_URL, 'Tool type edit URL'),
                        'course' => new external_value(PARAM_URL, 'Tool type edit URL', VALUE_OPTIONAL),
                    )
                ),
                'state' => new external_single_structure(
                    array(
                        'text' => new external_value(PARAM_TEXT, 'Tool type state name string'),
                        'pending' => new external_value(PARAM_BOOL, 'Is the state pending'),
                        'configured' => new external_value(PARAM_BOOL, 'Is the state configured'),
                        'rejected' => new external_value(PARAM_BOOL, 'Is the state rejected'),
                        'unknown' => new external_value(PARAM_BOOL, 'Is the state unknown'),
                    )
                ),
                'hascapabilitygroups' => new external_value(PARAM_BOOL, 'Indicate if capabilitygroups is populated'),
                'capabilitygroups' => new external_multiple_structure(
                    new external_value(PARAM_TEXT, 'Tool type capability groups enabled'),
                    'Array of capability groups', VALUE_DEFAULT, array()
                ),
                'courseid' => new external_value(PARAM_INT, 'Tool type course', VALUE_DEFAULT, 0),
                'instanceids' => new external_multiple_structure(
                    new external_value(PARAM_INT, 'EBOOKLTI instance ID'),
                    'IDs for the EBOOKLTI instances using this type', VALUE_DEFAULT, array()
                ),
                'instancecount' => new external_value(PARAM_INT, 'The number of times this tool is being used')
            ), 'Tool'
        );
    }

    /**
     * Returns description of a tool proxy
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    private static function tool_proxy_return_structure() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool proxy id'),
                'name' => new external_value(PARAM_TEXT, 'Tool proxy name'),
                'regurl' => new external_value(PARAM_URL, 'Tool proxy registration URL'),
                'state' => new external_value(PARAM_INT, 'Tool proxy state'),
                'guid' => new external_value(PARAM_TEXT, 'Tool proxy globally unique identifier'),
                'secret' => new external_value(PARAM_TEXT, 'Tool proxy shared secret'),
                'vendorcode' => new external_value(PARAM_TEXT, 'Tool proxy consumer code'),
                'capabilityoffered' => new external_value(PARAM_TEXT, 'Tool proxy capabilities offered'),
                'serviceoffered' => new external_value(PARAM_TEXT, 'Tool proxy services offered'),
                'toolproxy' => new external_value(PARAM_TEXT, 'Tool proxy'),
                'timecreated' => new external_value(PARAM_INT, 'Tool proxy time created'),
                'timemodified' => new external_value(PARAM_INT, 'Tool proxy modified'),
            )
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function get_tool_proxies_parameters() {
        return new external_function_parameters(
            array(
                'orphanedonly' => new external_value(PARAM_BOOL, 'Orphaned tool types only', VALUE_DEFAULT, 0)
            )
        );
    }

    /**
     * Returns the tool types.
     *
     * @param bool $orphanedonly Retrieve only tool proxies that do not have a corresponding tool type
     * @return array of tool types
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function get_tool_proxies($orphanedonly) {
        global $PAGE;
        $params = self::validate_parameters(self::get_tool_proxies_parameters(),
                                            array(
                                                'orphanedonly' => $orphanedonly
                                            ));
        $orphanedonly = $params['orphanedonly'];

        $proxies = array();
        $context = context_system::instance();

        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $proxies = ebooklti_get_tool_proxies($orphanedonly); 

        return array_map('ebooklti_serialise_tool_proxy', $proxies);
    }

    /**
     * Returns description of method result value.
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function get_tool_proxies_returns() {
        return new external_multiple_structure(
            self::tool_type_return_structure()
        );
    }

    /**
     * Returns description of method parameters.
     *
     * @return external_function_parameters
     * @since Moodle 3.0
     */
    public static function get_tool_launch_data_parameters() {
        return new external_function_parameters(
            array(
                'toolid' => new external_value(PARAM_INT, 'ebooklti external tool instance id')
            )
        );
    }

    /**
     * Return the launch data for a given ebooklti external tool.
     *
     * @param int $toolid the ebooklti external tool instance id
     * @return array of warnings and launch data
     * @since Moodle 3.0
     * @throws moodle_exception
     */
    public static function get_tool_launch_data($toolid) {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/mod/ebooklti/lib.php');

        $params = self::validate_parameters(self::get_tool_launch_data_parameters(),
                                            array(
                                                'toolid' => $toolid
                                            ));
        $warnings = array();

        // Request and permission validation.
        $ebooklti = $DB->get_record('ebooklti', array('id' => $params['toolid']), '*', MUST_EXIST);
        list($course, $cm) = get_course_and_cm_from_instance($ebooklti, 'ebooklti');

        $context = context_module::instance($cm->id);
        self::validate_context($context);

        require_capability('mod/ebooklti:view', $context);

        $ebooklti->cmid = $cm->id;
        list($endpoint, $parms) = ebooklti_get_launch_data($ebooklti);

        $parameters = array();
        foreach ($parms as $name => $value) {
            $parameters[] = array(
                'name' => $name,
                'value' => $value
            );
        }

        $result = array();
        $result['endpoint'] = $endpoint;
        $result['parameters'] = $parameters;
        $result['warnings'] = $warnings;
        return $result;
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.0
     */
    public static function get_tool_launch_data_returns() {
        return new external_single_structure(
            array(
                'endpoint' => new external_value(PARAM_RAW, 'Endpoint URL'), // Using PARAM_RAW as is defined in the module.
                'parameters' => new external_multiple_structure(
                    new external_single_structure(
                        array(
                            'name' => new external_value(PARAM_NOTAGS, 'Parameter name'),
                            'value' => new external_value(PARAM_RAW, 'Parameter value')
                        )
                    )
                ),
                'warnings' => new external_warnings()
            )
        );
    }

    /**
     * Describes the parameters for get_ebookltis_by_courses.
     *
     * @return external_function_parameters
     * @since Moodle 3.0
     */
    public static function get_ebookltis_by_courses_parameters() {
        return new external_function_parameters (
            array(
                'courseids' => new external_multiple_structure(
                    new external_value(PARAM_INT, 'course id'), 'Array of course ids', VALUE_DEFAULT, array()
                ),
            )
        );
    }

    /**
     * Returns a list of ebooklti external tools in a provided list of courses,
     * if no list is provided all ebooklti external tools that the user can view will be returned.
     *
     * @param array $courseids the course ids
     * @return array the ebooklti details
     * @since Moodle 3.0
     */
    public static function get_ebookltis_by_courses($courseids = array()) {
        global $CFG;

        $returnedebookltis = array();
        $warnings = array();

        $params = self::validate_parameters(self::get_ebookltis_by_courses_parameters(), array('courseids' => $courseids));

        $mycourses = array();
        if (empty($params['courseids'])) {
            $mycourses = enrol_get_my_courses();
            $params['courseids'] = array_keys($mycourses);
        }

        // Ensure there are courseids to loop through.
        if (!empty($params['courseids'])) {

            list($courses, $warnings) = external_util::validate_courses($params['courseids'], $mycourses);

            // Get the ebookltis in this course, this function checks users visibility permissions.
            // We can avoid then additional validate_context calls.
            $ebookltis = get_all_instances_in_courses("ebooklti", $courses);

            foreach ($ebookltis as $ebooklti) {

                $context = context_module::instance($ebooklti->coursemodule);

                // Entry to return.
                $module = array();

                // First, we return information that any user can see in (or can deduce from) the web interface.
                $module['id'] = $ebooklti->id;
                $module['coursemodule'] = $ebooklti->coursemodule;
                $module['course'] = $ebooklti->course;
                $module['name']  = external_format_string($ebooklti->name, $context->id);

                $viewablefields = [];
                if (has_capability('mod/ebooklti:view', $context)) {
                    list($module['intro'], $module['introformat']) =
                        external_format_text($ebooklti->intro, $ebooklti->introformat, $context->id, 'mod_ebooklti', 'intro', null);

                    $module['introfiles'] = external_util::get_area_files($context->id, 'mod_ebooklti', 'intro', false, false);
                    $viewablefields = array('launchcontainer', 'showtitlelaunch', 'showdescriptionlaunch', 'icon', 'secureicon');
                }

                // Check additional permissions for returning optional private settings.
                if (has_capability('moodle/course:manageactivities', $context)) {

                    $additionalfields = array('timecreated', 'timemodified', 'typeid', 'toolurl', 'securetoolurl',
                        'instructorchoicesendname', 'instructorchoicesendemailaddr', 'instructorchoiceallowroster',
                        'instructorchoiceallowsetting', 'instructorcustomparameters', 'instructorchoiceacceptgrades', 'grade',
                        'resourcekey', 'password', 'debuglaunch', 'servicesalt', 'visible', 'groupmode', 'groupingid');
                    $viewablefields = array_merge($viewablefields, $additionalfields);

                }

                foreach ($viewablefields as $field) {
                    $module[$field] = $ebooklti->{$field};
                }

                $returnedebookltis[] = $module;
            }
        }

        $result = array();
        $result['ebookltis'] = $returnedebookltis;
        $result['warnings'] = $warnings;
        return $result;
    }

    /**
     * Describes the get_ebookltis_by_courses return value.
     *
     * @return external_single_structure
     * @since Moodle 3.0
     */
    public static function get_ebookltis_by_courses_returns() {

        return new external_single_structure(
            array(
                'ebookltis' => new external_multiple_structure(
                    new external_single_structure(
                        array(
                            'id' => new external_value(PARAM_INT, 'EBOOKLTI External tool id'),
                            'coursemodule' => new external_value(PARAM_INT, 'Course module id'),
                            'course' => new external_value(PARAM_INT, 'Course id'),
                            'name' => new external_value(PARAM_RAW, 'EBOOKLTI name'),
                            'intro' => new external_value(PARAM_RAW, 'The EBOOKLTI intro', VALUE_OPTIONAL),
                            'introformat' => new external_format_value('intro', VALUE_OPTIONAL),
                            'introfiles' => new external_files('Files in the introduction text', VALUE_OPTIONAL),
                            'timecreated' => new external_value(PARAM_INT, 'Time of creation', VALUE_OPTIONAL),
                            'timemodified' => new external_value(PARAM_INT, 'Time of last modification', VALUE_OPTIONAL),
                            'typeid' => new external_value(PARAM_INT, 'Type id', VALUE_OPTIONAL),
                            'toolurl' => new external_value(PARAM_URL, 'Tool url', VALUE_OPTIONAL),
                            'securetoolurl' => new external_value(PARAM_RAW, 'Secure tool url', VALUE_OPTIONAL),
                            'instructorchoicesendname' => new external_value(PARAM_TEXT, 'Instructor choice send name',
                                                                               VALUE_OPTIONAL),
                            'instructorchoicesendemailaddr' => new external_value(PARAM_INT, 'instructor choice send mail address',
                                                                                    VALUE_OPTIONAL),
                            'instructorchoiceallowroster' => new external_value(PARAM_INT, 'Instructor choice allow roster',
                                                                                VALUE_OPTIONAL),
                            'instructorchoiceallowsetting' => new external_value(PARAM_INT, 'Instructor choice allow setting',
                                                                                 VALUE_OPTIONAL),
                            'instructorcustomparameters' => new external_value(PARAM_RAW, 'instructor custom parameters',
                                                                                VALUE_OPTIONAL),
                            'instructorchoiceacceptgrades' => new external_value(PARAM_INT, 'instructor choice accept grades',
                                                                                    VALUE_OPTIONAL),
                            'grade' => new external_value(PARAM_INT, 'Enable grades', VALUE_OPTIONAL),
                            'launchcontainer' => new external_value(PARAM_INT, 'Launch container mode', VALUE_OPTIONAL),
                            'resourcekey' => new external_value(PARAM_RAW, 'Resource key', VALUE_OPTIONAL),
                            'password' => new external_value(PARAM_RAW, 'Shared secret', VALUE_OPTIONAL),
                            'debuglaunch' => new external_value(PARAM_INT, 'Debug launch', VALUE_OPTIONAL),
                            'showtitlelaunch' => new external_value(PARAM_INT, 'Show title launch', VALUE_OPTIONAL),
                            'showdescriptionlaunch' => new external_value(PARAM_INT, 'Show description launch', VALUE_OPTIONAL),
                            'servicesalt' => new external_value(PARAM_RAW, 'Service salt', VALUE_OPTIONAL),
                            'icon' => new external_value(PARAM_URL, 'Alternative icon URL', VALUE_OPTIONAL),
                            'secureicon' => new external_value(PARAM_URL, 'Secure icon URL', VALUE_OPTIONAL),
                            'section' => new external_value(PARAM_INT, 'course section id', VALUE_OPTIONAL),
                            'visible' => new external_value(PARAM_INT, 'visible', VALUE_OPTIONAL),
                            'groupmode' => new external_value(PARAM_INT, 'group mode', VALUE_OPTIONAL),
                            'groupingid' => new external_value(PARAM_INT, 'group id', VALUE_OPTIONAL),
                        ), 'Tool'
                    )
                ),
                'warnings' => new external_warnings(),
            )
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.0
     */
    public static function view_ebooklti_parameters() {
        return new external_function_parameters(
            array(
                'ebookltiid' => new external_value(PARAM_INT, 'ebooklti instance id')
            )
        );
    }

    /**
     * Trigger the course module viewed event and update the module completion status.
     *
     * @param int $ebookltiid the ebooklti instance id
     * @return array of warnings and status result
     * @since Moodle 3.0
     * @throws moodle_exception
     */
    public static function view_ebooklti($ebookltiid) {
        global $DB;

        $params = self::validate_parameters(self::view_ebooklti_parameters(),
                                            array(
                                                'ebookltiid' => $ebookltiid
                                            ));
        $warnings = array();

        // Request and permission validation.
        $ebooklti = $DB->get_record('ebooklti', array('id' => $params['ebookltiid']), '*', MUST_EXIST);
        list($course, $cm) = get_course_and_cm_from_instance($ebooklti, 'ebooklti');

        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/ebooklti:view', $context);

        // Trigger course_module_viewed event and completion.
        ebooklti_view($ebooklti, $course, $cm, $context);

        $result = array();
        $result['status'] = true;
        $result['warnings'] = $warnings;
        return $result;
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.0
     */
    public static function view_ebooklti_returns() {
        return new external_single_structure(
            array(
                'status' => new external_value(PARAM_BOOL, 'status: true if success'),
                'warnings' => new external_warnings()
            )
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function create_tool_proxy_parameters() {
        return new external_function_parameters(
            array(
                'name' => new external_value(PARAM_TEXT, 'Tool proxy name', VALUE_DEFAULT, ''),
                'regurl' => new external_value(PARAM_URL, 'Tool proxy registration URL'),
                'capabilityoffered' => new external_multiple_structure(
                    new external_value(PARAM_TEXT, 'Tool proxy capabilities offered'),
                    'Array of capabilities', VALUE_DEFAULT, array()
                ),
                'serviceoffered' => new external_multiple_structure(
                    new external_value(PARAM_TEXT, 'Tool proxy services offered'),
                    'Array of services', VALUE_DEFAULT, array()
                )
            )
        );
    }

    /**
     * Creates a new tool proxy
     *
     * @param string $name Tool proxy name
     * @param string $registrationurl Registration url
     * @param string[] $capabilityoffered List of capabilities this tool proxy should be offered
     * @param string[] $serviceoffered List of services this tool proxy should be offered
     * @return object The new tool proxy
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function create_tool_proxy($name, $registrationurl, $capabilityoffered, $serviceoffered) {
        $params = self::validate_parameters(self::create_tool_proxy_parameters(),
                                            array(
                                                'name' => $name,
                                                'regurl' => $registrationurl,
                                                'capabilityoffered' => $capabilityoffered,
                                                'serviceoffered' => $serviceoffered
                                            ));
        $name = $params['name'];
        $regurl = $params['regurl'];
        $capabilityoffered = $params['capabilityoffered'];
        $serviceoffered = $params['serviceoffered'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        // Can't create duplicate proxies with the same URL.
        $duplicates = ebooklti_get_tool_proxies_from_registration_url($registrationurl);
        if (!empty($duplicates)) {
            throw new moodle_exception('duplicateregurl', 'mod_ebooklti');
        }

        $config = new stdClass();
        $config->ebooklti_registrationurl = $registrationurl;

        if (!empty($name)) {
            $config->ebooklti_registrationname = $name;
        }

        if (!empty($capabilityoffered)) {
            $config->ebooklti_capabilities = $capabilityoffered;
        }

        if (!empty($serviceoffered)) {
            $config->ebooklti_services = $serviceoffered;
        }

        $id = ebooklti_add_tool_proxy($config);
        $toolproxy = ebooklti_get_tool_proxy($id);

        // Pending makes more sense than configured as the first state, since
        // the next step is to register, which requires the state be pending.
        $toolproxy->state = EBOOKLTI_TOOL_PROXY_STATE_PENDING;
        ebooklti_update_tool_proxy($toolproxy);

        return $toolproxy;
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function create_tool_proxy_returns() {
        return self::tool_proxy_return_structure();
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function delete_tool_proxy_parameters() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool proxy id'),
            )
        );
    }

    /**
     * Trigger the course module viewed event and update the module completion status.
     *
     * @param int $id the ebooklti instance id
     * @return object The tool proxy
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function delete_tool_proxy($id) {
        $params = self::validate_parameters(self::delete_tool_proxy_parameters(),
                                            array(
                                                'id' => $id,
                                            ));
        $id = $params['id'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $toolproxy = ebooklti_get_tool_proxy($id);

        ebooklti_delete_tool_proxy($id);

        return $toolproxy;
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function delete_tool_proxy_returns() {
        return self::tool_proxy_return_structure();
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.0
     */
    public static function get_tool_proxy_registration_request_parameters() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool proxy id'),
            )
        );
    }

    /**
     * Returns the registration request for a tool proxy.
     *
     * @param int $id the ebooklti instance id
     * @return array of registration parameters
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function get_tool_proxy_registration_request($id) {
        $params = self::validate_parameters(self::get_tool_proxy_registration_request_parameters(),
                                            array(
                                                'id' => $id,
                                            ));
        $id = $params['id'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $toolproxy = ebooklti_get_tool_proxy($id);
        return ebooklti_build_registration_request($toolproxy);
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function get_tool_proxy_registration_request_returns() {
        return new external_function_parameters(
            array(
                'lti_message_type' => new external_value(PARAM_ALPHANUMEXT, 'EBOOKLTI message type'),
                'lti_version' => new external_value(PARAM_ALPHANUMEXT, 'EBOOKLTI version'),
                'reg_key' => new external_value(PARAM_TEXT, 'Tool proxy registration key'),
                'reg_password' => new external_value(PARAM_TEXT, 'Tool proxy registration password'),
                'reg_url' => new external_value(PARAM_TEXT, 'Tool proxy registration url'),
                'tc_profile_url' => new external_value(PARAM_URL, 'Tool consumers profile URL'),
                'launch_presentation_return_url' => new external_value(PARAM_URL, 'URL to redirect on registration completion'),
            )
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function get_tool_types_parameters() {
        return new external_function_parameters(
            array(
                'toolproxyid' => new external_value(PARAM_INT, 'Tool proxy id', VALUE_DEFAULT, 0)
            )
        );
    }

    /**
     * Returns the tool types.
     *
     * @param int $toolproxyid The tool proxy id
     * @return array of tool types
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function get_tool_types($toolproxyid) {
        global $PAGE;
        $params = self::validate_parameters(self::get_tool_types_parameters(),
                                            array(
                                                'toolproxyid' => $toolproxyid
                                            ));
        $toolproxyid = $params['toolproxyid'];

        $types = array();
        $context = context_system::instance();

        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        if (!empty($toolproxyid)) {
            $types = ebooklti_get_ebooklti_types_from_proxy_id($toolproxyid);
        } else {
            $types = ebooklti_get_ebooklti_types();
        }
		
        return array_map("ebooklti_serialise_tool_type", array_values($types));
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function get_tool_types_returns() {
        return new external_multiple_structure(
            self::tool_type_return_structure()
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function create_tool_type_parameters() {
        return new external_function_parameters(
            array(
                'cartridgeurl' => new external_value(PARAM_URL, 'URL to cardridge to load tool information', VALUE_DEFAULT, ''),
                'key' => new external_value(PARAM_TEXT, 'Consumer key', VALUE_DEFAULT, ''),
                'secret' => new external_value(PARAM_TEXT, 'Shared secret', VALUE_DEFAULT, ''),
            )
        );
    }

    /**
     * Creates a tool type.
     *
     * @param string $cartridgeurl Url of the xml cartridge representing the EBOOKLTI tool
     * @param string $key The consumer key to identify this consumer
     * @param string $secret The secret
     * @return array created tool type
     * @since Moodle 3.1
     * @throws moodle_exception If the tool type could not be created
     */
    public static function create_tool_type($cartridgeurl, $key, $secret) {
        $params = self::validate_parameters(self::create_tool_type_parameters(),
                                            array(
                                                'cartridgeurl' => $cartridgeurl,
                                                'key' => $key,
                                                'secret' => $secret
                                            ));
        $cartridgeurl = $params['cartridgeurl'];
        $key = $params['key'];
        $secret = $params['secret'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $id = null;

        if (!empty($cartridgeurl)) {
            $type = new stdClass();
            $data = new stdClass();
            $type->state = EBOOKLTI_TOOL_STATE_CONFIGURED;
            $data->ebooklti_coursevisible = 1;
            $data->ebooklti_sendname = EBOOKLTI_SETTING_DELEGATE;
            $data->ebooklti_sendemailaddr = EBOOKLTI_SETTING_DELEGATE;
            $data->ebooklti_acceptgrades = EBOOKLTI_SETTING_DELEGATE;
            $data->ebooklti_forcessl = 0;

            if (!empty($key)) {
                $data->ebooklti_resourcekey = $key;
            }

            if (!empty($secret)) {
                $data->ebooklti_password = $secret;
            }

            ebooklti_load_type_from_cartridge($cartridgeurl, $data);
            if (empty($data->ebooklti_toolurl)) {
                throw new moodle_exception('unabletocreatetooltype', 'mod_ebooklti');
            } else {
                $id = ebooklti_add_type($type, $data);
            }
        }

        if (!empty($id)) {
            $type = ebooklti_get_type($id);
            return ebooklti_serialise_tool_type($type);
        } else {
            throw new moodle_exception('unabletocreatetooltype', 'mod_ebooklti');
        }
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function create_tool_type_returns() {
        return self::tool_type_return_structure();
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function update_tool_type_parameters() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool type id'),
                'name' => new external_value(PARAM_RAW, 'Tool type name', VALUE_DEFAULT, null),
                'description' => new external_value(PARAM_RAW, 'Tool type description', VALUE_DEFAULT, null),
                'state' => new external_value(PARAM_INT, 'Tool type state', VALUE_DEFAULT, null)
            )
        );
    }

    /**
     * Update a tool type.
     *
     * @param int $id The id of the tool type to update
     * @param string $name The name of the tool type
     * @param string $description The name of the tool type
     * @param int $state The state of the tool type
     * @return array updated tool type
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function update_tool_type($id, $name, $description, $state) {
        $params = self::validate_parameters(self::update_tool_type_parameters(),
                                            array(
                                                'id' => $id,
                                                'name' => $name,
                                                'description' => $description,
                                                'state' => $state,
                                            ));
        $id = $params['id'];
        $name = $params['name'];
        $description = $params['description'];
        $state = $params['state'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $type = ebooklti_get_type($id);

        if (empty($type)) {
            throw new moodle_exception('unabletofindtooltype', 'mod_ebooklti', '', array('id' => $id));
        }

        if (!empty($name)) {
            $type->name = $name;
        }

        if (!empty($description)) {
            $type->description = $description;
        }

        if (!empty($state)) {
            // Valid state range.
            if (in_array($state, array(1, 2, 3))) {
                $type->state = $state;
            } else {
                throw new moodle_exception("Invalid state: $state - must be 1, 2, or 3");
            }
        }

        ebooklti_update_type($type, new stdClass());

        return ebooklti_serialise_tool_type($type);
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function update_tool_type_returns() {
        return self::tool_type_return_structure();
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function delete_tool_type_parameters() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool type id'),
            )
        );
    }

    /**
     * Delete a tool type.
     *
     * @param int $id The id of the tool type to be deleted
     * @return array deleted tool type
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function delete_tool_type($id) {
        $params = self::validate_parameters(self::delete_tool_type_parameters(),
                                            array(
                                                'id' => $id,
                                            ));
        $id = $params['id'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $type = ebooklti_get_type($id);

        if (!empty($type)) {
            ebooklti_delete_type($id);

            // If this is the last type for this proxy then remove the proxy
            // as well so that it isn't orphaned.
            $types = ebooklti_get_ebooklti_types_from_proxy_id($type->toolproxyid);
            if (empty($types)) {
                ebooklti_delete_tool_proxy($type->toolproxyid);
            }
        }

        return array('id' => $id);
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function delete_tool_type_returns() {
        return new external_function_parameters(
            array(
                'id' => new external_value(PARAM_INT, 'Tool type id'),
            )
        );
    }

    /**
     * Returns description of method parameters
     *
     * @return external_function_parameters
     * @since Moodle 3.1
     */
    public static function is_cartridge_parameters() {
        return new external_function_parameters(
            array(
                'url' => new external_value(PARAM_URL, 'Tool url'),
            )
        );
    }

    /**
     * Determine if the url to a tool is for a cartridge.
     *
     * @param string $url Url that may or may not be an xml cartridge
     * @return bool True if the url is for a cartridge.
     * @since Moodle 3.1
     * @throws moodle_exception
     */
    public static function is_cartridge($url) {
        $params = self::validate_parameters(self::is_cartridge_parameters(),
                                            array(
                                                'url' => $url,
                                            ));
        $url = $params['url'];

        $context = context_system::instance();
        self::validate_context($context);
        require_capability('moodle/site:config', $context);

        $iscartridge = ebooklti_is_cartridge($url);

        return array('iscartridge' => $iscartridge);
    }

    /**
     * Returns description of method result value
     *
     * @return external_description
     * @since Moodle 3.1
     */
    public static function is_cartridge_returns() {
        return new external_function_parameters(
            array(
                'iscartridge' => new external_value(PARAM_BOOL, 'True if the URL is a cartridge'),
            )
        );
    }
	
	public static function update_grades_parameters() {
        return new external_function_parameters(
               array(
					 'assessmentid' => new external_value(PARAM_TEXT, 'SARAS assessmentID for this ebooklti', VALUE_REQUIRED,'Invalid assessmentId', false),
					 'coursecode' => new external_value(PARAM_TEXT, 'unique course instance identifier',VALUE_REQUIRED,'Invalid coursecode', false),
					 'username' => new external_value(PARAM_TEXT, 'Navigate local username',VALUE_REQUIRED,'Invalid username', false),
					  'grade' => new external_value(PARAM_TEXT, 'grade in percentage'),      
					  'attemptid' => new external_value(PARAM_TEXT, 'attemptid of the assessment'),
					 'time_completed' =>  new external_value(PARAM_INT, 'submitted timestamp')
					 )
        	    );
    }
	
	public static function update_grades ($assessmentid,  $coursecode, $username =null, $grade, $attemptid, $time_completed ) {
      	 global $USER, $DB;
      	//clean up the url params
		$object =  "assessmentid: " . $assessmentid . " coursecode: " . $coursecode . " username: " . $username . " grade: " . $grade . " attemptid ".$attemptid."time_completed ". $time_completed. " TIMESTAMP: " . time() ;
		$rawgrade = $object;
		$event = \mod_ebooklti\event\ebookltigradepostbackrawdata_accepted::create(array('other' => $object));           
		$event->trigger();
		$username = urldecode($username);
      	
        // Retrieve user record of the user to which these results belong
        $results_user = $DB->get_record( 'user', array( 'username' => $username, 'deleted' => 0));
        if (!$results_user) {
            // Return error: cannot find user record
            // Logging the grade posting request
            $object =  "User record not Found. Raw grade: ".$rawgrade;
	        $event = \mod_ebooklti\event\ebookltigradepostback_failed::create(array('other' => $object));           
            $event->trigger();
            return $params['updateresult'] = 1;
        }
        
        // Use assessmentid and coursecode combination to retrieve the 
        // ebooklti activity record to which this test belongs        
        // verify course code exists:
        $results_course = $DB->get_record( 'course', array( 'idnumber' => $coursecode ) );
        if (!$results_course) {
        	$object =  "course with id $coursecode  not Found. Raw postback values: ".$rawgrade;
	        $event = \mod_ebooklti\event\ebookltigradepostback_failed::create(array('other' => $object));           
            $event->trigger();
            return $params['updateresult'] = 2;
        }
        $select = "custom_unique_activity_id = ? AND course = ?";
		//Previous field used custom_assessment_id, changed to custom_unique_activity_id
        $results_test = $DB->get_record_select( 'ebooklti', $select, array( 'custom_unique_activity_id' => $assessmentid, 'course' => $results_course->id ) ); 
        if (!$results_test) {
            // Return error: cannot find ebooklti record 
            // Logging the grade posting request
            $object =  "cannot find ebooklti record for the combination of unique_activity_id $assessmentid and course code $results_course->id . Raw grade: ".$rawgrade;
	        $event = \mod_ebooklti\event\ebookltigradepostback_failed::create(array('other' => $object));           
            $event->trigger();
            return $params['updateresult'] = 3;
        }
        
        
        // Create the ebooklti object
        $ebooklti_item = new stdClass();
        $ebooklti_item->id = $results_test->id;
        $ebooklti_item->name = $results_test->name;
        $ebooklti_item->course = $results_course->id;

        // When ans_correct is NULL it signals assessment includes pending essay
        // questions, so we need to normalize that rawgrade value as "0" for the grade
        //  $norm_correct = ($ans_correct == 'NULL') ? '0' : $ans_correct;
        $grade = ($grade=="NULL" || $grade == "") ? '0' : $grade;
        
        $update_response = ebooklti_update_grades_external( $ebooklti_item, $results_user->id, $grade );
        if ( $update_response == GRADE_UPDATE_OK ) {
        	
        	$update_attempts_table = ebooklti_update_attempts_table( $ebooklti_item, $grade, $attemptid,$time_completed );
		$update_submission_attempts_table = ebooklti_update_submission_attempts_table( $ebooklti_item, $results_user->id,$grade, $attemptid,$time_completed );
        	// Logging the grade posting request
             $object =  "Grade Post Back Accepted. Raw grade: ".$rawgrade;
	         $event = \mod_ebooklti\event\ebookltigradepostback_accepted::create(array('other' => $object));           
            $event->trigger();
        } else {
            // response is GRADE_UPDATE_FAILED, GRADE_UPDATE_MULTIPLE, or GRADE_ITEM_LOCKED
            // Logging the grade posting request        
             $object =  "User grade update failed or grade item locked. Raw grade: ".$rawgrade;
	         $event = \mod_ebooklti\event\ebookltigradepostback_failed::create(array('other' => $object));           
            $event->trigger();
            return $params['updateresult'] = 3;
        }
			
        
           	return $params['updateresult'] = 0;
      }

    
    public static function update_grades_returns() {
        return new external_value(PARAM_TEXT, 'flag success = 0, failure >= 1');
    }

}



function ebooklti_update_grades_external(stdClass $ebooklti, $userid = 0, $rawgrade, $rawgrademax=null) {
    global $CFG, $DB;
    require_once($CFG->libdir.'/gradelib.php');
	
	$item = array();
    $item['itemname'] = clean_param($ebooklti->name, PARAM_NOTAGS);
    $item['gradetype'] = GRADE_TYPE_VALUE; 
	if(isset($rawgrademax)){
	    $item['grademax'] = $rawgrademax;
	}
    $grades = array(); // populate array of grade objects indexed by userid
	$grades[$userid] = new stdClass();
	$grades[$userid]->id 		= $userid;
	$grades[$userid]->userid	= $userid;
	$grades[$userid]->rawgrade	= $rawgrade;

    grade_update('mod/ebooklti', $ebooklti->course, 'mod', 'ebooklti', $ebooklti->id, 0, $grades, $item);
}


function ebooklti_update_attempts_table( stdClass $ebooklti_item, $grade, $attemptid,$time_completed ) {
	
	global $CFG, $DB;
	
	$select = "ebookltiid = ? AND assessmentattemptid = ?";
    $attempt_record  = $DB->get_record_select( 'ebooklti_assessment_attempt', $select, array( 'ebookltiid' => $ebooklti_item->id, 'assessmentattemptid' => $attemptid ) ); 
    		
	$ebooklti_assessment_attempt_obj = new stdClass();     
	$ebooklti_assessment_attempt_obj->ebookltiid = $ebooklti_item->id;
	$ebooklti_assessment_attempt_obj->assessmentattemptid = $attemptid;
	$ebooklti_assessment_attempt_obj->gradepercent = $grade;
	$ebooklti_assessment_attempt_obj->timesubmitted = $time_completed;
	$ebooklti_assessment_attempt_obj->timecreated = time();
    if($attempt_record) {
    	 $ebooklti_assessment_attempt_obj->id = $attempt_record->id;
   		 $update_attempt_record = $DB->update_record('ebooklti_assessment_attempt',$ebooklti_assessment_attempt_obj,$returnid=true);
         return false;
    }
    else { 	
		 $create_attempt_record = $DB->insert_record('ebooklti_assessment_attempt',$ebooklti_assessment_attempt_obj,$returnid=true);
		 return true;
    }
}

function ebooklti_update_submission_attempts_table( stdClass $ebooklti_item, $userid, $grade, $attemptid,$time_completed  ) {

    global $CFG, $DB;
	// we need to update grade % as well. OP2 sends only grade value. we need to get the max grade value from the grade items table
    $grade_item = $DB->get_record( 'grade_items', array( 'itemmodule' => 'ebooklti', 'iteminstance' => $ebooklti_item->id ) );
    if($grade_item != null) {
		$max_grade = $grade_item->grademax;    
    }
	else {
		// make sure it wont break by giving max grade = 100, 
		$max_grade = 100;
	}

	$grade_percent = ($grade/$max_grade) * 100;
	$grade_percent = round($grade_percent,2);

	$ebooklti_assessment_attempt_obj = new stdClass();    
	$ebooklti_assessment_attempt_obj->ebookltiid = $ebooklti_item->id;
	$ebooklti_assessment_attempt_obj->userid = $userid;
	$ebooklti_assessment_attempt_obj->datesubmitted = $time_completed;
	$ebooklti_assessment_attempt_obj->dateupdated = time();
	$ebooklti_assessment_attempt_obj->gradepercent = $grade_percent; // do we need this? if so what is the value?
	$ebooklti_assessment_attempt_obj->originalgrade = $grade;
	$ebooklti_assessment_attempt_obj->launchid = $ebooklti_item->id;
	$ebooklti_assessment_attempt_obj->state = 1;

	$create_attempt_record = $DB->insert_record('ebooklti_submission',$ebooklti_assessment_attempt_obj,$returnid=true);
	return true;

}

