<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * When the course settings are updated, this handler will determine,
 * if anything needs to be done with respect to updating the ebooklti table
 * records and issuing a notification to OP2 regarding the identity of this
 * course and the identity of the source (or "master") course that was used
 * to create it.
 * Description of ebooklti_event_handler
 *
 * @author snehalkumar.patel
 */

namespace mod_ebooklti;

defined('MOODLE_INTERNAL') || die();

class ebooklti_event_handler {

    public static function op2_course_subscribe_service_requested($event) {
        global $CFG, $SITE, $DB, $COURSE;
        //echo "<pre>";
        //echo "snehal";
        //echo "</br>";
        $course_object = $event->get_record_snapshot('course', $event->courseid);
        //print_r($course_object);
        //echo "</br>";
        //exit;
        $course_id = $course_object->id;
        $course_idnumber = $course_object->idnumber;
        $course_shortname = $course_object->shortname;

        if (!empty($course_idnumber)) {
            // Retrieve ebooklti records for this course only,
            // with a course idnumber that is different
            // than the current course's idnumber. NOTE that the
            // id and the idnumber are distinct fields in the
            // course table record.
            $filter_sql = "course = '" . $course_id . "' AND ";
            $filter_sql .= "custom_course_idnumber <> '" . $course_idnumber . "'";

            //$targets = array();
            $targets = $DB->get_records_select('ebooklti', $filter_sql);
            if (count($targets) > 0) {
                foreach ($targets as $target) {
                    if ((!empty($target->custom_course_idnumber) ) && ( $target->custom_course_idnumber <> $course_idnumber )) {
                        // call OP2  once only to subscribeCourse/create a course
                        //$params = "?masterCourseCode=9781284137880_jbl&courseInstanceCode=9781284137880_jblAA&courseInstanceName=9781284137880_jblAA_NAME";
                        $url = $CFG->op2_course_creation_url;
                        $fields = array(
                            "masterCourseCode" => $target->custom_course_idnumber,
                            "courseInstanceCode" => $course_idnumber,
                            "courseInstanceName" => $course_shortname
                        );
                        /* out going request log */
                        $object = "EBOOKLTI existing_course_Idnum: " . $target->custom_course_idnumber . " new_course_Idnum: " . $course_idnumber . " new_course_name : " . $course_shortname . " date & time: " . date('m/d/Y H:i:s e', time());
                        $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => "Out going request object  ". $object));
                        $event->trigger();

                        $response = self::api_call_toop2($url, $fields);
                        $received_code = json_decode($response);
                        if ($received_code->statusCode == "CC001") {
                            $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => "In coming response response code: CC001. Course Instance created successfully. " . $object));
                            $event->trigger();
                        } else {

                            switch ($received_code->statusCode) {
                                // These OP2 response codes indicate a problem
                                case "CC002":
                                // CC002 - Invalid Course code
                                case "CC003":
                                // CC003 - Course already exist
                                case "CC004":
                                // CC004 - New instructor tagged to the course Instance
                                case "CC005":
                                // CC005 - Already instructor tagged to the course Instance
                                default:

                                    $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => "Course Instance creation failed. Response Code: " . $received_code->statusCode . " Data : " . $object));
                                    $event->trigger();
                                    break;
                            }
                        }
                        // OP2 course creation  call only needs to be made once per course instance,
                        // even if there are multiple links, so terminate the foreach block
                        break;
                    } else {
                        if (empty($target->custom_course_idnumber)) {
                            $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => "custom_course_idnumber was empty in EBOOKLTI activity, id " . $target->id . " PHP Course Id is " . $COURSE->id . "Please type ISBN+6 and save again."));
                            $event->trigger();
                        }
                        if ($target->custom_course_idnumber == $course_idnumber) {
                            $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => "No change to course idnumber, custom_course_idnumbers in EBOOKLTI activities have not changed. Course IDnumber is " . $course_idnumber));
                            $event->trigger();
                        }
                    }
                } // END of foreach ( $targets as $target)
                // Now update all of the selected records to reflect the course idnumber from this course
                $DB->set_field_select('ebooklti', 'custom_course_idnumber', $course_idnumber, $filter_sql);
            } else {
                $event = \mod_ebooklti\event\ebookltisubscribecoursesvc_requested::create(array('other' => " There is  no course IDnumber/ISBN for the course PHP Id : " . $COURSE->id . "Please type ISBN+6 and save again."));
                $event->trigger();
            }
        }
        // return true;
    }

// END of function op2_course_creation

    public static function api_call_toop2($url, $post_fields = null) {
        global $DB, $CFG;
        //url-ify the data for the POST
        $fields_string = '';
        foreach ($post_fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        $fields_string_trimed = rtrim($fields_string, '&');
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        //curl_setopt($ch,CURLOPT_POST, count($post_fields));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string_trimed);
        // receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

//END of function api_interface
}
