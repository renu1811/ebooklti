<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file defines the global ebooklti administration form
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

/*
 * @var admin_settingpage $settings
 */
$modebookltifolder = new admin_category('modebookltifolder', new lang_string('pluginname', 'mod_ebooklti'), $module->is_enabled() === false);
$ADMIN->add('modsettings', $modebookltifolder);
$settings->visiblename = new lang_string('manage_tools', 'mod_ebooklti');
$settings->hidden = true;
$ADMIN->add('modebookltifolder', $settings);
$proxieslink = new admin_externalpage('ebookltitoolproxies',
        get_string('manage_tool_proxies', 'ebooklti'),
        new moodle_url('/mod/ebooklti/toolproxies.php'));
$proxieslink->hidden = true;
$ADMIN->add('modebookltifolder', $proxieslink);
$ADMIN->add('modebookltifolder', new admin_externalpage('ebookltitoolconfigure',
        get_string('manage_external_tools', 'ebooklti'),
        new moodle_url('/mod/ebooklti/toolconfigure.php')));

foreach (core_plugin_manager::instance()->get_plugins_of_type('ebookltisource') as $plugin) {
    /*
     * @var \mod_ebooklti\plugininfo\ebookltisource $plugin
     */
    $plugin->load_settings($ADMIN, 'modebookltifolder', $hassiteconfig);
}

$toolproxiesurl = new moodle_url('/mod/ebooklti/toolproxies.php');
$toolproxiesurl = $toolproxiesurl->out();

if ($ADMIN->fulltree) {
    require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

    $configuredtoolshtml = '';
    $pendingtoolshtml = '';
    $rejectedtoolshtml = '';

    $active = get_string('active', 'ebooklti');
    $pending = get_string('pending', 'ebooklti');
    $rejected = get_string('rejected', 'ebooklti');

    // Gather strings used for labels in the inline JS.
    $PAGE->requires->strings_for_js(
        array(
            'typename',
            'baseurl',
            'action',
            'createdon'
        ),
        'mod_ebooklti'
    );

    $types = ebooklti_filter_get_types(get_site()->id);

    $configuredtools = ebooklti_filter_tool_types($types, EBOOKLTI_TOOL_STATE_CONFIGURED);

    $configuredtoolshtml = ebooklti_get_tool_table($configuredtools, 'ebooklti_configured');

    $pendingtools = ebooklti_filter_tool_types($types, EBOOKLTI_TOOL_STATE_PENDING);

    $pendingtoolshtml = ebooklti_get_tool_table($pendingtools, 'ebooklti_pending');

    $rejectedtools = ebooklti_filter_tool_types($types, EBOOKLTI_TOOL_STATE_REJECTED);

    $rejectedtoolshtml = ebooklti_get_tool_table($rejectedtools, 'ebooklti_rejected');

    $tab = optional_param('tab', '', PARAM_ALPHAEXT);
    $activeselected = '';
    $pendingselected = '';
    $rejectedselected = '';
    switch ($tab) {
        case 'ebooklti_pending':
            $pendingselected = 'class="selected"';
            break;
        case 'ebooklti_rejected':
            $rejectedselected = 'class="selected"';
            break;
        default:
            $activeselected = 'class="selected"';
            break;
    }
    $addtype = get_string('addtype', 'ebooklti');
    $config = get_string('manage_tool_proxies', 'ebooklti');

    $addtypeurl = "{$CFG->wwwroot}/mod/ebooklti/typessettings.php?action=add&amp;sesskey={$USER->sesskey}";

    $template = <<< EOD
<div id="ebooklti_tabs" class="yui-navset">
    <ul id="ebooklti_tab_heading" class="yui-nav" style="display:none">
        <li {$activeselected}>
            <a href="#tab1">
                <em>$active</em>
            </a>
        </li>
        <li {$pendingselected}>
            <a href="#tab2">
                <em>$pending</em>
            </a>
        </li>
        <li {$rejectedselected}>
            <a href="#tab3">
                <em>$rejected</em>
            </a>
        </li>
    </ul>
    <div class="yui-content">
        <div>
            <div><a style="margin-top:.25em" href="{$addtypeurl}">{$addtype}</a></div>
            $configuredtoolshtml
        </div>
        <div>
            $pendingtoolshtml
        </div>
        <div>
            $rejectedtoolshtml
        </div>
    </div>
</div>

<script type="text/javascript">
//<![CDATA[
    YUI().use('yui2-tabview', 'yui2-datatable', function(Y) {
        //If javascript is disabled, they will just see the three tabs one after another
        var ebooklti_tab_heading = document.getElementById('ebooklti_tab_heading');
        ebooklti_tab_heading.style.display = '';

        new Y.YUI2.widget.TabView('ebooklti_tabs');

        var setupTools = function(id, sort){
            var ebooklti_tools = Y.YUI2.util.Dom.get(id);

            if(ebooklti_tools){
                var dataSource = new Y.YUI2.util.DataSource(ebooklti_tools);

                var configuredColumns = [
                    {key:'name', label: M.util.get_string('typename', 'mod_ebooklti'), sortable: true},
                    {key:'baseURL', label: M.util.get_string('baseurl', 'mod_ebooklti'), sortable: true},
                    {key:'timecreated', label: M.util.get_string('createdon', 'mod_ebooklti'), sortable: true},
                    {key:'action', label: M.util.get_string('action', 'mod_ebooklti')}
                ];

                dataSource.responseType = Y.YUI2.util.DataSource.TYPE_HTMLTABLE;
                dataSource.responseSchema = {
                    fields: [
                        {key:'name'},
                        {key:'baseURL'},
                        {key:'timecreated'},
                        {key:'action'}
                    ]
                };

                new Y.YUI2.widget.DataTable(id + '_container', configuredColumns, dataSource,
                    {
                        sortedBy: sort
                    }
                );
            }
        };

        setupTools('ebooklti_configured_tools', {key:'name', dir:'asc'});
        setupTools('ebooklti_pending_tools', {key:'timecreated', dir:'desc'});
        setupTools('ebooklti_rejected_tools', {key:'timecreated', dir:'desc'});
    });
//]]
</script>
EOD;
    $settings->add(new admin_setting_heading('ebooklti_types', new lang_string('external_tool_types', 'ebooklti') .
        $OUTPUT->help_icon('main_admin', 'ebooklti'), $template));
}

// Tell core we already added the settings structure.
$settings = null;

