<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains all necessary code to view a ebooklti activity instance
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');
require_once($CFG->libdir.'/completionlib.php');
require_once($CFG->dirroot.'/mod/ebooklti/lib.php');
require_once($CFG->dirroot.'/mod/ebooklti/locallib.php');

$id = optional_param('id', 0, PARAM_INT); // Course Module ID, or
$l  = optional_param('l', 0, PARAM_INT);  // ebooklti ID.
$forceview = optional_param('forceview', 0, PARAM_BOOL);

if ($l) {  // Two ways to specify the module.
    $ebooklti = $DB->get_record('ebooklti', array('id' => $l), '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('ebooklti', $ebooklti->id, $ebooklti->course, false, MUST_EXIST);

} else {
    $cm = get_coursemodule_from_id('ebooklti', $id, 0, false, MUST_EXIST);
    $ebooklti = $DB->get_record('ebooklti', array('id' => $cm->instance), '*', MUST_EXIST);
}

$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

if (!empty($ebooklti->typeid)) {
    $toolconfig = ebooklti_get_type_config($ebooklti->typeid);
} else if ($tool = ebooklti_get_tool_by_url_match($ebooklti->toolurl)) {
    $toolconfig = ebooklti_get_type_config($tool->id);
} else {
    $toolconfig = array();
}

$PAGE->set_cm($cm, $course); // Set's up global $COURSE.
$context = context_module::instance($cm->id);
$PAGE->set_context($context);

require_login($course, true, $cm);
require_capability('mod/ebooklti:view', $context);

$url = new moodle_url('/mod/ebooklti/view.php', array('id' => $cm->id));
$PAGE->set_url($url);

$launchcontainer = ebooklti_get_launch_container($ebooklti, $toolconfig);

if ($launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_EMBED_NO_BLOCKS) {
    $PAGE->set_pagelayout('frametop'); // Most frametops don't include footer, and pre-post blocks.
    $PAGE->blocks->show_only_fake_blocks(); // Disable blocks for layouts which do include pre-post blocks.
} else if ($launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_REPLACE_MOODLE_WINDOW) {
    if (!$forceview) {
        $url = new moodle_url('/mod/ebooklti/launch.php', array('id' => $cm->id));
        redirect($url);
    }
} else {
    $PAGE->set_pagelayout('incourse');
}

ebooklti_view($ebooklti, $course, $cm, $context);

$pagetitle = strip_tags($course->shortname.': '.format_string($ebooklti->name));
$PAGE->set_title($pagetitle);
$PAGE->set_heading($course->fullname);

// Print the page header.
echo $OUTPUT->header();

if ($ebooklti->showtitlelaunch) {
    // Print the main part of the page.
    echo $OUTPUT->heading(format_string($ebooklti->name, true, array('context' => $context)));
}

if ($ebooklti->showdescriptionlaunch && $ebooklti->intro) {
    echo $OUTPUT->box(format_module_intro('ebooklti', $ebooklti, $cm->id), 'generalbox description', 'intro');
}

if ( $launchcontainer == EBOOKLTI_LAUNCH_CONTAINER_WINDOW ) {
    if (!$forceview) {
        echo "<script language=\"javascript\">//<![CDATA[\n";
        echo "window.open('launch.php?id=" . $cm->id . "&triggerview=0','ebooklti-" . $cm->id . "');";
        echo "//]]\n";
        echo "</script>\n";
        echo "<p>".get_string("basicebooklti_in_new_window", "ebooklti")."</p>\n";
    }
    $url = new moodle_url('/mod/ebooklti/launch.php', array('id' => $cm->id));
    echo html_writer::start_tag('p');
    echo html_writer::link($url, get_string("basicebooklti_in_new_window_open", "ebooklti"), array('target' => '_blank'));
    echo html_writer::end_tag('p');
} else {
    // Request the launch content with an iframe tag.
    echo '<iframe id="contentframe" height="600px" width="100%" src="launch.php?id='.$cm->id.'&triggerview=0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';

    // Output script to make the iframe tag be as large as possible.
    $resize = '
        <script type="text/javascript">
        //<![CDATA[
            YUI().use("node", "event", function(Y) {
                var doc = Y.one("body");
                var frame = Y.one("#contentframe");
                var padding = 15; //The bottom of the iframe wasn\'t visible on some themes. Probably because of border widths, etc.
                var lastHeight;
                var resize = function(e) {
                    var viewportHeight = doc.get("winHeight");
                    if(lastHeight !== Math.min(doc.get("docHeight"), viewportHeight)){
                        frame.setStyle("height", viewportHeight - frame.getY() - padding + "px");
                        lastHeight = Math.min(doc.get("docHeight"), doc.get("winHeight"));
                    }
                };

                resize();

                Y.on("windowresize", resize);
            });
        //]]
        </script>
';

    echo $resize;
}

// Finish the page.
echo $OUTPUT->footer();
