<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains all the backup steps that will be used
 * by the backup_ebooklti_activity_task
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

/**
 * Define the complete assignment structure for backup, with file and id annotations
 */
class backup_ebooklti_activity_structure_step extends backup_activity_structure_step {

    /**
     * Defines structure of activity backup
     * @return backup_nested_element
     */
    protected function define_structure() {
        global $DB;

        // To know if we are including userinfo.
        $userinfo = $this->get_setting_value('userinfo');

        // Define each element separated.
        $ebooklti = new backup_nested_element('ebooklti', array('id'), array(
            'name',
            'intro',
            'introformat',
            'timecreated',
            'timemodified',
            'typeid',
            'toolurl',
            'securetoolurl',
            'preferheight',
            'launchcontainer',
            'instructorchoicesendname',
            'instructorchoicesendemailaddr',
            'instructorchoiceacceptgrades',
            'instructorchoiceallowroster',
            'instructorchoiceallowsetting',
            'grade',
            'instructorcustomparameters',
            'debuglaunch',
            'showtitlelaunch',
            'showdescriptionlaunch',
            'icon',
            'secureicon',
            'custom_resource_link_id',
            'custom_activity_type',
            'custom_unique_activity_id',
            'custom_course_idnumber',
            'custom_is_restricted_access',
            new encrypted_final_element('resourcekey'),
            new encrypted_final_element('password'),
            )
        );
		/*
        $ebookltitype = new backup_nested_element('ebookltitype', array('id'), array(
            'name',
            'baseurl',
            'tooldomain',
            'state',
            'course',
            'coursevisible',
            'toolproxyid',
            'enabledcapability',
            'parameter',
            'icon',
            'secureicon',
            'createdby',
            'timecreated',
            'timemodified',
            'description'
            )
        );

        $ebookltitypesconfigs = new backup_nested_element('ebookltitypesconfigs');
        $ebookltitypesconfig  = new backup_nested_element('ebookltitypesconfig', array('id'), array(
                'name',
                'value',
            )
        );
        $ebookltitypesconfigencrypted  = new backup_nested_element('ebookltitypesconfigencrypted', array('id'), array(
                'name',
                new encrypted_final_element('value'),
            )
        );

        $ebookltitoolproxy = new backup_nested_element('ebookltitoolproxy', array('id'));

        $ebookltitoolsettings = new backup_nested_element('ebookltitoolsettings');
        $ebookltitoolsetting  = new backup_nested_element('ebookltitoolsetting', array('id'), array(
                'settings',
                'timecreated',
                'timemodified',
            )
        );

        $ebookltisubmissions = new backup_nested_element('ebookltisubmissions');
        $ebookltisubmission = new backup_nested_element('ebookltisubmission', array('id'), array(
            'userid',
            'datesubmitted',
            'dateupdated',
            'gradepercent',
            'originalgrade',
            'launchid',
            'state'
        ));
		*/
        // Build the tree
        /*
		$ebooklti->add_child($ebookltitype);
        $ebookltitype->add_child($ebookltitypesconfigs);
        $ebookltitypesconfigs->add_child($ebookltitypesconfig);
        $ebookltitypesconfigs->add_child($ebookltitypesconfigencrypted);
        $ebookltitype->add_child($ebookltitoolproxy);
        $ebookltitoolproxy->add_child($ebookltitoolsettings);
        $ebookltitoolsettings->add_child($ebookltitoolsetting);
        $ebooklti->add_child($ebookltisubmissions);
        $ebookltisubmissions->add_child($ebookltisubmission);
		*/
        
		// Define sources.
        //$ebookltirecord = $DB->get_record('ebooklti', ['id' => $this->task->get_activityid()]);
        //$ebooklti->set_source_array([$ebookltirecord]);
		$ebooklti->set_source_table('ebooklti', array('id' => backup::VAR_ACTIVITYID));
		/*
        $ebookltitypedata = $this->retrieve_ebooklti_type($ebookltirecord);
        $ebookltitype->set_source_array($ebookltitypedata ? [$ebookltitypedata] : []);

        if (isset($ebookltitypedata->baseurl)) {
            // Add type config values only if the type was backed up. Encrypt password and resourcekey.
            $params = [backup_helper::is_sqlparam($ebookltitypedata->id),
                backup_helper::is_sqlparam('password'),
                backup_helper::is_sqlparam('resourcekey')];
            $ebookltitypesconfig->set_source_sql("SELECT id, name, value
                FROM {ebooklti_types_config}
                WHERE typeid = ? AND name <> ? AND name <> ?", $params);
            $ebookltitypesconfigencrypted->set_source_sql("SELECT id, name, value
                FROM {ebooklti_types_config}
                WHERE typeid = ? AND (name = ? OR name = ?)", $params);
        }

        if (!empty($ebookltitypedata->toolproxyid)) {
            // If this is LTI 2 tool add settings for the current activity.
            $ebookltitoolproxy->set_source_array([['id' => $ebookltitypedata->toolproxyid]]);
            $ebookltitoolsetting->set_source_sql("SELECT *
                FROM {ebooklti_tool_settings}
                WHERE toolproxyid = ? AND course = ? AND coursemoduleid = ?",
                [backup_helper::is_sqlparam($ebookltitypedata->toolproxyid), backup::VAR_COURSEID, backup::VAR_MODID]);
        } else {
            $ebookltitoolproxy->set_source_array([]);
        }

        // All the rest of elements only happen if we are including user info.
        if ($userinfo) {
            $ebookltisubmission->set_source_table('ebooklti_submission', array('ebookltiid' => backup::VAR_ACTIVITYID));
        }

        // Define id annotations
        $ebookltitype->annotate_ids('user', 'createdby');
        $ebookltitype->annotate_ids('course', 'course');
        $ebookltisubmission->annotate_ids('user', 'userid');
		*/
        // Define file annotations.
        $ebooklti->annotate_files('mod_ebooklti', 'intro', null); // This file areas haven't itemid.

        // Add support for subplugin structures.
        $this->add_subplugin_structure('ebookltisource', $ebooklti, true);
        $this->add_subplugin_structure('ebookltiservice', $ebooklti, true);

        // Return the root element (ebooklti), wrapped into standard activity structure.
        return $this->prepare_activity_structure($ebooklti);
    }

    /**
     * Retrieves a record from {ebooklti_type} table associated with the current activity
     *
     * Information about site tools is not returned because it is insecure to back it up,
     * only fields necessary for same-site tool matching are left in the record
     *
     * @param stdClass $ebookltirecord record from {ebooklti} table
     * @return stdClass|null
     */
	 /*
    protected function retrieve_ebooklti_type($ebookltirecord) {
        global $DB;
        if (!$ebookltirecord->typeid) {
            return null;
        }

        $record = $DB->get_record('ebooklti_types', ['id' => $ebookltirecord->typeid]);
        if ($record && $record->course == SITEID) {
            // Site EBOOKLTI types or registrations are not backed up except for their name (which is visible).
            // Predefined course types can be backed up.
            $allowedkeys = ['id', 'course', 'name', 'toolproxyid'];
            foreach ($record as $key => $value) {
                if (!in_array($key, $allowedkeys)) {
                    $record->$key = null;
                }
            }
        }

        return $record;
    }
	*/
}
