<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
//
// This file is part of BasicEBOOKLTI4Moodle
//
// BasicEBOOKLTI4Moodle is an IMS BasicEBOOKLTI (Basic Learning Tools for Interoperability)
// consumer for Moodle 1.9 and Moodle 2.0. BasicEBOOKLTI is a IMS Standard that allows web
// based learning tools to be easily integrated in LMS as native ones. The IMS BasicEBOOKLTI
// specification is part of the IMS standard Common Cartridge 1.1 Sakai and other main LMS
// are already supporting or going to support BasicEBOOKLTI. This project Implements the consumer
// for Moodle. Moodle is a Free Open source Learning Management System by Martin Dougiamas.
// BasicEBOOKLTI4Moodle is a project iniciated and leaded by Ludo(Marc Alier) and Jordi Piguillem
// at the GESSI research group at UPC.
// SimpleLTI consumer for Moodle is an implementation of the early specification of EBOOKLTI
// by Charles Severance (Dr Chuck) htp://dr-chuck.com , developed by Jordi Piguillem in a
// Google Summer of Code 2008 project co-mentored by Charles Severance and Marc Alier.
//
// BasicEBOOKLTI4Moodle is copyright 2009 by Marc Alier Forment, Jordi Piguillem and Nikolas Galanis
// of the Universitat Politecnica de Catalunya http://www.upc.edu
// Contact info: Marc Alier Forment granludo @ gmail.com or marc.alier @ upc.edu.

/**
 * This file contains all the restore steps that will be used
 * by the restore_ebooklti_activity_task
 *
 * @package mod_ebooklti
 * @copyright  2018 onwards Ascend Learning LLC. All rights reserved.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

/**
 * Structure step to restore one ebooklti activity
 */
class restore_ebooklti_activity_structure_step extends restore_activity_structure_step {

    /** @var bool */
    //protected $newebookltitype = false;

    protected function define_structure() {

        $paths = array();
        // To know if we are including userinfo.
        //$userinfo = $this->get_setting_value('userinfo');

        $ebooklti = new restore_path_element('ebooklti', '/activity/ebooklti');
        $paths[] = $ebooklti;
        /*
		$paths[] = new restore_path_element('ebookltitype', '/activity/ebooklti/ebookltitype');
        $paths[] = new restore_path_element('ebookltitypesconfig', '/activity/ebooklti/ebookltitype/ebookltitypesconfigs/ebookltitypesconfig');
        $paths[] = new restore_path_element('ebookltitypesconfigencrypted',
            '/activity/ebooklti/ebookltitype/ebookltitypesconfigs/ebookltitypesconfigencrypted');
        $paths[] = new restore_path_element('ebookltitoolproxy', '/activity/ebooklti/ebookltitype/ebookltitoolproxy');
        $paths[] = new restore_path_element('ebookltitoolsetting', '/activity/ebooklti/ebookltitype/ebookltitoolproxy/ebookltitoolsettings/ebookltitoolsetting');
		
        if ($userinfo) {
            $submission = new restore_path_element('ebookltisubmission', '/activity/ebooklti/ebookltisubmissions/ebookltisubmission');
            $paths[] = $submission;
        }
		*/
        // Add support for subplugin structures.
        $this->add_subplugin_structure('ebookltisource', $ebooklti);
        $this->add_subplugin_structure('ebookltiservice', $ebooklti);

        // Return the paths wrapped into standard activity structure.
        return $this->prepare_activity_structure($paths);
    }

    protected function process_ebooklti($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();
        $data->servicesalt = uniqid('', true);

        // Any changes to the list of dates that needs to be rolled should be same during course restore and course reset.
        // See MDL-9367.

         // Grade used to be a float (whole numbers only), restore as int.
        $data->grade = (int) $data->grade;

        $data->typeid = 0;

        // Try to decrypt resourcekey and password. Null if not possible (DB default).
        // Note these fields were originally encrypted on backup using {link @encrypted_final_element}.
        $data->resourcekey = isset($data->resourcekey) ? $this->decrypt($data->resourcekey) : null;
        $data->password = isset($data->password) ? $this->decrypt($data->password) : null;

        $newitemid = $DB->insert_record('ebooklti', $data);

        // Immediately after inserting "activity" record, call this.
        $this->apply_activity_instance($newitemid);
    }

    /**
     * Process an ebooklti type restore
     * @param mixed $data The data from backup XML file
     * @return void
     */
    /*
	protected function process_ebookltitype($data) {
        global $DB, $USER;

        $data = (object)$data;
        $oldid = $data->id;
        if (!empty($data->createdby)) {
            $data->createdby = $this->get_mappingid('user', $data->createdby) ?: $USER->id;
        }

        $courseid = $this->get_courseid();
        $data->course = ($this->get_mappingid('course', $data->course) == $courseid) ? $courseid : SITEID;

        // Try to find existing ebooklti type with the same properties.
        $ebookltitypeid = $this->find_existing_ebooklti_type($data);

        $this->newebookltitype = false;
        if (!$ebookltitypeid && $data->course == $courseid) {
            unset($data->toolproxyid); // Course tools can not use LTI2.
            $ebookltitypeid = $DB->insert_record('ebooklti_types', $data);
            $this->newebookltitype = true;
            $this->set_mapping('ebookltitype', $oldid, $ebookltitypeid);
        }

        // Add the typeid entry back to EBOOKLTI module.
        $DB->update_record('ebooklti', ['id' => $this->get_new_parentid('ebooklti'), 'typeid' => $ebookltitypeid]);
    }
	*/
    /**
     * Attempts to find existing record in ebooklti_type
     * @param stdClass $data
     * @return int|null field ebooklti_types.id or null if tool is not found
     */
	/* 
    protected function find_existing_ebooklti_type($data) {
        global $DB;
        if ($ebookltitypeid = $this->get_mappingid('ebookltitype', $data->id)) {
            return $ebookltitypeid;
        }

        $ebookltitype = null;
        $params = (array)$data;
        if ($this->task->is_samesite()) {
            // If we are restoring on the same site try to find ebooklti type with the same id.
            $sql = 'id = :id AND course = :course';
            $sql .= ($data->toolproxyid) ? ' AND toolproxyid = :toolproxyid' : ' AND toolproxyid IS NULL';
            if ($DB->record_exists_select('ebooklti_types', $sql, $params)) {
                $this->set_mapping('ebookltitype', $data->id, $data->id);
                if ($data->toolproxyid) {
                    $this->set_mapping('ebookltitoolproxy', $data->toolproxyid, $data->toolproxyid);
                }
                return $data->id;
            }
        }

        if ($data->course != $this->get_courseid()) {
            // Site tools are not backed up and are not restored.
            return null;
        }

        // Now try to find the same type on the current site available in this course.
        // Compare only fields baseurl, course and name, if they are the same we assume it is the same tool.
        // LTI2 is not possible in the course so we add "lt.toolproxyid IS NULL" to the query.
        $sql = 'SELECT id
            FROM {ebooklti_types}
           WHERE ' . $DB->sql_compare_text('baseurl', 255) . ' = ' . $DB->sql_compare_text(':baseurl', 255) . ' AND
                 course = :course AND name = :name AND toolproxyid IS NULL';
        if ($ebookltitype = $DB->get_record_sql($sql, $params, IGNORE_MULTIPLE)) {
            $this->set_mapping('ebookltitype', $data->id, $ebookltitype->id);
            return $ebookltitype->id;
        }

        return null;
    }
	*/
    /**
     * Process an ebooklti config restore
     * @param mixed $data The data from backup XML file
     */
	/* 
    protected function process_ebookltitypesconfig($data) {
        global $DB;

        $data = (object)$data;
        $data->typeid = $this->get_new_parentid('ebookltitype');

        // Only add configuration if the new ebooklti_type was created.
        if ($data->typeid && $this->newebookltitype) {
            if ($data->name == 'servicesalt') {
                $data->value = uniqid('', true);
            }
            $DB->insert_record('ebooklti_types_config', $data);
        }
    }
	*/
    /**
     * Process an ebooklti config restore
     * @param mixed $data The data from backup XML file
     */
	/* 
    protected function process_ebookltitypesconfigencrypted($data) {
        global $DB;

        $data = (object)$data;
        $data->typeid = $this->get_new_parentid('ebookltitype');

        // Only add configuration if the new ebooklti_type was created.
        if ($data->typeid && $this->newebookltitype) {
            $data->value = $this->decrypt($data->value);
            if (!is_null($data->value)) {
                $DB->insert_record('ebooklti_types_config', $data);
            }
        }
    }
	*/
    /**
     * Process a restore of EBOOKLTI tool registration
     * This method is empty because we actually process registration as part of process_ebookltitype()
     * @param mixed $data The data from backup XML file
     */
	/* 
    protected function process_ebookltitoolproxy($data) {

    }
	*/
    /**
     * Process an ebooklti tool registration settings restore (only settings for the current activity)
     * @param mixed $data The data from backup XML file
     */
	/* 
    protected function process_ebookltitoolsetting($data) {
        global $DB;

        $data = (object)$data;
        $data->toolproxyid = $this->get_new_parentid('ebookltitoolproxy');

        if (!$data->toolproxyid) {
            return;
        }

        $data->course = $this->get_courseid();
        $data->coursemoduleid = $this->task->get_moduleid();
        $DB->insert_record('ebooklti_tool_settings', $data);
    }
	*/
    /**
     * Process a submission restore
     * @param mixed $data The data from backup XML file
     */
	/* 
    protected function process_ebookltisubmission($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->ebookltiid = $this->get_new_parentid('ebooklti');

        $data->datesubmitted = $this->apply_date_offset($data->datesubmitted);
        $data->dateupdated = $this->apply_date_offset($data->dateupdated);
        if ($data->userid > 0) {
            $data->userid = $this->get_mappingid('user', $data->userid);
        }

        $newitemid = $DB->insert_record('ebooklti_submission', $data);

        $this->set_mapping('ebookltisubmission', $oldid, $newitemid);
    }
	*/
    protected function after_execute() {
        // Add ebooklti related files, no need to match by itemname (just internally handled context).
        $this->add_related_files('mod_ebooklti', 'intro', null);
    }
}
